package com.sajid.splayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.concurrent.CopyOnWriteArrayList

/** Shared state of the running save so the screen can show / hide its progress. */
object ExportJob {
    @Volatile var active = false
    @Volatile var cancel = false
    @Volatile var pct = 0
    @Volatile var resultMsg = ""
    val listeners = CopyOnWriteArrayList<() -> Unit>()
    fun fire() { for (l in listeners) l() }
}

/** Runs Video cutter / Video to MP3 in the background so the user can keep using the app. */
class ExportService : Service() {
    private var title = ""

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "cancel") { ExportJob.cancel = true; return START_NOT_STICKY }
        val u = i?.getStringExtra("uri")
        if (i == null || u == null) { stopSelf(); return START_NOT_STICKY }
        val name = i.getStringExtra("name") ?: ""
        val audio = i.getBooleanExtra("audio", false)
        title = (if (audio) "Converting to MP3 • " else "Cutting video • ") + name.substringBeforeLast('.')
        ExportJob.active = true
        ExportJob.cancel = false
        ExportJob.pct = 0
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("export", "Saving", NotificationManager.IMPORTANCE_LOW))
        val n = progressNotif(0)
        if (Build.VERSION.SDK_INT >= 29) startForeground(41, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(41, n)

        Exporter.run(
            this, Uri.parse(u), name, i.getLongExtra("start", 0L), i.getLongExtra("end", 0L), audio, i.getLongExtra("total", 0L),
            { pc ->
                if (pc != ExportJob.pct) {
                    ExportJob.pct = pc
                    try { getSystemService(NotificationManager::class.java).notify(41, progressNotif(pc)) } catch (e: Exception) {}
                    ExportJob.fire()
                }
            },
            { ok, msg ->
                ExportJob.resultMsg = if (ok) "Saved to $msg" else if (msg == "Cancelled") "Cancelled" else "Failed: $msg"
                ExportJob.active = false
                ExportJob.cancel = false
                stopForeground(STOP_FOREGROUND_DETACH)
                val done = NotificationCompat.Builder(this, "export")
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(title)
                    .setContentText(ExportJob.resultMsg)
                    .setAutoCancel(true)
                    .build()
                try { getSystemService(NotificationManager::class.java).notify(41, done) } catch (e: Exception) {}
                ExportJob.fire()
                stopSelf()
            },
            exclude = i.getBooleanExtra("exclude", false),
            bitrate = i.getIntExtra("bitrate", 192),
            volume = i.getIntExtra("volume", 100),
            fadeIn = i.getIntExtra("fadeIn", 0),
            fadeOut = i.getIntExtra("fadeOut", 0),
            silenceIn = i.getIntExtra("silenceIn", 0),
            silenceOut = i.getIntExtra("silenceOut", 0)
        )
        return START_NOT_STICKY
    }

    private fun progressNotif(pc: Int): Notification {
        val cancel = PendingIntent.getService(
            this, 41, Intent(this, ExportService::class.java).setAction("cancel"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "export")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText("$pc%")
            .setProgress(100, pc, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancel)
            .build()
    }
}
