package com.sajid.splayer

import android.content.Context
import android.content.SharedPreferences

class Prefs(c: Context) {
    val sp: SharedPreferences = c.applicationContext.getSharedPreferences("s", 0)

    fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun i(k: String, d: Int) = sp.getInt(k, d)
    fun put(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun put(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }

    var dark: Boolean
        get() = b("dark", false)
        set(v) = put("dark", v)
    var accent: Int
        get() = i("accent", 0xFF3F51B5.toInt())
        set(v) = put("accent", v)
    var resume: Boolean
        get() = b("resume", true)
        set(v) = put("resume", v)
    var auto: Boolean
        get() = b("auto", true)
        set(v) = put("auto", v)
    /** keep playing the sound (background play) when leaving the video player */
    var autoBg: Boolean
        get() = b("auto_bg", true)
        set(v) = put("auto_bg", v)
    var showLast: Boolean
        get() = b("showlast", true)
        set(v) = put("showlast", v)
    var orient: Int
        get() = i("orient", 0)
        set(v) = put("orient", v)
    var musicFirst: Boolean
        get() = b("musicfirst", false)
        set(v) = put("musicfirst", v)
    var sysEq: Boolean
        get() = b("syseq", false)
        set(v) = put("syseq", v)
    var smartVol: Boolean
        get() = b("smartvol", false)
        set(v) = put("smartvol", v)
    var minSec: Int
        get() = i("minsec", 0)
        set(v) = put("minsec", v)
    var broadcast: Boolean
        get() = b("broadcast", true)
        set(v) = put("broadcast", v)
    var scrobble: Boolean
        get() = b("scrobble", false)
        set(v) = put("scrobble", v)
    var shake: Boolean
        get() = b("shake", false)
        set(v) = put("shake", v)
    var shakeAction: Int
        get() = i("shakeact", 0)
        set(v) = put("shakeact", v)
    var shakeForce: Int
        get() = i("shakeforce", 70)
        set(v) = put("shakeforce", v)
    var sortKey: Int
        get() = i("sortkey", 0)
        set(v) = put("sortkey", v)
    var sortAsc: Boolean
        get() = b("sortasc", true)
        set(v) = put("sortasc", v)
    var grid: Boolean
        get() = b("grid", false)
        set(v) = put("grid", v)
    var pin: String
        get() = sp.getString("pin", "") ?: ""
        set(v) = put("pin", v)
    var lastUri: String
        get() = sp.getString("last_u", "") ?: ""
        set(v) = put("last_u", v)
    var lastName: String
        get() = sp.getString("last_n", "") ?: ""
        set(v) = put("last_n", v)
    var lastVideo: Boolean
        get() = b("last_v", true)
        set(v) = put("last_v", v)

    var bgPlay: Boolean
        get() = b("bgplay", false)
        set(v) = put("bgplay", v)
    var decoder: Int
        get() = i("decoder", 0)
        set(v) = put("decoder", v)
    /** speed used while the finger rests on the video (long press) */
    var holdSpeed: Float
        get() = sp.getFloat("hold_speed", 3f)
        set(v) { sp.edit().putFloat("hold_speed", v).apply() }
    var viz: Boolean
        get() = b("viz", false)
        set(v) = put("viz", v)

    companion object {
        val V_KEYS = listOf("all", "folder", "playlist")
        val A_KEYS = listOf("album", "songs", "artist", "folder", "playlist", "recent", "genres", "mini")
        val A_DEFAULT_ON = listOf("album", "songs", "artist", "folder", "playlist")
    }

    /** Full ordered list of tab keys for a mode (always contains every key once). */
    fun order(video: Boolean): List<String> {
        val all = if (video) V_KEYS else A_KEYS
        val saved = (sp.getString(if (video) "v_order" else "a_order", null) ?: "").split(",").filter { it in all }
        return (saved + all.filter { it !in saved }).distinct()
    }
    fun on(video: Boolean): MutableSet<String> {
        val k = if (video) "v_on" else "a_on"
        val raw = sp.getString(k, null)
        val all = if (video) V_KEYS else A_KEYS
        return if (raw == null) (if (video) V_KEYS else A_DEFAULT_ON).toMutableSet()
        else raw.split(",").filter { it in all }.toMutableSet()
    }
    fun saveTabs(video: Boolean, order: List<String>, on: Set<String>) {
        put(if (video) "v_order" else "a_order", order.joinToString(","))
        put(if (video) "v_on" else "a_on", on.joinToString(","))
    }
    /** Enabled tabs in the saved order (never empty). */
    fun tabs(video: Boolean): List<String> {
        val on = on(video)
        val l = order(video).filter { it in on }
        return if (l.isEmpty()) listOf(order(video).first()) else l
    }

    fun tag(id: Long, f: String): String = sp.getString("tg_${id}_$f", "") ?: ""
    fun setTag(id: Long, f: String, v: String) = put("tg_${id}_$f", v)

    fun strs(k: String): MutableSet<String> = HashSet(sp.getStringSet(k, emptySet()) ?: emptySet())
    fun putStrs(k: String, s: Set<String>) { sp.edit().putStringSet(k, HashSet(s)).apply() }

    // ---- named playlists: names in "pl_names" (own order), items of each in "plo_<name>" (own order)
    private fun split(s: String?) = if (s.isNullOrEmpty()) emptyList<String>() else s.split("\n")

    fun plNames(): List<String> {
        if (sp.contains("pl")) {   // very old single playlist
            val old = strs("pl")
            sp.edit().remove("pl").apply()
            if (old.isNotEmpty()) plCreate("My playlist", old.toList())
        }
        val saved = split(sp.getString("pl_names", null))
        val legacy = strs("pls").filter { it !in saved }.sortedWith(String.CASE_INSENSITIVE_ORDER)   // v3.1 data
        val all = (saved + legacy).distinct()
        if (legacy.isNotEmpty()) { plSetNameOrder(all); sp.edit().remove("pls").apply() }
        return all
    }
    fun plSetNameOrder(l: List<String>) { put("pl_names", l.joinToString("\n")) }

    fun plList(n: String): List<String> {
        val s = sp.getString("plo_$n", null)
        if (s != null) return split(s)
        val old = strs("pl_$n").toList()   // v3.1 data
        if (old.isNotEmpty()) plSetOrder(n, old)
        return old
    }
    fun plItems(n: String): Set<String> = plList(n).toSet()
    fun plSetOrder(n: String, l: List<String>) { put("plo_$n", l.joinToString("\n")) }
    fun plCreate(n: String, keys: Collection<String> = emptyList()) {
        val names = plNames()
        if (n !in names) plSetNameOrder(names + n)
        plSetOrder(n, (plList(n) + keys).distinct())
    }
    fun plAdd(n: String, keys: Collection<String>) = plCreate(n, keys)
    fun plRemoveItem(n: String, key: String) { plSetOrder(n, plList(n) - key) }
    fun plDelete(n: String) {
        plSetNameOrder(plNames() - n)
        sp.edit().remove("plo_$n").remove("pl_$n").apply()
    }
    fun plRename(old: String, new: String) {
        val items = plList(old)
        val names = plNames().map { if (it == old) new else it }
        sp.edit().remove("plo_$old").remove("pl_$old").apply()
        plSetNameOrder(names)
        plSetOrder(new, items)
    }

    // last video queue (for the video mini bar)
    var lastQ: List<String>
        get() = split(sp.getString("lq_u", null))
        set(v) = put("lq_u", v.joinToString("\n"))
    var lastQN: List<String>
        get() = split(sp.getString("lq_n", null))
        set(v) = put("lq_n", v.joinToString("\n"))

    fun folderColor(f: String) = i("fc_$f", 0)
    fun setFolderColor(f: String, c: Int) = put("fc_$f", c)
    fun alias(f: String) = sp.getString("al_$f", null) ?: f
    fun setAlias(f: String, n: String) = put("al_$f", n)
}
