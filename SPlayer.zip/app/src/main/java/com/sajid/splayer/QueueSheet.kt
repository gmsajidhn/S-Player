package com.sajid.splayer

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog

data class QueueEntry(val key: String, val title: String)

private class QueueRowHolder(
    val row: LinearLayout,
    val handle: TextView,
    val name: TextView,
    val remove: TextView
) : RecyclerView.ViewHolder(row)

object QueueSheet {
    fun show(
        context: Context,
        title: String,
        entries: List<QueueEntry>,
        accent: Int,
        currentKey: String? = null,
        showMode: Boolean = false,
        modeIndex: () -> Int = { AudioEngine.modeIndex() },
        onCycleMode: () -> Unit = { AudioEngine.cycleMode() },
        onSelect: (QueueEntry) -> Unit,
        onChange: (List<QueueEntry>) -> Unit
    ) {
        val dialog = BottomSheetDialog(context)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(context.dp(18), context.dp(12), 0, context.dp(20))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF292929.toInt())
                cornerRadii = floatArrayOf(context.dp(26).toFloat(), context.dp(26).toFloat(), context.dp(26).toFloat(), context.dp(26).toFloat(), 0f, 0f, 0f, 0f)
            }
        }
        val header = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, context.dp(18), 0) }
        val close = TextView(context).apply {
            text = "×"; textSize = 30f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        header.addView(close, LinearLayout.LayoutParams(context.dp(42), context.dp(48)))
        val heading = TextView(context).apply {
            text = title; textSize = 18f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val count = TextView(context).apply {
            text = entries.size.toString(); textSize = 14f; setTextColor(0xFFAAAAAA.toInt())
            setPadding(context.dp(8), 0, context.dp(14), 0)
        }
        header.addView(count)
        if (showMode) {
            val modeLabel = TextView(context).apply { textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL }
            val modeIcon = PathIcon(Ic.ORDER, Color.WHITE)
            val modeIv = ImageView(context).apply { setImageDrawable(modeIcon); scaleType = ImageView.ScaleType.FIT_CENTER }
            val modeBox = LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true; isFocusable = true
                setPadding(context.dp(8), 0, context.dp(2), 0)
                addView(modeLabel, LinearLayout.LayoutParams(-2, -2))
                addView(modeIv, LinearLayout.LayoutParams(context.dp(26), context.dp(26)).apply { leftMargin = context.dp(6) })
            }
            fun refreshMode() {
                val i = modeIndex()
                modeLabel.text = AudioEngine.modeLabels[i]
                modeIcon.set(AudioEngine.modePath(i))
                modeIcon.tint(if (i == 0) Color.WHITE else accent)
            }
            refreshMode()
            modeBox.setOnClickListener { onCycleMode(); refreshMode() }
            header.addView(modeBox, LinearLayout.LayoutParams(-2, context.dp(48)))
        }
        root.addView(header)
        val rv = RecyclerView(context).apply {
            layoutManager = LinearLayoutManager(context)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val data = entries.toMutableList()
        var dragHelper: ItemTouchHelper? = null
        val adapter = object : RecyclerView.Adapter<QueueRowHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QueueRowHolder {
                val row = LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(context.dp(4), 0, 0, 0)
                    minimumHeight = context.dp(58)
                    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                }
                val handle = TextView(context).apply {
                    text = "≡"; textSize = 25f; setTextColor(0xFFAAAAAA.toInt()); gravity = Gravity.CENTER
                }
                row.addView(handle, LinearLayout.LayoutParams(context.dp(42), context.dp(54)))
                val name = TextView(context).apply {
                    textSize = 15f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
                    setPadding(context.dp(12), 0, context.dp(8), 0)
                }
                row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
                val remove = TextView(context).apply {
                    text = "×"; textSize = 28f; setTextColor(0xFFBDBDBD.toInt()); gravity = Gravity.CENTER
                }
                row.addView(remove, LinearLayout.LayoutParams(context.dp(46), context.dp(54)))
                return QueueRowHolder(row, handle, name, remove)
            }
            override fun getItemCount() = data.size
            override fun onBindViewHolder(h: QueueRowHolder, position: Int) {
                val item = data[position]
                h.name.text = item.title
                h.name.setTextColor(if (item.key == currentKey) 0xFF35C759.toInt() else Color.WHITE)
                h.handle.setOnTouchListener { _, event ->
                    if (event.actionMasked == android.view.MotionEvent.ACTION_DOWN) dragHelper?.startDrag(h)
                    true
                }
                h.row.setOnClickListener { onSelect(item); dialog.dismiss() }
                h.remove.setOnClickListener {
                    val at = h.bindingAdapterPosition
                    if (at != RecyclerView.NO_POSITION) {
                        data.removeAt(at); notifyItemRemoved(at); count.text = data.size.toString()
                        onChange(data.toList())
                    }
                }
            }
        }
        rv.adapter = adapter
        var moved = false
        val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(r: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                val from = vh.bindingAdapterPosition; val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                java.util.Collections.swap(data, from, to)
                adapter.notifyItemMoved(from, to)
                moved = true
                return true
            }
            override fun clearView(r: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(r, vh)
                if (moved) { moved = false; onChange(data.toList()) }
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}
            override fun isLongPressDragEnabled() = false
            override fun isItemViewSwipeEnabled() = false
        })
        dragHelper = touch
        touch.attachToRecyclerView(rv)
        root.addView(rv, LinearLayout.LayoutParams(-1, minOf(context.dp(560), context.dp(62) * maxOf(entries.size, 1))))
        dialog.setContentView(root)
        close.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }
}
