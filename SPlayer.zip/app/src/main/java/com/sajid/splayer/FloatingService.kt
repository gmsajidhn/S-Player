package com.sajid.splayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs

/** Starts the floating pop-up player. Returns false (and asks for the permission) if overlays are not allowed yet. */
fun Context.startPopup(uris: List<String>, names: List<String>, idx: Int, pos: Long, play: Boolean = true): Boolean {
    if (!Settings.canDrawOverlays(this)) {
        toast("Allow \"Display over other apps\" for S Player, then open pop-up again")
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
        return false
    }
    val i = Intent(this, FloatingService::class.java)
        .putStringArrayListExtra("u", ArrayList(uris)).putStringArrayListExtra("n", ArrayList(names))
        .putExtra("i", idx).putExtra("pos", pos).putExtra("play", play)
    ContextCompat.startForegroundService(this, i)
    return true
}

/**
 * Pop-up video: a floating window that can be dragged, pinched or corner-dragged to any size.
 * Top-left = full screen, top-right = close, middle = previous / play-pause / next, bottom = -10s (left) and +10s (right).
 */
class FloatingService : Service() {
    private var wm: WindowManager? = null
    private var root: FrameLayout? = null
    private var ctl: FrameLayout? = null
    private var grip: ImageView? = null
    private var bar: LinearLayout? = null
    private var barA: View? = null
    private var barB: View? = null
    private var titleTv: TextView? = null
    private var playIc: PathIcon? = null
    private var pv: PlayerView? = null
    private var params: WindowManager.LayoutParams? = null
    private var p: ExoPlayer? = null
    private var uris: List<String> = emptyList()
    private var names: List<String> = emptyList()
    private var ratio = 16f / 9f
    private var curW = 0f
    private var sized = false
    private var shown = true
    private var ticks = 0
    private val h = Handler(Looper.getMainLooper())
    private val ref get() = dp(300)

    private val hideRun = Runnable { if (p?.isPlaying == true) setControls(false) }
    private val tick = object : Runnable {
        override fun run() {
            val x = p
            if (x != null) {
                val d = maxOf(x.duration, 0L)
                val f = if (d > 0) (x.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
                (barA?.layoutParams as? LinearLayout.LayoutParams)?.weight = f
                (barB?.layoutParams as? LinearLayout.LayoutParams)?.weight = 1f - f
                bar?.requestLayout()
                ticks++
                if (ticks % 20 == 0) savePos()
            }
            h.postDelayed(this, 500)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "toggle" -> { p?.let { if (it.isPlaying) it.pause() else it.play() }; return START_NOT_STICKY }
            "full" -> { goFullscreen(); return START_NOT_STICKY }
            "close" -> { closeAll(); return START_NOT_STICKY }
        }
        val u = i?.getStringArrayListExtra("u")
        if (i == null || u == null || u.isEmpty()) { stopSelf(); return START_NOT_STICKY }
        startFg()
        uris = u
        names = i.getStringArrayListExtra("n") ?: arrayListOf()
        AudioEngine.player?.pause()
        if (root == null) buildWindow()
        startPlayer(i.getIntExtra("i", 0).coerceIn(0, u.size - 1), i.getLongExtra("pos", -1L), i.getBooleanExtra("play", true))
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ notification
    private fun startFg() {
        val n = notif()
        if (Build.VERSION.SDK_INT >= 29) startForeground(31, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(31, n)
    }

    private fun act(a: String, icon: Int, title: String): NotificationCompat.Action {
        val pi = PendingIntent.getService(
            this, a.hashCode(), Intent(this, FloatingService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Action(icon, title, pi)
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("popup", "Pop-up video", NotificationManager.IMPORTANCE_LOW))
        val playing = p?.isPlaying == true
        val i = (p?.currentMediaItemIndex ?: 0).coerceIn(0, maxOf(0, names.size - 1))
        return NotificationCompat.Builder(this, "popup")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(names.getOrElse(i) { "Pop-up video" })
            .setContentText("Pop-up player")
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .addAction(act("toggle", if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause"))
            .addAction(act("full", android.R.drawable.ic_menu_view, "Full screen"))
            .addAction(act("close", android.R.drawable.ic_menu_close_clear_cancel, "Close"))
            .build()
    }

    private fun refreshNotif() {
        try { getSystemService(NotificationManager::class.java).notify(31, notif()) } catch (e: Exception) {}
    }

    // ------------------------------------------------------------------ window
    private fun skipBtn(ctx: Context, fwd: Boolean): View {
        val f = FrameLayout(ctx)
        val iv = ImageView(ctx)
        iv.setImageDrawable(PathIcon(Ic.REPLAY, Color.WHITE))
        if (fwd) iv.scaleX = -1f
        f.addView(iv, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        val t = TextView(ctx)
        t.text = "10"
        t.textSize = 9f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        f.addView(t, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { topMargin = dp(2) })
        f.background = ctx.ripple(null, dpf(24))
        f.setOnClickListener {
            val x = p ?: return@setOnClickListener
            x.seekTo((x.currentPosition + if (fwd) 10000 else -10000).coerceIn(0L, maxOf(x.duration, 0L)))
            showControls()
        }
        return f
    }

    @Suppress("ClickableViewAccessibility")
    private fun buildWindow() {
        val ctx = ContextThemeWrapper(this, Themes.res(Prefs(this).accent))
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val dm = resources.displayMetrics
        val r = FrameLayout(ctx)
        r.setBackgroundColor(Color.BLACK)
        r.roundClip(dpf(14))
        val v = LayoutInflater.from(ctx).inflate(R.layout.view_player, r, false) as PlayerView
        r.addView(v, FrameLayout.LayoutParams(-1, -1))
        pv = v

        // ---- control layer (designed at 300dp wide, scaled together with the window)
        val c = FrameLayout(ctx)
        c.setBackgroundColor(0x66000000)
        c.addView(ctx.iconBtn(Ic.FULLSCREEN, Color.WHITE, 44, 24) { goFullscreen() }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START).apply { setMargins(dp(4), dp(4), 0, 0) })
        c.addView(ctx.iconBtn(Ic.CLOSE, Color.WHITE, 44, 24) { closeAll() }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(4), dp(4), 0) })
        val tt = TextView(ctx)
        tt.setTextColor(Color.WHITE)
        tt.textSize = 12f
        tt.maxLines = 1
        tt.ellipsize = android.text.TextUtils.TruncateAt.END
        tt.gravity = Gravity.CENTER
        titleTv = tt
        c.addView(tt, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(dp(52), dp(15), dp(52), 0) })

        val mid = LinearLayout(ctx)
        mid.gravity = Gravity.CENTER
        mid.addView(ctx.iconBtn(Ic.PREV, Color.WHITE, 44, 26) { p?.seekToPrevious(); showControls() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        val ring = FrameLayout(ctx)
        ring.background = ripple(null, dpf(28))
        val pi = PathIcon(Ic.PLAY, Color.WHITE)
        playIc = pi
        val piv = ImageView(ctx)
        piv.setImageDrawable(pi)
        ring.addView(piv, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER))
        ring.setOnClickListener {
            val x = p ?: return@setOnClickListener
            if (x.isPlaying) x.pause() else { if (x.playbackState == Player.STATE_ENDED) x.seekTo(0L); x.play() }
            showControls()
        }
        mid.addView(ring, LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(dp(12), 0, dp(12), 0) })
        mid.addView(ctx.iconBtn(Ic.NEXT, Color.WHITE, 44, 26) { p?.seekToNext(); showControls() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        c.addView(mid, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        c.addView(skipBtn(ctx, false), FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(22), 0, 0, dp(8)) })
        c.addView(skipBtn(ctx, true), FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(22), dp(8)) })
        r.addView(c, FrameLayout.LayoutParams(ref, (ref / ratio).toInt()))
        c.pivotX = 0f
        c.pivotY = 0f
        ctl = c

        // thin progress line, always visible
        val b = LinearLayout(ctx)
        val ba = View(ctx)
        ba.setBackgroundColor(Prefs(this).accent)
        val bb = View(ctx)
        bb.setBackgroundColor(0x55FFFFFF)
        b.addView(ba, LinearLayout.LayoutParams(0, -1, 0f))
        b.addView(bb, LinearLayout.LayoutParams(0, -1, 1f))
        r.addView(b, FrameLayout.LayoutParams(-1, dp(3), Gravity.BOTTOM))
        bar = b; barA = ba; barB = bb

        // touch strip over the progress line: tap or drag to jump anywhere in the video
        val zone = View(ctx)
        r.addView(zone, FrameLayout.LayoutParams(-1, dp(28), Gravity.BOTTOM).apply { marginEnd = dp(30) })
        zone.setOnTouchListener { v, e ->
            val x = p
            val d = x?.duration ?: 0L
            if (x != null && d > 0L) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                        v.parent.requestDisallowInterceptTouchEvent(true)
                        h.removeCallbacks(hideRun)
                        val f = (e.x / v.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                        x.seekTo((d * f).toLong())
                        (barA?.layoutParams as? LinearLayout.LayoutParams)?.weight = f
                        (barB?.layoutParams as? LinearLayout.LayoutParams)?.weight = 1f - f
                        bar?.let { it.layoutParams = (it.layoutParams as FrameLayout.LayoutParams).also { lp2 -> lp2.height = dp(7) } }
                        bar?.requestLayout()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        bar?.let { it.layoutParams = (it.layoutParams as FrameLayout.LayoutParams).also { lp2 -> lp2.height = dp(3) } }
                        showControls()
                    }
                }
            }
            true
        }

        // resize grip (bottom-right corner)
        val g = ImageView(ctx)
        g.setImageDrawable(PathIcon(Ic.RESIZE, Color.WHITE))
        g.setPadding(dp(7), dp(7), dp(7), dp(7))
        r.addView(g, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.BOTTOM or Gravity.END))
        grip = g
        var gx = 0f
        var gw = 0f
        g.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { gx = e.rawX; gw = curW; h.removeCallbacks(hideRun) }
                MotionEvent.ACTION_MOVE -> resizeTo(gw + (e.rawX - gx))
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> showControls()
            }
            true
        }

        // ---- window gestures: drag to move, pinch to resize, tap to show/hide controls
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { resizeTo(curW * d.scaleFactor); return true }
        })
        var bx = 0f
        var by = 0f
        var wx = 0
        var wy = 0
        var moved = false
        r.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            val pr = params
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    bx = e.rawX; by = e.rawY; wx = pr?.x ?: 0; wy = pr?.y ?: 0; moved = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> moved = true
                MotionEvent.ACTION_POINTER_UP -> {
                    val k = if (e.actionIndex == 0) 1 else 0
                    bx = e.getRawX(k); by = e.getRawY(k); wx = pr?.x ?: 0; wy = pr?.y ?: 0
                }
                MotionEvent.ACTION_MOVE -> if (!sd.isInProgress && pr != null) {
                    val dx = e.rawX - bx
                    val dy = e.rawY - by
                    if (e.pointerCount == 1 && (moved || abs(dx) > slop || abs(dy) > slop)) {
                        moved = true
                        pr.x = (wx + dx).toInt()
                        pr.y = (wy + dy).toInt()
                        clampPos()
                        try { wm?.updateViewLayout(root, pr) } catch (ex: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) setControls(!shown) else showControls()
            }
            true
        }

        val maxW = (dm.widthPixels * 0.62f).coerceAtMost(dp(360).toFloat())
        curW = maxW
        val lp = WindowManager.LayoutParams(
            curW.toInt(), (curW / ratio).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (dm.widthPixels - curW.toInt()) / 2
        lp.y = dp(96)
        params = lp
        root = r
        try { w.addView(r, lp) } catch (e: Exception) { toast("Cannot open pop-up window"); stopSelf(); return }
        updateScale()
        h.post(tick)
    }

    private fun clampPos() {
        val pr = params ?: return
        val dm = resources.displayMetrics
        pr.x = pr.x.coerceIn(0, maxOf(0, dm.widthPixels - pr.width))
        pr.y = pr.y.coerceIn(0, maxOf(0, dm.heightPixels - pr.height))
    }

    private fun updateScale() {
        val c = ctl ?: return
        val s = curW / ref
        c.scaleX = s
        c.scaleY = s
        val lp = c.layoutParams
        lp.width = ref
        lp.height = (ref / ratio).toInt()
        c.layoutParams = lp
    }

    /** Resize keeping the video's shape; limited by the screen. */
    private fun resizeTo(w: Float) {
        val pr = params ?: return
        val dm = resources.displayMetrics
        val maxW = minOf(dm.widthPixels.toFloat(), dm.heightPixels * ratio)
        val minW = minOf(dp(190).toFloat(), maxW)
        curW = w.coerceIn(minW, maxW)
        pr.width = curW.toInt()
        pr.height = (curW / ratio).toInt()
        clampPos()
        try { wm?.updateViewLayout(root, pr) } catch (e: Exception) {}
        updateScale()
    }

    private fun setControls(on: Boolean) {
        shown = on
        val vis = if (on) View.VISIBLE else View.GONE
        ctl?.visibility = vis
        grip?.visibility = vis
        h.removeCallbacks(hideRun)
        if (on && p?.isPlaying == true) h.postDelayed(hideRun, 3500)
    }

    private fun showControls() = setControls(true)

    // ------------------------------------------------------------------ player
    private fun startPlayer(idx: Int, pos: Long, play: Boolean) {
        p?.let { savePos(); it.release() }
        val pf = Prefs(this)
        val x = ExoPlayer.Builder(this).build()
        x.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
        x.setHandleAudioBecomingNoisy(true)
        x.setWakeMode(C.WAKE_MODE_LOCAL)
        val start = if (pos >= 0L) pos else if (pf.resume) pf.sp.getLong("pos_" + uris[idx], 0L) else 0L
        x.setMediaItems(uris.map { MediaItem.fromUri(it) }, idx, start)
        x.pauseAtEndOfMediaItems = !pf.auto
        x.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(vs: VideoSize) {
                if (vs.width <= 0 || vs.height <= 0) return
                val rot = vs.unappliedRotationDegrees % 180 != 0
                val vw = (if (rot) vs.height.toFloat() else vs.width.toFloat()) * (if (rot) 1f else vs.pixelWidthHeightRatio)
                val vh = if (rot) vs.width.toFloat() else vs.height.toFloat()
                ratio = (vw / vh).coerceIn(0.4f, 2.4f)
                if (!sized) {
                    sized = true
                    val dm = resources.displayMetrics
                    curW = minOf(dm.widthPixels * 0.62f, dm.heightPixels * 0.42f * ratio, dp(360).toFloat())
                }
                resizeTo(curW)
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playIc?.set(if (isPlaying) Ic.PAUSE else Ic.PLAY)
                setControls(shown)
                refreshNotif()
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { onTrack() }
            override fun onPlayerError(error: PlaybackException) { toast("Cannot play this file (${error.errorCodeName})") }
        })
        pv?.player = x
        x.prepare()
        x.playWhenReady = play
        p = x
        onTrack()
    }

    private fun onTrack() {
        val x = p ?: return
        val i = x.currentMediaItemIndex.coerceIn(0, maxOf(0, uris.size - 1))
        val n = names.getOrElse(i) { "" }
        titleTv?.text = n
        if (uris.getOrElse(i) { "" }.contains("/vault/").not() && uris.isNotEmpty()) {
            val pf = Prefs(this)
            pf.lastUri = uris[i]
            pf.lastName = n
            pf.lastVideo = true
        }
        refreshNotif()
    }

    private fun savePos() {
        val x = p ?: return
        if (uris.isEmpty()) return
        val i = x.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val d = x.duration
        val c = x.currentPosition
        val end = d > 0 && c > d - 3000
        Prefs(this).sp.edit().putLong("pos_" + uris[i], if (end || c < 3000) 0L else c).apply()
    }

    private fun goFullscreen() {
        val x = p ?: return
        savePos()
        val i = Intent(this, PlayerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putStringArrayListExtra("u", ArrayList(uris)).putStringArrayListExtra("n", ArrayList(names))
            .putExtra("i", x.currentMediaItemIndex).putExtra("v", true)
            .putExtra("pos", x.currentPosition).putExtra("play", x.playWhenReady)
        try { startActivity(i) } catch (e: Exception) { toast("Cannot open full screen") }
        closeAll()
    }

    private fun closeAll() {
        savePos()
        removeWindow()
        stopForeground(true)
        stopSelf()
    }

    private fun removeWindow() {
        h.removeCallbacksAndMessages(null)
        try { root?.let { wm?.removeView(it) } } catch (e: Exception) {}
        root = null
        try { p?.release() } catch (e: Exception) {}
        p = null
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        resizeTo(curW)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (root != null) { savePos(); removeWindow() }
    }
}
