package com.sajid.splayer

import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.material.materialswitch.MaterialSwitch

fun fmtSpeedX(x: Float): String = String.format(java.util.Locale.US, "%.2f", x).trimEnd('0').trimEnd('.')

/** "12:30" / "1:02:10" style remaining-time text for the sleep timer. */
fun fmtRemain(ms: Long): String {
    val s = (ms.coerceAtLeast(0L) + 999L) / 1000L
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(java.util.Locale.US, "%d:%02d", m, sec)
}

// ------------------------------------------------------------------ double-tap seek animation

/** Round glass bubble with three chevrons, a soft ripple and "10 sec" text, shown on double tap (left or right). */
class SeekFx(c: Context, private val right: Boolean) : View(c) {
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x47000000 }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d; color = 0x55FFFFFF }
    private val ripple = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.WHITE }
    private val ch = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE; color = Color.WHITE; strokeJoin = Paint.Join.ROUND; strokeWidth = 1.6f * d
    }
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        setShadowLayer(4f * d, 0f, 1f * d, 0x66000000)
    }
    private val tri = Path()
    private var text = ""
    private var step = 0f
    private var pop = 1f
    private val wave = ValueAnimator.ofFloat(0f, 3f).apply {
        duration = 720; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { step = it.animatedValue as Float; invalidate() }
    }
    private val popAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 520
        interpolator = android.view.animation.DecelerateInterpolator(1.6f)
        addUpdateListener { pop = it.animatedValue as Float; invalidate() }
    }
    private val hideRun = Runnable { animate().alpha(0f).setDuration(220).withEndAction { visibility = GONE; wave.cancel() }.start() }

    init { visibility = GONE; alpha = 0f; isClickable = false; setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun show(seconds: Int) {
        text = "$seconds sec"
        removeCallbacks(hideRun)
        if (visibility != VISIBLE) { visibility = VISIBLE; alpha = 0f }
        animate().cancel()
        animate().alpha(1f).setDuration(110).start()
        if (!wave.isStarted) wave.start()
        popAnim.cancel()
        popAnim.start()
        invalidate()
        postDelayed(hideRun, 760)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * .44f
        val scale = .9f + .1f * pop
        // glass bubble + thin rim
        cv.drawCircle(cx, cy, r * scale, fill)
        cv.drawCircle(cx, cy, r * scale, rim)
        // ripple ring that expands and fades on every tap
        ripple.alpha = ((1f - pop) * 110).toInt().coerceIn(0, 255)
        if (ripple.alpha > 0) cv.drawCircle(cx, cy, r * (.78f + .42f * pop), ripple)
        // three chevrons lighting up one after another
        val s = r * .17f
        val gap = s * 1.55f
        val y = cy - r * .16f
        for (k in 0 until 3) {
            val idx = if (right) k else 2 - k
            val a = (1f - kotlin.math.abs(step - idx - .5f).coerceAtMost(1.5f) / 1.5f).coerceIn(.28f, 1f)
            ch.alpha = (a * 255).toInt()
            val x = cx + (k - 1) * gap
            tri.reset()
            if (right) { tri.moveTo(x - s * .55f, y - s); tri.lineTo(x + s * .65f, y); tri.lineTo(x - s * .55f, y + s) }
            else { tri.moveTo(x + s * .55f, y - s); tri.lineTo(x - s * .65f, y); tri.lineTo(x + s * .55f, y + s) }
            tri.close()
            cv.drawPath(tri, ch)
        }
        tx.textSize = (r * .30f).coerceIn(11f * d, 16f * d)
        cv.drawText(text, cx, cy + r * .50f, tx)
    }
}

// ------------------------------------------------------------------ vertical slider (equalizer bands)

class VSlider(c: Context) : View(c) {
    var min = 0
    var max = 100
    var value = 50
        set(v) { field = v.coerceIn(min, max); invalidate() }
    var onChange: ((Int) -> Unit)? = null
    var green = 0xFF2DC76D.toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    private fun pad() = 16f * d
    private fun yFor(v: Int): Float {
        val t = (v - min).toFloat() / (max - min).coerceAtLeast(1)
        return pad() + (1f - t) * (height - 2 * pad())
    }

    override fun onDraw(cv: Canvas) {
        val x = width / 2f
        val y = yFor(value)
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3f * d
        p.color = 0xFFD0D0D0.toInt()
        cv.drawLine(x, pad(), x, height - pad(), p)
        p.color = green
        cv.drawLine(x, y, x, height - pad(), p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        cv.drawCircle(x, y, 13f * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> parent.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { parent.requestDisallowInterceptTouchEvent(false); return true }
        }
        val t = 1f - ((e.y - pad()) / (height - 2 * pad())).coerceIn(0f, 1f)
        val nv = min + Math.round(t * (max - min))
        if (nv != value) { value = nv; onChange?.invoke(nv) }
        return true
    }
}

// ------------------------------------------------------------------ extra audio effects

class FxExtras {
    var bass: BassBoost? = null
    var virt: Virtualizer? = null
    var rev: PresetReverb? = null

    fun release() {
        try { bass?.release() } catch (e: Exception) {}
        try { virt?.release() } catch (e: Exception) {}
        try { rev?.release() } catch (e: Exception) {}
        bass = null; virt = null; rev = null
    }

    companion object {
        fun create(session: Int, pf: Prefs): FxExtras {
            val x = FxExtras()
            if (session == 0) return x
            val on = pf.b("eq_on", true)
            try { x.bass = BassBoost(0, session).also { b -> if (b.strengthSupported) b.setStrength(pf.i("fx_bass", 0).toShort()); b.setEnabled(on && pf.i("fx_bass", 0) > 0) } } catch (e: Exception) {}
            try { x.virt = Virtualizer(0, session).also { v -> if (v.strengthSupported) v.setStrength(pf.i("fx_virt", 0).toShort()); v.setEnabled(on && pf.i("fx_virt", 0) > 0) } } catch (e: Exception) {}
            try { x.rev = PresetReverb(0, session).also { r -> r.preset = pf.i("fx_rev", 0).toShort(); r.setEnabled(on && pf.i("fx_rev", 0) > 0) } } catch (e: Exception) {}
            return x
        }
    }
}

// ------------------------------------------------------------------ Speed panel (like the reference "Speed" screen)

private fun Context.chip(text: String, selected: Boolean, green: Int, click: () -> Unit): TextView {
    val t = label(text, 17f, Color.WHITE)
    t.gravity = Gravity.CENTER
    t.maxLines = 1
    t.background = rr(if (selected) green else 0xFF262626.toInt(), dpf(30))
    t.setOnClickListener { click() }
    return t
}

/** Full-screen translucent Speed panel: big value, slider 0.25–8.0, preset buttons. */
fun Context.speedPanel(current: Float, onChange: (Float) -> Unit) {
    val green = 0xFF12B312.toInt()
    val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
    dlg.window?.apply {
        setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0xB8000000.toInt()))
        setLayout(-1, -1)
        addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
    }
    val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val root = FrameLayout(this)
    root.setOnClickListener { dlg.dismiss() }
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(16), dp(8), dp(16), dp(16))
    col.isClickable = true

    val head = LinearLayout(this)
    head.gravity = Gravity.CENTER_VERTICAL
    head.addView(iconBtn(Ic.BACK, Color.WHITE, 48, 26) { dlg.dismiss() })
    val title = label("Speed", 22f, Color.WHITE, true)
    title.setPadding(dp(8), 0, 0, 0)
    head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
    val big = label(fmtSpeedX(current) + "x", 26f, Color.WHITE, true)
    head.addView(big)
    col.addView(head, LinearLayout.LayoutParams(-1, -2))

    val seek = SeekBar(this)
    seek.max = 155                                   // 0.25 .. 8.00 in 0.05 steps
    seek.progress = ((current - 0.25f) / 0.05f).toInt().coerceIn(0, 155)
    seek.progressTintList = android.content.res.ColorStateList.valueOf(green)
    seek.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFF3A3A3A.toInt())
    seek.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
    col.addView(seek, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(10) })
    val scale = LinearLayout(this)
    scale.addView(label("0.25", 15f, 0xFFCCCCCC.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
    scale.addView(label("8.0", 15f, 0xFFCCCCCC.toInt()))
    scale.setPadding(dp(14), 0, dp(14), 0)
    col.addView(scale, LinearLayout.LayoutParams(-1, -2))

    val vals = floatArrayOf(0.25f, 0.5f, 1f, 1.25f, 1.5f, 2f, 4f, 8f)
    val chips = ArrayList<TextView>()
    fun refreshChips(v: Float) {
        for ((i, t) in chips.withIndex()) t.background = rr(if (kotlin.math.abs(vals[i] - v) < 0.001f) green else 0xFF262626.toInt(), dpf(30))
    }
    fun apply(v: Float, fromSlider: Boolean) {
        val x = (Math.round(v * 20f) / 20f).coerceIn(0.25f, 8f)
        big.text = fmtSpeedX(x) + "x"
        if (!fromSlider) seek.progress = ((x - 0.25f) / 0.05f).toInt().coerceIn(0, 155)
        refreshChips(x)
        onChange(x)
    }
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) { if (u) apply(0.25f + v * 0.05f, true) }
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    })
    val grid = LinearLayout(this)
    grid.orientation = LinearLayout.VERTICAL
    for (r in 0 until 2) {
        val row = LinearLayout(this)
        for (k in 0 until 4) {
            val v = vals[r * 4 + k]
            val t = chip(fmtSpeedX(v) + "x", kotlin.math.abs(v - current) < 0.001f, green) { apply(v, false) }
            chips.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(5), dp(6), dp(5), dp(6)) })
        }
        grid.addView(row, LinearLayout.LayoutParams(-1, -2))
    }
    col.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

    if (land) root.addView(col, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.58f).toInt(), -2, Gravity.END or Gravity.CENTER_VERTICAL))
    else root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
    dlg.setContentView(root)
    dlg.show()
}

// ------------------------------------------------------------------ Equalizer panel (like the reference)

/** Dark equalizer sheet: ON switch, preset chips, vertical band sliders, Reverb, BassBooster, Virtualizer. */
fun Context.eqPanel(eq: Equalizer?, extras: FxExtras?, session: Int, pf: Prefs, onStateChange: () -> Unit = {}) {
    val green = 0xFF2DC76D.toInt()
    val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar)
    dlg.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0xFF262626.toInt()))
    dlg.window?.setLayout(-1, -1)
    val sv = android.widget.ScrollView(this)
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(16), dp(10), dp(16), dp(24))
    col.setBackgroundColor(0xFF262626.toInt())
    sv.addView(col)

    var on = pf.b("eq_on", true)
    fun applyOn() {
        try { eq?.setEnabled(on) } catch (e: Exception) {}
        try { extras?.bass?.setEnabled(on && pf.i("fx_bass", 0) > 0) } catch (e: Exception) {}
        try { extras?.virt?.setEnabled(on && pf.i("fx_virt", 0) > 0) } catch (e: Exception) {}
        try { extras?.rev?.setEnabled(on && pf.i("fx_rev", 0) > 0) } catch (e: Exception) {}
    }

    val top = LinearLayout(this)
    top.gravity = Gravity.CENTER_VERTICAL
    top.addView(iconBtn(Ic.BACK, Color.WHITE, 48, 26) { dlg.dismiss() })
    val tt = label("Equalizer", 22f, Color.WHITE, true)
    tt.setPadding(dp(6), 0, 0, 0)
    top.addView(tt, LinearLayout.LayoutParams(0, -2, 1f))
    top.addView(label(if (on) "ON" else "OFF", 20f, Color.WHITE, true).also { it.tag = "onoff" })
    val sw = MaterialSwitch(this)
    sw.isChecked = on
    sw.setOnCheckedChangeListener { _, v ->
        on = v; pf.put("eq_on", v); applyOn()
        (top.findViewWithTag<TextView>("onoff"))?.text = if (v) "ON" else "OFF"
        onStateChange()
    }
    top.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
    col.addView(top, LinearLayout.LayoutParams(-1, -2))

    if (eq == null) {
        col.addView(label("Equalizer is not available for this track yet. Start playing first.", 16f, 0xFFCCCCCC.toInt()).apply { setPadding(0, dp(20), 0, dp(20)) })
    } else {
        val e = eq
        val minL = e.bandLevelRange[0].toInt()
        val maxL = e.bandLevelRange[1].toInt()
        val nb = e.numberOfBands.toInt()
        val sliders = ArrayList<VSlider>()
        val presetChips = ArrayList<TextView>()
        val names = ArrayList<String>()
        names.add("Custom")
        for (i in 0 until e.numberOfPresets.toInt()) names.add(e.getPresetName(i.toShort()))
        var selected = pf.i("eq_preset", -1) + 1          // 0 = Custom

        fun paintChips() {
            for ((i, t) in presetChips.withIndex()) {
                val sel = i == selected
                t.background = if (sel) rr(green, dpf(24)) else rr(0, dpf(24), dp(2), 0xFFD0D0D0.toInt())
                t.setTextColor(Color.WHITE)
            }
        }
        val chipRow = LinearLayout(this)
        for ((i, n) in names.withIndex()) {
            val t = label(n, 17f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(22), dp(10), dp(22), dp(10))
            t.setOnClickListener {
                selected = i
                pf.put("eq_preset", i - 1)
                if (i > 0) {
                    try { e.usePreset((i - 1).toShort()); e.setEnabled(on) } catch (x: Exception) {}
                    for (b in 0 until nb) { val lv = e.getBandLevel(b.toShort()).toInt(); sliders[b].value = lv; pf.put("eq$b", lv) }
                }
                paintChips()
            }
            presetChips.add(t)
            chipRow.addView(t, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) })
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chipRow)
        col.addView(hs, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        paintChips()

        val bands = LinearLayout(this)
        bands.weightSum = nb.toFloat()
        for (b in 0 until nb) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            val s = VSlider(this)
            s.green = green; s.min = minL; s.max = maxL
            s.value = e.getBandLevel(b.toShort()).toInt()
            s.onChange = { v ->
                try { e.setBandLevel(b.toShort(), v.toShort()); e.setEnabled(on) } catch (x: Exception) {}
                pf.put("eq$b", v)
                if (selected != 0) { selected = 0; pf.put("eq_preset", -1); paintChips() }
            }
            sliders.add(s)
            cell.addView(s, LinearLayout.LayoutParams(dp(48), dp(190)))
            val hz = e.getCenterFreq(b.toShort()) / 1000
            cell.addView(label("${hz}Hz", 14f, Color.WHITE, true))
            bands.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(bands, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
    }

    // reverb dropdown
    val revNames = listOf("None", "Small room", "Medium room", "Large room", "Medium hall", "Large hall", "Plate")
    val revRow = LinearLayout(this)
    revRow.gravity = Gravity.CENTER_VERTICAL
    revRow.addView(label("Reverb", 19f, Color.WHITE, true))
    val revVal = label(revNames[pf.i("fx_rev", 0).coerceIn(0, 6)] + "  ▼", 19f, green, true)
    revVal.setPadding(dp(18), dp(8), dp(8), dp(8))
    revVal.setOnClickListener {
        val pm = PopupMenu(this, revVal)
        for ((i, n) in revNames.withIndex()) pm.menu.add(0, i, i, n)
        pm.setOnMenuItemClickListener { mi ->
            val v = mi.itemId
            pf.put("fx_rev", v)
            try { extras?.rev?.preset = v.toShort(); extras?.rev?.setEnabled(on && v > 0) } catch (x: Exception) {}
            revVal.text = revNames[v] + "  ▼"
            true
        }
        pm.show()
    }
    revRow.addView(revVal)
    col.addView(revRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

    col.addView(View(this).apply { setBackgroundColor(0xFF4A4A4A.toInt()) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(14); bottomMargin = dp(14) })

    fun strengthRow(name: String, key: String, apply: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(label(name, 19f, Color.WHITE, true))
        val sb = SeekBar(this)
        sb.max = 1000
        sb.progress = pf.i(key, 0)
        sb.progressTintList = android.content.res.ColorStateList.valueOf(green)
        sb.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFFD0D0D0.toInt())
        sb.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { if (u) { pf.put(key, v); apply(v) } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb, LinearLayout.LayoutParams(-1, dp(40)))
        return box
    }
    val two = LinearLayout(this)
    two.addView(strengthRow("BassBooster", "fx_bass") { v ->
        try { extras?.bass?.let { if (it.strengthSupported) it.setStrength(v.toShort()); it.setEnabled(on && v > 0) } } catch (x: Exception) {}
    }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(10) })
    two.addView(strengthRow("Virtualizer", "fx_virt") { v ->
        try { extras?.virt?.let { if (it.strengthSupported) it.setStrength(v.toShort()); it.setEnabled(on && v > 0) } } catch (x: Exception) {}
    }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
    col.addView(two, LinearLayout.LayoutParams(-1, -2))

    val more = label("Explore more equalizer settings  ›", 18f, Color.WHITE, true)
    more.gravity = Gravity.CENTER
    more.background = rr(0, dpf(32), dp(2), 0xFFD0D0D0.toInt())
    more.setOnClickListener {
        try {
            startActivity(
                Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
                    .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, session)
                    .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            )
        } catch (x: Exception) { toast("System equalizer is not available on this device") }
    }
    col.addView(more, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(24) })

    dlg.setContentView(sv)
    dlg.show()
}
