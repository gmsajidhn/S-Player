package com.sajid.splayer

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.Shader
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SweepGradient
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Size
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import kotlin.math.min
import kotlin.math.sqrt

class Track(val uri: String, val title: String, val artist: String, val album: String, val id: Long) {
    val shownArtist: String get() = if (artist.isEmpty()) "<unknown>" else artist
}

fun Item.toTrack() = Track(uri.toString(), title, artist, album, id)

/** MediaItem with title / artist, so the system media card shows the real name. */
fun Track.mediaItem(): MediaItem = MediaItem.Builder().setUri(uri)
    .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(title).setArtist(if (artist.isEmpty()) null else artist).build()).build()

object Art {
    fun file(c: Context, id: Long) = File(c.filesDir, "cover_$id.jpg")

    /** Custom cover (set in Edit tag) first, then the embedded/thumbnail art from MediaStore. */
    fun load(c: Context, uri: String, id: Long, size: Int): Bitmap? {
        try {
            if (id > 0) {
                val f = file(c, id)
                if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { return it }
            }
        } catch (e: Exception) {
        }
        try {
            val u = Uri.parse(uri)
            if (u.scheme == "content") return c.contentResolver.loadThumbnail(u, Size(size, size), null)
            if (u.scheme == "file") {
                val f = File(u.path ?: "")
                val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: ""
                return if (mime.startsWith("audio")) android.media.ThumbnailUtils.createAudioThumbnail(f, Size(size, size), null)
                else android.media.ThumbnailUtils.createVideoThumbnail(f, Size(size, size), null)
            }
        } catch (e: Exception) {
        }
        return null
    }
}

/** One app-wide audio player so music keeps playing when screens close. */
object AudioEngine {
    var player: ExoPlayer? = null
    var queue: List<Track> = emptyList()
    var stopAfterCurrent: Boolean = false

    /** 0 = play in order, 1 = repeat one, 2 = repeat all, 3 = stop after current, 4 = shuffle all */
    fun modeIndex(): Int {
        val p = player ?: return 0
        return when {
            stopAfterCurrent -> 3
            p.shuffleModeEnabled -> 4
            p.repeatMode == Player.REPEAT_MODE_ONE -> 1
            p.repeatMode == Player.REPEAT_MODE_ALL -> 2
            else -> 0
        }
    }
    val modeLabels = listOf("Play in Order", "Repeat One", "Repeat All", "Stop After Current Song", "Shuffle All")
    fun modePath(i: Int): String = when (i) {
        1 -> Ic.REPEAT_ONE
        2 -> Ic.REPEAT
        3 -> Ic.STOP_AFTER
        4 -> Ic.SHUFFLE
        else -> Ic.ORDER
    }
    /** Order -> Repeat one -> Repeat all -> Stop after current -> Shuffle all -> Order */
    fun cycleMode() {
        val p = player ?: return
        val next = (modeIndex() + 1) % 5
        app?.let { Prefs(it).modeA = next }
        stopAfterCurrent = next == 3
        p.pauseAtEndOfMediaItems = next == 3
        p.shuffleModeEnabled = next == 4
        p.repeatMode = when (next) { 1 -> Player.REPEAT_MODE_ONE; 2 -> Player.REPEAT_MODE_ALL; else -> Player.REPEAT_MODE_OFF }
    }
    val listeners = ArrayList<() -> Unit>()
    var eq: Equalizer? = null
    var loud: LoudnessEnhancer? = null
    var extras: FxExtras? = null
    var sys: SysMedia? = null
    var sysArt: Bitmap? = null
    private var sysUri = ""
    /** uptime (SystemClock.elapsedRealtime) when the sleep timer fires, 0 = off */
    var sleepEnd = 0L
    val sleepLeft: Long get() = if (sleepEnd == 0L) 0L else (sleepEnd - android.os.SystemClock.elapsedRealtime()).coerceAtLeast(0L)
    private var app: Context? = null
    private val h = Handler(Looper.getMainLooper())
    private val sleepRun = Runnable { sleepEnd = 0L; player?.pause(); fire() }

    val current: Track?
        get() { val p = player ?: return null; return queue.getOrNull(p.currentMediaItemIndex) }

    fun fire() { for (l in ArrayList(listeners)) l() }

    fun ensure(ctx: Context): ExoPlayer {
        player?.let { return it }
        val a = ctx.applicationContext
        app = a
        val p = ExoPlayer.Builder(a).build()
        p.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
        p.setHandleAudioBecomingNoisy(true)
        p.setWakeMode(C.WAKE_MODE_LOCAL)
        try { sys = SysMedia(a, "splayer_audio", p) } catch (e: Exception) {}
        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isPlaying && stopAfterCurrent && p.duration > 0L && p.currentPosition >= p.duration - 300L) {
                    p.pause()
                    stopAfterCurrent = false
                    p.pauseAtEndOfMediaItems = false
                }
                fire()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && stopAfterCurrent) {
                    p.pause()
                    stopAfterCurrent = false
                    p.pauseAtEndOfMediaItems = false
                }
                fire()
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                fire()
                syncSys(false)
                val t = current
                if (t != null && Prefs(a).broadcast) {
                    try { a.sendBroadcast(Intent("com.android.music.metachanged").putExtra("track", t.title).putExtra("playing", true)) } catch (e: Exception) {}
                }
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { setupFx(audioSessionId) }
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(a, "Cannot play this file (${error.errorCodeName})", Toast.LENGTH_SHORT).show()
            }
        })
        player = p
        return p
    }

    fun start(ctx: Context, list: List<Track>, idx: Int, startPos: Long = 0L, speed: Float = -1f) {
        if (list.isEmpty()) return
        val a = ctx.applicationContext
        val p = ensure(a)
        val prefs = Prefs(a)
        val sourceSignature = list.map { it.uri }.sorted().joinToString("\n")
        val savedSource = prefs.sp.getString("audio_queue_source", null)
        val savedOrder = prefs.sp.getString("audio_queue_order", null)?.split("\n")?.filter { it.isNotBlank() }
        val ordered = if (savedSource == sourceSignature && !savedOrder.isNullOrEmpty()) {
            savedOrder.mapNotNull { u -> list.firstOrNull { it.uri == u } }
        } else {
            prefs.put("audio_queue_source", sourceSignature)
            prefs.put("audio_queue_order", list.joinToString("\n") { it.uri })
            list
        }
        val selected = list.getOrNull(idx.coerceIn(0, list.size - 1))
        val startIndex = ordered.indexOfFirst { it.uri == selected?.uri }.coerceAtLeast(0)
        queue = ordered
        if (speed > 0f) p.setPlaybackSpeed(speed)
        // last used playback mode is restored
        val sm0 = prefs.modeA
        stopAfterCurrent = sm0 == 3
        p.pauseAtEndOfMediaItems = sm0 == 3
        p.shuffleModeEnabled = sm0 == 4
        p.repeatMode = when (sm0) { 1 -> Player.REPEAT_MODE_ONE; 2 -> Player.REPEAT_MODE_ALL; else -> Player.REPEAT_MODE_OFF }
        p.setMediaItems(ordered.map { it.mediaItem() }, startIndex, startPos)
        p.prepare()
        p.playWhenReady = true
        try { ContextCompat.startForegroundService(a, Intent(a, AudioService::class.java)) } catch (e: Exception) {}
        sys?.setActive(true)
        fire()
        syncSys(false)
    }

    /** Publish title / artist / cover of the current track to the Android system (media card, lock screen, Bluetooth). */
    fun syncSys(force: Boolean) {
        val s = sys ?: return
        val t = current ?: return
        if (!force && sysUri == t.uri) return
        sysUri = t.uri
        sysArt = null
        val who = if (t.id < 0L) "Video" else t.artist
        s.setInfo(t.title, who, null)
        val c = app ?: return
        Thread {
            val bm = try { Art.load(c, t.uri, t.id, 320) } catch (e: Throwable) { null }
            h.post {
                if (current?.uri == t.uri) {
                    sysArt = SysMedia.small(bm)
                    sys?.setInfo(t.title, who, sysArt)
                    fire()
                }
            }
        }.start()
    }


    /** Replace queue order while keeping the current track and playback position stable. */
    fun reorderQueue(ctx: Context, ordered: List<Track>) {
        val p = player ?: return
        if (ordered.isEmpty()) { stop(ctx); return }
        val current = current
        val position = p.currentPosition
        val wasPlaying = p.isPlaying
        val currentIndex = ordered.indexOfFirst { it.uri == current?.uri }
        val nextIndex = if (currentIndex >= 0) currentIndex else 0
        val resumeAt = if (currentIndex >= 0) position else 0L
        queue = ordered
        p.setMediaItems(ordered.map { it.mediaItem() }, nextIndex, resumeAt)
        p.prepare()
        p.playWhenReady = wasPlaying
        Prefs(ctx).put("audio_queue_order", ordered.joinToString("\n") { it.uri })
        fire()
    }

    fun stop(ctx: Context) {
        val a = ctx.applicationContext
        h.removeCallbacks(sleepRun)
        sleepEnd = 0L
        player?.stop()
        player?.clearMediaItems()
        queue = emptyList()
        sysUri = ""
        sysArt = null
        sys?.setActive(false)
        try { a.stopService(Intent(a, AudioService::class.java)) } catch (e: Exception) {}
        fire()
    }

    /** Append tracks to the end of the playing queue (starts playing them when nothing is playing). */
    fun addToQueue(ctx: Context, list: List<Track>) {
        if (list.isEmpty()) return
        val p = player
        if (p == null || queue.isEmpty()) { start(ctx, list, 0); return }
        val have = queue.map { it.uri }.toSet()
        val add = list.filter { it.uri !in have }
        if (add.isEmpty()) return
        queue = queue + add
        p.addMediaItems(add.map { it.mediaItem() })
        Prefs(ctx).put("audio_queue_order", queue.joinToString("\n") { it.uri })
        fire()
    }

    fun toggle() { val p = player ?: return; if (p.isPlaying) p.pause() else p.play() }

    fun setSleep(min: Int) {
        h.removeCallbacks(sleepRun)
        if (min > 0) { sleepEnd = android.os.SystemClock.elapsedRealtime() + min * 60000L; h.postDelayed(sleepRun, min * 60000L) }
        else sleepEnd = 0L
        fire()
    }

    fun updateTrack(id: Long, t: Track) { queue = queue.map { if (it.id == id) t else it }; fire(); syncSys(true) }

    fun removeCurrent(ctx: Context) {
        val p = player ?: return
        val i = p.currentMediaItemIndex
        if (i < 0 || i >= queue.size) return
        p.removeMediaItem(i)
        val l = queue.toMutableList()
        l.removeAt(i)
        queue = l
        if (queue.isEmpty()) stop(ctx) else fire()
    }

    private fun setupFx(id: Int) {
        try { eq?.release() } catch (e: Exception) {}
        try { loud?.release() } catch (e: Exception) {}
        extras?.release()
        eq = null
        loud = null
        extras = null
        val a = app ?: return
        val pf = Prefs(a)
        if (id == 0) return
        extras = FxExtras.create(id, pf)
        try {
            val e = Equalizer(0, id)
            for (bd in 0 until e.numberOfBands.toInt()) {
                val k = "eq$bd"
                if (pf.sp.contains(k)) e.setBandLevel(bd.toShort(), pf.i(k, 0).toShort())
            }
            e.setEnabled(pf.b("eq_on", true))
            applyBassFallback(e, extras, pf, pf.i("fx_bass", 0))
            eq = e
        } catch (e: Exception) {
        }
        try {
            val l = LoudnessEnhancer(id)
            l.setTargetGain(600)
            l.setEnabled(pf.smartVol)
            loud = l
        } catch (e: Exception) {
        }
    }
}

class AudioService : Service() {
    private val cb: () -> Unit = { refresh() }
    private var sm: SensorManager? = null

    private val shakeL = object : SensorEventListener {
        var last = 0L
        override fun onSensorChanged(e: SensorEvent) {
            val pf = Prefs(this@AudioService)
            if (!pf.shake) return
            val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / SensorManager.GRAVITY_EARTH
            val thr = 1.3f + pf.shakeForce / 100f * 1.7f
            val now = System.currentTimeMillis()
            val p = AudioEngine.player ?: return
            if (g > thr && now - last > 1000) {
                last = now
                when (pf.shakeAction) {
                    0 -> p.seekToNext()
                    1 -> p.seekToPrevious()
                    else -> if (p.isPlaying) p.pause() else p.play()
                }
            }
        }
        override fun onAccuracyChanged(s: Sensor?, acc: Int) {}
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("play", "Music playback", NotificationManager.IMPORTANCE_LOW))
        AudioEngine.listeners.add(cb)
        run {
            sm = getSystemService(SENSOR_SERVICE) as SensorManager
            val acc = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (acc != null) sm?.registerListener(shakeL, acc, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "prev" -> AudioEngine.player?.seekToPrevious()
            "toggle" -> AudioEngine.toggle()
            "next" -> AudioEngine.player?.seekToNext()
            "stop" -> { AudioEngine.stop(this); stopSelf(); return START_NOT_STICKY }
        }
        val n = build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
        return START_NOT_STICKY
    }

    private fun refresh() {
        if (AudioEngine.queue.isEmpty()) return
        try { getSystemService(NotificationManager::class.java).notify(1, build()) } catch (e: Exception) {}
    }

    private fun act(a: String, icon: Int, title: String): NotificationCompat.Action {
        val pi = PendingIntent.getService(this, a.hashCode(), Intent(this, AudioService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Action(icon, title, pi)
    }

    private fun build(): Notification {
        val t = AudioEngine.current
        val playing = AudioEngine.player?.isPlaying == true
        val open = PendingIntent.getActivity(this, 0, Intent(this, AudioPlayerActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val style = androidx.media.app.NotificationCompat.MediaStyle().setShowActionsInCompactView(0, 1, 2)
        AudioEngine.sys?.let { style.setMediaSession(it.session.sessionToken) }
        return NotificationCompat.Builder(this, "play")
            .setStyle(style)
            .setLargeIcon(AudioEngine.sysArt)
            .setShowWhen(false)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(t?.title ?: "Sajid Player")
            .setContentText(if (t != null && t.id < 0L) "Video" else (t?.shownArtist ?: ""))
            .setContentIntent(open)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .addAction(act("prev", android.R.drawable.ic_media_previous, "Previous"))
            .addAction(act("toggle", if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause"))
            .addAction(act("next", android.R.drawable.ic_media_next, "Next"))
            .addAction(act("stop", android.R.drawable.ic_menu_close_clear_cancel, "Close"))
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        AudioEngine.listeners.remove(cb)
        try { sm?.unregisterListener(shakeL) } catch (e: Exception) {}
    }
}

/** Album cover shown as one big, perfectly round picture. No disc, no tonearm, no rotation. */
/** Spinning vinyl record with the cover as its label, and a tone-arm that swings onto the record while playing. */
class CoverView(c: Context) : View(c) {
    var art: Bitmap? = null
        set(v) { field = v; invalidate() }
    var accent = 0xFF3F51B5.toInt()
    var bar = 0xFFE0DDD5.toInt()
    var playing = false
        set(v) { field = v; postInvalidateOnAnimation() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val matrix = Matrix()
    private val levels = FloatArray(96) { 0.14f }
    private var lastFeed = 0L
    private var phase = 0f
    private var last = 0L

    fun feed(fft: ByteArray) {
        val bins = fft.size / 2 - 1
        if (bins <= 0) return
        lastFeed = System.nanoTime()
        for (i in levels.indices) {
            // spread the lower ~60% of the spectrum around the ring, mirrored so left and right look alike
            val half = if (i < levels.size / 2) i else levels.size - 1 - i
            val k = 1 + half * (bins * 6 / 10) / (levels.size / 2)
            val re = fft[2 * k].toInt()
            val im = fft[2 * k + 1].toInt()
            val magnitude = kotlin.math.sqrt((re * re + im * im).toFloat()) / 128f
            levels[i] = maxOf(levels[i] * .72f, (magnitude * 1.8f).coerceIn(.08f, 1f))
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0f else ((now - last) / 1e9f).coerceAtMost(.1f)
        last = now
        val live = now - lastFeed < 400_000_000L
        if (playing) {
            phase += dt * 2.6f
            if (!live) {
                // no spectrum available (permission off): animate a soft pseudo-spectrum so the ring still moves
                for (i in levels.indices) {
                    val w = .5f + .5f * kotlin.math.sin(phase * 1.7f + i * .43f) * kotlin.math.sin(phase * .9f + i * .11f + 1.3f)
                    levels[i] = maxOf(levels[i] * .85f, .1f + w * .5f)
                }
            }
        } else for (i in levels.indices) levels[i] = maxOf(.1f, levels[i] * .94f)

        val cx = width / 2f
        val cy = height / 2f
        val radius = min(width * .33f, height * .34f)
        if (radius < 2f) return
        val d = resources.displayMetrics.density

        paint.style = Paint.Style.FILL
        paint.color = 0x33000000
        canvas.drawCircle(cx, cy + radius * .025f, radius * 1.12f, paint)
        paint.color = 0xFF121314.toInt()
        canvas.drawCircle(cx, cy, radius * .99f, paint)
        paint.color = 0xFF2A2C2E.toInt()
        canvas.drawCircle(cx, cy, radius * .90f, paint)
        paint.color = 0xFF0C0D0E.toInt()
        canvas.drawCircle(cx, cy, radius * .84f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * d
        paint.color = 0xFF3A3D40.toInt()
        canvas.drawCircle(cx, cy, radius * .91f, paint)
        paint.strokeWidth = 1f * d
        paint.color = 0xFF62666A.toInt()
        canvas.drawCircle(cx, cy, radius * .84f, paint)

        // Radial audio bars, like the reference player's circular spectrum.
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        for (i in levels.indices) {
            val angle = (Math.PI * 2.0 * i / levels.size - Math.PI / 2.0).toFloat()
            val idle = if (playing) .035f + .035f * kotlin.math.sin(phase * 2.1f + i * .31f) else 0f
            val amp = (levels[i] * .30f + idle) * radius
            val r0 = radius * 1.10f
            val r1 = r0 + maxOf(3f * d, amp)
            paint.strokeWidth = (2.4f * d).coerceAtLeast(1f)
            paint.color = if (playing) bar else androidx.core.graphics.ColorUtils.setAlphaComponent(bar, 0xB4)
            val x0 = cx + kotlin.math.cos(angle.toDouble()).toFloat() * r0
            val y0 = cy + kotlin.math.sin(angle.toDouble()).toFloat() * r0
            val x1 = cx + kotlin.math.cos(angle.toDouble()).toFloat() * r1
            val y1 = cy + kotlin.math.sin(angle.toDouble()).toFloat() * r1
            canvas.drawLine(x0, y0, x1, y1, paint)
        }

        val coverR = radius * .77f
        val bm = art
        paint.style = Paint.Style.FILL
        if (bm != null) {
            val scale = maxOf(coverR * 2 / bm.width, coverR * 2 / bm.height)
            val shader = BitmapShader(bm, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            matrix.reset()
            matrix.setScale(scale, scale)
            matrix.postTranslate(cx - bm.width * scale / 2f, cy - bm.height * scale / 2f)
            shader.setLocalMatrix(matrix)
            paint.shader = shader
            canvas.drawCircle(cx, cy, coverR, paint)
            paint.shader = null
        } else {
            paint.color = accent
            canvas.drawCircle(cx, cy, coverR, paint)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f * d
        paint.color = 0xFF202326.toInt()
        canvas.drawCircle(cx, cy, coverR, paint)
        if (playing) postInvalidateOnAnimation()
    }
}

class VisualizerView(c: Context) : View(c) {
    var mags = FloatArray(32)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAFFFFFF.toInt() }
    private val r = RectF()

    fun feed(fft: ByteArray) {
        val n = mags.size
        val bins = (fft.size / 2) - 1
        if (bins <= 0) return
        for (i in 0 until n) {
            val k = 1 + (i * bins / n)
            val re = fft[2 * k].toInt()
            val im = fft[2 * k + 1].toInt()
            val m = sqrt((re * re + im * im).toFloat()) / 128f
            mags[i] = maxOf(mags[i] * 0.7f, min(1f, m * 1.6f))
        }
        postInvalidate()
    }

    override fun onDraw(cv: Canvas) {
        val n = mags.size
        val bw = width.toFloat() / n
        for (i in 0 until n) {
            val h = maxOf(4f, mags[i] * height)
            r.set(i * bw + bw * 0.2f, height - h, (i + 1) * bw - bw * 0.2f, height.toFloat())
            cv.drawRoundRect(r, bw * 0.2f, bw * 0.2f, p)
        }
    }
}
