package com.sajid.splayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.view.MotionEvent
import android.view.View

/** One text or picture placed on the video. cx / cy = centre (0..1 of the video frame). */
class VOverlay(
    var text: String = "",
    var image: Bitmap? = null,
    var color: Int = Color.WHITE,
    var cx: Float = 0.5f,
    var cy: Float = 0.5f,
    var size: Float = 0.08f,      // text: fraction of frame height, picture: fraction of frame width
    var alpha: Float = 1f         // 0.1 .. 1  (how much of the picture / text is visible)
) {
    val isText: Boolean get() = image == null
    var cacheKey = ""
    var cacheBmp: Bitmap? = null
}

/** What the user chose in Video Edit besides the cut handles (read by the export). */
object VideoEditSpec {
    @Volatile var exclude = false                 // false = Include (keep the selection), true = Exclude (remove the selection)
    val overlays = ArrayList<VOverlay>()
    @Volatile var crop: FloatArray? = null        // left, top, right, bottom (0..1) or null = no crop
    fun active(): Boolean = exclude || overlays.isNotEmpty() || crop != null
    fun clearEdits() { overlays.clear(); crop = null }
}

object OverlayRender {
    fun text(o: VOverlay, frameH: Int): Bitmap {
        val px = maxOf(8f, o.size * frameH)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = px
        p.color = o.color
        p.typeface = Typeface.DEFAULT_BOLD
        p.setShadowLayer(px / 14f, 0f, 0f, 0xAA000000.toInt())
        val lines = o.text.split("\n")
        var w = 1f
        for (l in lines) w = maxOf(w, p.measureText(l))
        val lh = p.fontSpacing
        val pad = px / 5f
        val bw = Math.ceil((w + 2 * pad).toDouble()).toInt().coerceIn(2, 4096)
        val bh = Math.ceil((lh * lines.size + 2 * pad).toDouble()).toInt().coerceIn(2, 4096)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        for ((i, l) in lines.withIndex()) cv.drawText(l, pad, pad - p.fontMetrics.ascent + i * lh, p)
        return bmp
    }

    fun bitmapFor(o: VOverlay, frameW: Int, frameH: Int): Bitmap {
        val im = o.image
        if (im != null) {
            val w = maxOf(2, (o.size * frameW).toInt())
            val h = maxOf(2, (w.toFloat() * im.height / im.width).toInt())
            return Bitmap.createScaledBitmap(im, w, h, true)
        }
        return text(o, frameH)
    }

    /** Decodes a picture from the phone, at most `max` pixels on the long side. */
    fun decode(c: Context, u: Uri, max: Int = 1280): Bitmap? {
        return try {
            val o1 = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o1) }
            var s = 1
            while (maxOf(o1.outWidth, o1.outHeight) / s > max * 2) s *= 2
            val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = s }
            val b = c.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val long = maxOf(b.width, b.height)
            if (long > max) {
                val k = max.toFloat() / long
                Bitmap.createScaledBitmap(b, maxOf(1, (b.width * k).toInt()), maxOf(1, (b.height * k).toInt()), true)
            } else b
        } catch (e: Throwable) { null }
    }

    /** Frame size of the video as it is shown (rotation applied). */
    fun frameSize(c: Context, u: Uri): Pair<Int, Int> {
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(c, u)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (w > 0 && h > 0) return Pair(w, h)
        } catch (e: Throwable) {}
        return Pair(1280, 720)
    }

    /** Media3 video effects for the current VideoEditSpec: overlays first, then the crop. A fresh list for every clip. */
    fun videoEffects(c: Context, u: Uri): List<androidx.media3.common.Effect> {
        val out = ArrayList<androidx.media3.common.Effect>()
        val ovs = VideoEditSpec.overlays.toList()
        if (ovs.isNotEmpty()) {
            val (fw, fh) = frameSize(c, u)
            val list = ArrayList<androidx.media3.effect.TextureOverlay>()
            for (o in ovs) {
                val st = androidx.media3.effect.OverlaySettings.Builder()
                    .setBackgroundFrameAnchor(o.cx * 2f - 1f, 1f - o.cy * 2f)
                    .setAlphaScale(o.alpha.coerceIn(0.05f, 1f))
                    .build()
                list.add(androidx.media3.effect.BitmapOverlay.createStaticBitmapOverlay(bitmapFor(o, fw, fh), st))
            }
            out.add(androidx.media3.effect.OverlayEffect(com.google.common.collect.ImmutableList.copyOf(list)))
        }
        val cr = VideoEditSpec.crop
        if (cr != null) out.add(androidx.media3.effect.Crop(cr[0] * 2f - 1f, cr[2] * 2f - 1f, 1f - cr[3] * 2f, 1f - cr[1] * 2f))
        return out
    }
}

fun fitRect(vw: Int, vh: Int, w: Int, h: Int): RectF {
    if (vw <= 0 || vh <= 0 || w <= 0 || h <= 0) return RectF(0f, 0f, w.toFloat(), h.toFloat())
    val s = minOf(w.toFloat() / vw, h.toFloat() / vh)
    val rw = vw * s
    val rh = vh * s
    return RectF((w - rw) / 2f, (h - rh) / 2f, (w + rw) / 2f, (h + rh) / 2f)
}

/** Transparent layer above the video preview: shows the texts / pictures (drag to move, tap to edit) and the crop box. */
class EditOverlayView(c: Context, private val videoRect: () -> RectF) : View(c) {
    var cropMode = false
        set(v) { field = v; invalidate() }
    var current: VOverlay? = null
    var onTapOverlay: ((VOverlay) -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private var dragging: VOverlay? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var cropDrag = 0          // 1 left, 2 top, 4 right, 8 bottom, 16 whole box

    private fun bmpOf(o: VOverlay, r: RectF): Bitmap {
        val key = "${o.text}|${o.color}|${o.size}|${r.width().toInt()}|${r.height().toInt()}|${System.identityHashCode(o.image)}"
        val cb = o.cacheBmp
        if (cb != null && o.cacheKey == key) return cb
        val b = OverlayRender.bitmapFor(o, maxOf(2, r.width().toInt()), maxOf(2, r.height().toInt()))
        o.cacheKey = key
        o.cacheBmp = b
        return b
    }

    private fun boxOf(o: VOverlay, r: RectF): RectF {
        val b = bmpOf(o, r)
        val cx = r.left + o.cx * r.width()
        val cy = r.top + o.cy * r.height()
        return RectF(cx - b.width / 2f, cy - b.height / 2f, cx + b.width / 2f, cy + b.height / 2f)
    }

    override fun onDraw(cv: Canvas) {
        val r = videoRect()
        for (o in VideoEditSpec.overlays) {
            val box = boxOf(o, r)
            paint.alpha = (o.alpha * 255).toInt().coerceIn(20, 255)
            cv.drawBitmap(bmpOf(o, r), box.left, box.top, paint)
            paint.alpha = 255
            if (o === current && !cropMode) {
                paint.style = Paint.Style.STROKE
                paint.color = Color.WHITE
                paint.strokeWidth = 1.5f * d
                paint.pathEffect = DashPathEffect(floatArrayOf(6f * d, 4f * d), 0f)
                cv.drawRect(box, paint)
                paint.pathEffect = null
                paint.style = Paint.Style.FILL
            }
        }
        val cr = VideoEditSpec.crop
        if (cr != null || cropMode) {
            val c4 = cr ?: floatArrayOf(0f, 0f, 1f, 1f)
            val L = r.left + c4[0] * r.width()
            val T = r.top + c4[1] * r.height()
            val R = r.left + c4[2] * r.width()
            val B = r.top + c4[3] * r.height()
            paint.style = Paint.Style.FILL
            paint.color = if (cropMode) 0xAA000000.toInt() else 0x88000000.toInt()
            cv.drawRect(r.left, r.top, r.right, T, paint)
            cv.drawRect(r.left, B, r.right, r.bottom, paint)
            cv.drawRect(r.left, T, L, B, paint)
            cv.drawRect(R, T, r.right, B, paint)
            if (cropMode) {
                paint.style = Paint.Style.STROKE
                paint.color = Color.WHITE
                paint.strokeWidth = 2f * d
                cv.drawRect(L, T, R, B, paint)
                paint.strokeWidth = 0.8f * d
                paint.color = 0x88FFFFFF.toInt()
                cv.drawLine(L + (R - L) / 3, T, L + (R - L) / 3, B, paint)
                cv.drawLine(L + 2 * (R - L) / 3, T, L + 2 * (R - L) / 3, B, paint)
                cv.drawLine(L, T + (B - T) / 3, R, T + (B - T) / 3, paint)
                cv.drawLine(L, T + 2 * (B - T) / 3, R, T + 2 * (B - T) / 3, paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                for (px in floatArrayOf(L, R)) for (py in floatArrayOf(T, B)) cv.drawCircle(px, py, 7f * d, paint)
            }
        }
    }

    /** the item under (or very near) the finger; the closest one wins */
    private fun hitOverlay(x: Float, y: Float): VOverlay? {
        val r = videoRect()
        var best: VOverlay? = null
        var bestD = Float.MAX_VALUE
        for (o in VideoEditSpec.overlays) {
            val b = boxOf(o, r)
            b.inset(-40f * d, -40f * d)
            if (!b.contains(x, y)) continue
            val dd = Math.hypot((x - b.centerX()).toDouble(), (y - b.centerY()).toDouble()).toFloat()
            if (dd <= bestD) { bestD = dd; best = o }
        }
        return best
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // an item is being grabbed: the page (ScrollView) must not take over the drag
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && !cropMode && hitOverlay(ev.x, ev.y) != null) parent?.requestDisallowInterceptTouchEvent(true)
        return super.dispatchTouchEvent(ev)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val r = videoRect()
        if (r.width() <= 0f || r.height() <= 0f) return false
        if (cropMode) return cropTouch(e, r)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; moved = false
                dragging = hitOverlay(e.x, e.y)
                if (dragging == null) return false           // not on an item: let the video area behave as before
                current = dragging
                parent.requestDisallowInterceptTouchEvent(true)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val o = dragging ?: return false
                if (!moved && Math.hypot((e.x - downX).toDouble(), (e.y - downY).toDouble()) < 8 * d) return true
                moved = true
                o.cx = ((e.x - r.left) / r.width()).coerceIn(0f, 1f)
                o.cy = ((e.y - r.top) / r.height()).coerceIn(0f, 1f)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val o = dragging
                dragging = null
                parent.requestDisallowInterceptTouchEvent(false)
                if (o != null && !moved && e.actionMasked == MotionEvent.ACTION_UP) onTapOverlay?.invoke(o)
                return o != null
            }
        }
        return false
    }

    private fun cropTouch(e: MotionEvent, r: RectF): Boolean {
        val cr = VideoEditSpec.crop ?: floatArrayOf(0f, 0f, 1f, 1f).also { VideoEditSpec.crop = it }
        val L = r.left + cr[0] * r.width()
        val T = r.top + cr[1] * r.height()
        val R = r.left + cr[2] * r.width()
        val B = r.top + cr[3] * r.height()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = 30f * d
                var m = 0
                if (e.y in (T - hit)..(B + hit) && Math.abs(e.x - L) < hit) m = m or 1
                if (e.y in (T - hit)..(B + hit) && Math.abs(e.x - R) < hit) m = m or 4
                if (e.x in (L - hit)..(R + hit) && Math.abs(e.y - T) < hit) m = m or 2
                if (e.x in (L - hit)..(R + hit) && Math.abs(e.y - B) < hit) m = m or 8
                if (m == 0 && e.x in L..R && e.y in T..B) m = 16
                cropDrag = m
                lastX = e.x; lastY = e.y
                parent.requestDisallowInterceptTouchEvent(true)
                return m != 0
            }
            MotionEvent.ACTION_MOVE -> {
                if (cropDrag == 0) return false
                val dx = (e.x - lastX) / r.width()
                val dy = (e.y - lastY) / r.height()
                lastX = e.x; lastY = e.y
                val min = 0.1f
                if (cropDrag == 16) {
                    val w = cr[2] - cr[0]; val h = cr[3] - cr[1]
                    val nl = (cr[0] + dx).coerceIn(0f, 1f - w)
                    val nt = (cr[1] + dy).coerceIn(0f, 1f - h)
                    cr[0] = nl; cr[2] = nl + w; cr[1] = nt; cr[3] = nt + h
                } else {
                    if ((cropDrag and 1) != 0) cr[0] = (cr[0] + dx).coerceIn(0f, cr[2] - min)
                    if ((cropDrag and 4) != 0) cr[2] = (cr[2] + dx).coerceIn(cr[0] + min, 1f)
                    if ((cropDrag and 2) != 0) cr[1] = (cr[1] + dy).coerceIn(0f, cr[3] - min)
                    if ((cropDrag and 8) != 0) cr[3] = (cr[3] + dy).coerceIn(cr[1] + min, 1f)
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent.requestDisallowInterceptTouchEvent(false)
                val was = cropDrag != 0
                cropDrag = 0
                return was
            }
        }
        return false
    }
}
