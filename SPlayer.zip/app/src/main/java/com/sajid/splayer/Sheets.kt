package com.sajid.splayer

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class Act(
    val icon: String, val label: String, val danger: Boolean = false, val div: Boolean = false,
    val run: () -> Unit
)

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

private fun Context.divider(p: Pal): View {
    val v = View(this)
    v.setBackgroundColor(p.line)
    v.layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { marginStart = dp(20); marginEnd = dp(20) }
    return v
}

/** Bottom sheet. circle = true gives the rounded-icon look used for the audio menu. */
fun Context.sheet(p: Pal, head: View?, title: String, sub: String, acts: List<Act>, circle: Boolean = false) {
    val d = BottomSheetDialog(this)
    val r = dpf(28)
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.background = GradientDrawable().apply {
        setColor(if (circle && !p.dark) Color.WHITE else p.surface)
        cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
    }
    col.setPadding(0, 0, 0, dp(20))

    val bar = View(this)
    bar.background = rr(p.line, dpf(2))
    col.addView(bar, LinearLayout.LayoutParams(dp(if (circle) 40 else 32), dp(4)).apply {
        gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12); bottomMargin = dp(if (circle) 14 else 16)
    })

    val hr = LinearLayout(this)
    hr.gravity = Gravity.CENTER_VERTICAL
    hr.setPadding(dp(20), 0, dp(20), dp(if (circle) 14 else 16))
    val hs = if (circle) 48 else 64
    if (head != null) hr.addView(head, LinearLayout.LayoutParams(dp(hs), dp(hs)).apply { marginEnd = dp(16) })
    val tc = LinearLayout(this)
    tc.orientation = LinearLayout.VERTICAL
    val t1 = label(title, if (circle) 19f else 20f, p.text, true)
    t1.maxLines = 1
    t1.ellipsize = TextUtils.TruncateAt.END
    tc.addView(t1)
    if (sub.isNotEmpty()) {
        val t2 = label(sub, 15f, p.sub)
        t2.setPadding(0, dp(4), 0, 0)
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        tc.addView(t2)
    }
    hr.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
    col.addView(hr)
    col.addView(divider(p))

    for (a in acts) {
        if (a.div && !circle) col.addView(divider(p))
        val c = if (a.danger) p.danger else p.text
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(56)
        row.setPadding(dp(if (circle) 20 else 24), dp(if (circle) 6 else 0), dp(24), dp(if (circle) 6 else 0))
        row.background = ripple(null, 0f)
        if (circle) {
            val circ = FrameLayout(this)
            circ.background = rr(p.tile, dpf(22))
            val ic = ImageView(this)
            ic.setImageDrawable(PathIcon(a.icon, c))
            circ.addView(ic, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            row.addView(circ, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(20) })
        } else {
            val ic = ImageView(this)
            ic.setImageDrawable(PathIcon(a.icon, c))
            row.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(24) })
        }
        val tv = label(a.label, 17f, c)
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        row.setOnClickListener { d.dismiss(); a.run() }
        col.addView(row, LinearLayout.LayoutParams(-1, -2))
    }

    val sv = ScrollView(this)
    sv.addView(col)
    d.setContentView(sv)
    d.setOnShowListener {
        d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
        d.behavior.skipCollapsed = true
        d.behavior.state = BottomSheetBehavior.STATE_EXPANDED
    }
    d.show()
}

/** Sleep timer for music (pauses playback after the chosen time). */
fun Context.sleepTimerDialog() {
    val m = intArrayOf(0, 15, 30, 45, 60, 90)
    choose("Sleep timer", m.map { if (it == 0) "Off" else "$it minutes" } + "Custom…", -1) {
        if (it == m.size) {
            askNumber("Custom sleep timer", "Enter minutes (1 – 1440)", "", false) { v ->
                val mm = v.toInt()
                if (v !in 1.0..1440.0) {
                    toast("Enter a duration from 1 to 1440 minutes")
                } else {
                    AudioEngine.setSleep(mm)
                    toast("Music will pause in $mm min")
                }
            }
        } else {
            AudioEngine.setSleep(m[it])
            toast(if (m[it] > 0) "Music will pause in ${m[it]} min" else "Timer off")
        }
    }
}

fun Context.setRingtone(uri: String) {
    if (!android.provider.Settings.System.canWrite(this)) {
        toast("Allow \"Modify system settings\" for S Player")
        try {
            startActivity(
                android.content.Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS)
                    .setData(android.net.Uri.parse("package:$packageName")).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
        return
    }
    try {
        android.media.RingtoneManager.setActualDefaultRingtoneUri(this, android.media.RingtoneManager.TYPE_RINGTONE, android.net.Uri.parse(uri))
        toast("Ringtone set")
    } catch (e: Exception) {
        toast("Cannot set ringtone")
    }
}

fun Context.ask(title: String, hint: String, init: String, pw: Boolean = false, ok: (String) -> Unit) {
    val til = TextInputLayout(this)
    til.hint = hint
    val et = TextInputEditText(til.context)
    et.setText(init)
    if (pw) et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    til.addView(et)
    val box = FrameLayout(this)
    box.setPadding(dp(24), dp(8), dp(24), 0)
    box.addView(til)
    MaterialAlertDialogBuilder(this).setTitle(title).setView(box)
        .setPositiveButton("OK") { _, _ -> ok(et.text.toString()) }
        .setNegativeButton("Cancel", null).show()
}

fun Context.askNumber(title: String, hint: String, init: String, decimal: Boolean, ok: (Double) -> Unit) {
    val til = TextInputLayout(this)
    til.hint = hint
    val et = TextInputEditText(til.context)
    et.setText(init)
    et.inputType = InputType.TYPE_CLASS_NUMBER or (if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
    til.addView(et)
    val box = FrameLayout(this)
    box.setPadding(dp(24), dp(8), dp(24), 0)
    box.addView(til)
    MaterialAlertDialogBuilder(this).setTitle(title).setView(box)
        .setPositiveButton("OK") { _, _ ->
            val v = et.text.toString().trim().toDoubleOrNull()
            if (v == null) toast("Enter a number") else ok(v)
        }
        .setNegativeButton("Cancel", null).show()
}

fun Context.choose(title: String, items: List<String>, checked: Int, cb: (Int) -> Unit) {
    MaterialAlertDialogBuilder(this).setTitle(title)
        .setSingleChoiceItems(items.toTypedArray(), checked) { dlg, which -> dlg.dismiss(); cb(which) }
        .setNegativeButton("Cancel", null).show()
}

fun Context.message(title: String, msg: String) {
    MaterialAlertDialogBuilder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
}

fun Context.swatches(title: String, cols: IntArray, cur: Int, cb: (Int) -> Unit) {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(18), dp(8), dp(18), 0)
    var dlg: androidx.appcompat.app.AlertDialog? = null
    var row: LinearLayout? = null
    cols.forEachIndexed { i, c ->
        if (i % 4 == 0) {
            row = LinearLayout(this)
            box.addView(row)
        }
        val v = FrameLayout(this)
        v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
        if (c == cur) {
            val ck = ImageView(this)
            ck.setImageDrawable(PathIcon(Ic.CHECK, Color.WHITE))
            v.addView(ck, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        }
        v.setOnClickListener { cb(c); dlg?.dismiss() }
        row!!.addView(v, LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
    }
    val custom = label("Custom colour  ＋", 16f, 0xFF3F51B5.toInt(), true).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(14), 0, dp(10))
        setOnClickListener {
            val input = android.widget.EditText(this@swatches).apply {
                hint = "#RRGGBB"; setSingleLine(true); setText(String.format("#%06X", 0xFFFFFF and cur))
                inputType = android.text.InputType.TYPE_CLASS_TEXT
            }
            MaterialAlertDialogBuilder(this@swatches).setTitle("Custom primary colour").setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Apply") { _, _ ->
                    try {
                        val raw = input.text.toString().trim().removePrefix("#")
                        val parsed = android.graphics.Color.parseColor("#" + raw)
                        cb(parsed)
                        dlg?.dismiss()
                    } catch (_: Exception) { toast("Enter a valid hex colour") }
                }.show()
        }
    }
    box.addView(custom)
    dlg = MaterialAlertDialogBuilder(this).setTitle(title).setView(box).setNegativeButton("Cancel", null).show()
}
