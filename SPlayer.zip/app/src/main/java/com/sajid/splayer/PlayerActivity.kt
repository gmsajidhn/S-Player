package com.sajid.splayer

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.os.Build
import android.widget.CheckBox
import android.widget.ScrollView
import android.widget.PopupWindow
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil
import androidx.media3.exoplayer.video.MediaCodecVideoRenderer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

class PlayerActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var p: ExoPlayer
    lateinit var pv: PlayerView
    lateinit var root: FrameLayout
    lateinit var topPanel: LinearLayout
    lateinit var botPanel: LinearLayout
    lateinit var toolsRow: LinearLayout
    lateinit var rotBtn: ImageView
    lateinit var rotRow: LinearLayout
    var unlockShown = false
    lateinit var flashTxt: TextView
    lateinit var seekFxL: SeekFx
    lateinit var seekFxR: SeekFx
    lateinit var sleepChip: TextView
    lateinit var sleepIc: PathIcon
    var sleepEnd = 0L
    var holdActive = false
    var holdPrevSpeed = 1f
    var dtSum = 0
    var dtLast = 0L
    var dtFwd = true
    lateinit var titleTxt: TextView
    lateinit var curTxt: TextView
    lateinit var durTxt: TextView
    lateinit var seek: SeekBar
    lateinit var edgeSeek: SeekBar
    lateinit var playIc: PathIcon
    var stopAfterCurrent = false
    lateinit var lockBtn: ImageView
    lateinit var gd: GestureDetector
    lateinit var am: AudioManager
    var uris: List<String> = emptyList()
    var names: List<String> = emptyList()
    var isVideo = true
    var locked = false
    var shown = true
    var muted = false
    var night = false
    var flipped = false
    var inPip = false
    var userSeeking = false
    var expanded = false
    var a = -1L
    var b = -1L
    var resizeIdx = 0
    var savedBright = -1f
    var cBright = 0
    var cContrast = 100
    var cSat = 100
    var msess: SysMedia? = null
    var vArt: android.graphics.Bitmap? = null
    var vArtUri = ""
    var notifOff = false
    fun bindSession() {
        try { msess?.release() } catch (e: Exception) {}
        msess = try { SysMedia(this, "splayer_video", p) } catch (e: Exception) { null }
        vArtUri = ""
        postVideoNotif()
    }

    /** Notification + system media session: the video shows in the phone's media card (Control Center) with play / pause / next / previous. */
    fun postVideoNotif() {
        if (notifOff || !::p.isInitialized || uris.isEmpty()) return
        try {
            val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
            val name = names.getOrElse(i) { "" }.substringBeforeLast('.')
            val who = if (isVideo) "Video" else ""
            msess?.setInfo(name, who, vArt)
            msess?.setActive(true)
            if (vArtUri != uris[i]) {
                val u = uris[i]
                vArtUri = u
                vArt = null
                Thread {
                    val bm = try { Art.load(this, u, -1L, 320) } catch (e: Throwable) { null }
                    runOnUiThread { if (vArtUri == u && !isDestroyed) { vArt = SysMedia.small(bm); postVideoNotif() } }
                }.start()
            }
            val nm = getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(android.app.NotificationChannel("vplay", "Video playback", android.app.NotificationManager.IMPORTANCE_LOW))
            val playing = p.isPlaying
            fun act(a: String, icon: Int, t: String): androidx.core.app.NotificationCompat.Action {
                val pi = android.app.PendingIntent.getBroadcast(
                    this, a.hashCode(), Intent(a).setPackage(packageName),
                    android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
                )
                return androidx.core.app.NotificationCompat.Action(icon, t, pi)
            }
            val open = android.app.PendingIntent.getActivity(
                this, 0, Intent(this, PlayerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            )
            val style = androidx.media.app.NotificationCompat.MediaStyle().setShowActionsInCompactView(0, 1, 2)
            msess?.let { style.setMediaSession(it.session.sessionToken) }
            val n = androidx.core.app.NotificationCompat.Builder(this, "vplay")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(name)
                .setContentText(who)
                .setLargeIcon(vArt)
                .setContentIntent(open)
                .setOngoing(playing)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC)
                .setCategory(android.app.Notification.CATEGORY_TRANSPORT)
                .setStyle(style)
                .addAction(act(SysMedia.A_PREV, android.R.drawable.ic_media_previous, "Previous"))
                .addAction(act(SysMedia.A_TOGGLE, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause"))
                .addAction(act(SysMedia.A_NEXT, android.R.drawable.ic_media_next, "Next"))
                .build()
            nm.notify(2, n)
        } catch (e: Exception) {
        }
    }

    fun cancelVideoNotif() {
        try { getSystemService(android.app.NotificationManager::class.java).cancel(2) } catch (e: Exception) {}
        msess?.setActive(false)
    }

    val vRecv = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context?, i: Intent?) {
            if (!::p.isInitialized) return
            when (i?.action) {
                SysMedia.A_PREV -> p.seekToPrevious()
                SysMedia.A_TOGGLE -> if (p.isPlaying) p.pause() else p.play()
                SysMedia.A_NEXT -> p.seekToNext()
            }
        }
    }
    var eq: Equalizer? = null
    var loud: LoudnessEnhancer? = null
    var extras: FxExtras? = null
    var sm: SensorManager? = null
    var ticks = 0
    var lastFlashUpdate = 0L
    var gMode = 0
    var gStartPos = 0L
    var gTarget = 0L
    var gStartB = 0.5f
    var gStartV = 0
    var gStartVF = 0f
    var trackIdx = -1
    var trackPos = 0L
    var trackDur = 0L
    val toolViews = ArrayList<View>()
    val toolLabels = ArrayList<TextView>()
    val h = Handler(Looper.getMainLooper())

    val autoHide = Runnable { if (isVideo && p.isPlaying && !locked) show(false) }
    val hideFlash = Runnable { flashTxt.visibility = View.GONE }
    val hideUnlock = Runnable { if (locked) { unlockShown = false; botPanel.visibility = View.GONE } }
    val sleepRun = Runnable { sleepEnd = 0L; p.pause(); finish() }

    val tick = object : Runnable {
        override fun run() {
            val d = maxOf(p.duration, 0L)
            val c = p.currentPosition
            trackIdx = p.currentMediaItemIndex
            trackPos = c
            trackDur = d
            if (a >= 0 && b > a && c >= b) p.seekTo(a)
            if (!userSeeking) {
                seek.max = d.toInt()
                seek.progress = c.toInt()
                edgeSeek.max = d.toInt()
                edgeSeek.progress = c.toInt()
                curTxt.text = Media.time(c)
            }
            durTxt.text = Media.time(d)
            ticks++
            updateSleepChip()
            if (ticks % 16 == 0) savePos()
            h.postDelayed(this, 300)
        }
    }

    val shakeL = object : SensorEventListener {
        var last = 0L
        override fun onSensorChanged(e: SensorEvent) {
            val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / SensorManager.GRAVITY_EARTH
            val thr = 1.3f + pf.shakeForce / 100f * 1.7f
            val now = System.currentTimeMillis()
            if (g > thr && now - last > 1000) {
                last = now
                when (pf.shakeAction) {
                    0 -> p.seekToNext()
                    1 -> p.seekToPrevious()
                    else -> if (p.isPlaying) p.pause() else p.play()
                }
            }
        }
        override fun onAccuracyChanged(s: Sensor?, acc: Int) {}
    }

    fun lp(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)

    val plListener = object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { setupFx(audioSessionId) }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && stopAfterCurrent) {
                    p.pause()
                    stopAfterCurrent = false
                    p.pauseAtEndOfMediaItems = !pf.auto
                                flash("Stopped after current item")
                }
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (isVideo && pf.orient == 3 && videoSize.width > 0) {
                    requestedOrientation = if (videoSize.width >= videoSize.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                }
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // remember where the previous video was left
                if (trackIdx in uris.indices && trackIdx != p.currentMediaItemIndex) saveAt(trackIdx, trackPos, trackDur)
                onTrack()
                // continue the new video from where it was left last time
                if (pf.resume && (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK)) {
                    val ni = p.currentMediaItemIndex
                    if (ni in uris.indices) {
                        val sv = pf.sp.getLong("pos_" + uris[ni], 0L)
                        if (sv > 0L) { p.seekTo(sv); flash("Resumed from " + Media.time(sv)) }
                    }
                }
                trackIdx = p.currentMediaItemIndex
                trackPos = 0L
                postVideoNotif()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playIc.set(if (isPlaying) Ic.PAUSE else Ic.PLAY)
                postVideoNotif()
                if (!isPlaying && stopAfterCurrent && p.duration > 0L && p.currentPosition >= p.duration - 300L) {
                    p.pause()
                    stopAfterCurrent = false
                    p.pauseAtEndOfMediaItems = !pf.auto
                                flash("Stopped after current item")
                }
                if (isPlaying) show(shown)
            }
            override fun onPlayerError(error: PlaybackException) { toast("Cannot play this file (${error.errorCodeName})") }
            }


    // ------------------------------------------------------------------ setup
    override fun onCreate(s: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(s)
        pal = Pal(pf.dark, pf.accent)
        isVideo = intent.getBooleanExtra("v", true)
        uris = intent.getStringArrayListExtra("u") ?: arrayListOf()
        names = intent.getStringArrayListExtra("n") ?: arrayListOf()
        val data = intent.data
        if (uris.isEmpty() && data != null) {
            uris = listOf(data.toString())
            names = listOf(nameOf(data))
            val ty = intent.type ?: try { contentResolver.getType(data) } catch (e: Exception) { null }
            val nm = names.firstOrNull()?.lowercase() ?: ""
            val audioExt = listOf(".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg", ".opus", ".wma", ".amr", ".mka")
            isVideo = if (ty != null && ty.startsWith("audio")) false else if (ty != null && ty.startsWith("video")) true else audioExt.none { nm.endsWith(it) }
        }
        if (uris.isEmpty()) { finish(); return }
        if (!isVideo) {
            // audio now plays in the dedicated audio screen
            val ix = intent.getIntExtra("i", 0).coerceIn(0, uris.size - 1)
            AudioEngine.start(this, uris.mapIndexed { i, u -> Track(u, names.getOrElse(i) { "" }.substringBeforeLast('.'), "", "", -1L) }, ix)
            startActivity(Intent(this, AudioPlayerActivity::class.java))
            finish()
            return
        }
        am = getSystemService(AUDIO_SERVICE) as AudioManager

        if (isVideo) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.attributes = window.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val wc = WindowInsetsControllerCompat(window, window.decorView)
        wc.isAppearanceLightStatusBars = false
        wc.isAppearanceLightNavigationBars = false
        if (isVideo) {
            wc.hide(WindowInsetsCompat.Type.systemBars())
            wc.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            requestedOrientation = when (pf.orient) {
                1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            }
        }

        val idx = intent.getIntExtra("i", 0).coerceIn(0, uris.size - 1)
        if (isVideo && uris.none { it.contains("/vault/") }) { pf.lastQ = uris; pf.lastQN = names }
        p = makePlayer()
        p.setHandleAudioBecomingNoisy(true)
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(if (isVideo) C.AUDIO_CONTENT_TYPE_MOVIE else C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
        )
        p.setWakeMode(C.WAKE_MODE_LOCAL)
        val pos = if (intent.hasExtra("pos")) intent.getLongExtra("pos", 0L)
        else if (pf.resume) pf.sp.getLong("pos_" + uris[idx], 0L) else 0L
        p.setMediaItems(uris.map { MediaItem.fromUri(it) }, idx, pos)
        p.pauseAtEndOfMediaItems = !pf.auto

        buildUi()
        pv.player = p
        try {
            androidx.core.content.ContextCompat.registerReceiver(
                this, vRecv,
                android.content.IntentFilter().apply { addAction(SysMedia.A_PREV); addAction(SysMedia.A_TOGGLE); addAction(SysMedia.A_NEXT) },
                androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) {}
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)
        }
        bindSession()
        p.addListener(plListener)
        p.prepare()
        p.playWhenReady = intent.getBooleanExtra("play", true)
        trackIdx = idx
        onTrack()
        h.post(tick)
        if (isVideo && pos > 3000L) flash("Resumed from " + Media.time(pos))

        if (pf.shake) {
            sm = getSystemService(SENSOR_SERVICE) as SensorManager
            val acc = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (acc != null) sm?.registerListener(shakeL, acc, SensorManager.SENSOR_DELAY_UI)
        }
        if (intent.getBooleanExtra("pip", false)) { show(false); root.post { enterPip() } }
    }

    fun swFactory(): RenderersFactory {
        val sel = MediaCodecSelector { mime, secure, tunneling ->
            val l = MediaCodecUtil.getDecoderInfos(mime, secure, tunneling)
            l.sortedBy { if (it.softwareOnly) 0 else if (it.hardwareAccelerated) 2 else 1 }
        }
        return RenderersFactory { handler, videoL, audioL, _, _ ->
            arrayOf<Renderer>(
                MediaCodecVideoRenderer(this, sel, 5000L, handler, videoL, 50),
                MediaCodecAudioRenderer(this, sel, handler, audioL)
            )
        }
    }

    fun makePlayer(): ExoPlayer {
        val x = if (pf.decoder == 1) ExoPlayer.Builder(this, swFactory()).build() else ExoPlayer.Builder(this).build()
        // Keyframe-aligned seeking avoids expensive frame-by-frame decoding on rapid double taps.
        x.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        x.setHandleAudioBecomingNoisy(true)
        x.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
        x.setWakeMode(C.WAKE_MODE_LOCAL)
        return x
    }

    fun rebuildPlayer() {
        val i = p.currentMediaItemIndex
        val pos = p.currentPosition
        val play = p.playWhenReady
        val rm = p.repeatMode
        val shuffle = p.shuffleModeEnabled
        val spd = p.playbackParameters.speed
        p.removeListener(plListener)
        try { msess?.release() } catch (e: Exception) {}
        msess = null
        p.release()
        p = makePlayer()
        p.setMediaItems(uris.map { MediaItem.fromUri(it) }, i, pos)
        p.pauseAtEndOfMediaItems = stopAfterCurrent || (!pf.auto && rm == Player.REPEAT_MODE_OFF && !shuffle)
        p.repeatMode = rm
        p.shuffleModeEnabled = shuffle
        p.setPlaybackSpeed(spd)
        pv.player = p
        p.addListener(plListener)
        p.prepare()
        p.playWhenReady = play
        bindSession()
    }

    fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "video"
            }
        } catch (e: Exception) {
        }
        return u.lastPathSegment ?: "video"
    }

    fun onTrack() {
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val n = names.getOrElse(i) { "" }
        titleTxt.text = n
        if (!uris[i].contains("/vault/")) {
            pf.lastUri = uris[i]
            pf.lastName = n
            pf.lastVideo = isVideo
        }
        a = -1L
        b = -1L
        if (!isVideo && pf.broadcast) {
            try { sendBroadcast(Intent("com.android.music.metachanged").putExtra("track", n).putExtra("playing", true)) } catch (e: Exception) {}
        }
    }

    // ------------------------------------------------------------------ ui
    fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = layoutInflater.inflate(R.layout.view_player, root, false) as PlayerView
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        if (!isVideo) {
            val art = FrameLayout(this)
            art.background = rr(pal.accent and 0x00FFFFFF or 0x33000000, dpf(40))
            val ic = ImageView(this)
            ic.setImageDrawable(PathIcon(Ic.MUSIC, pal.bright))
            art.addView(ic, FrameLayout.LayoutParams(dp(96), dp(96), Gravity.CENTER))
            root.addView(art, FrameLayout.LayoutParams(dp(200), dp(200), Gravity.CENTER))
        }

        // ---- top panel: back / title / queue / more, then a small row of quick tools
        topPanel = LinearLayout(this)
        topPanel.orientation = LinearLayout.VERTICAL
        topPanel.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0))
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(iconBtn(Ic.BACK, Color.WHITE, 48, 26) { finishUp() })
        titleTxt = label("", 17f, Color.WHITE, true)
        titleTxt.maxLines = 1
        titleTxt.ellipsize = android.text.TextUtils.TruncateAt.END
        titleTxt.setPadding(dp(8), 0, dp(8), 0)
        bar.addView(titleTxt, lp(0, -2, 1f))
        // remaining sleep-timer time, shown inside a small timer badge while the timer runs
        sleepChip = label("", 13f, Color.WHITE, true)
        sleepChip.gravity = Gravity.CENTER
        sleepChip.setPadding(dp(8), dp(4), dp(10), dp(4))
        sleepChip.compoundDrawablePadding = dp(4)
        sleepIc = PathIcon(Ic.TIMER, Color.WHITE)
        sleepChip.setCompoundDrawables(sleepIc, null, null, null)
        sleepChip.setOnClickListener { timerDialog() }
        bar.addView(sleepChip, lp(-2, -2))
        updateSleepChip()
        bar.addView(iconBtn(Ic.QUEUE, Color.WHITE, 48, 24) { queueSheet() })
        val more = iconBtn(Ic.MORE, Color.WHITE, 48, 24) {}
        more.setOnClickListener { moreMenu(more) }
        bar.addView(more)
        topPanel.addView(bar)

        root.addView(topPanel, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- bottom panel
        botPanel = LinearLayout(this)
        botPanel.orientation = LinearLayout.VERTICAL
        botPanel.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xDD000000.toInt(), 0))
        // lock sits right above the current time (left), rotation right above the total time (right)
        rotRow = LinearLayout(this)
        rotRow.gravity = Gravity.CENTER_VERTICAL
        lockBtn = iconBtn(Ic.LOCK, Color.WHITE, 44, 24) { onLockTap() }
        lockBtn.background = ring(44)
        rotRow.addView(lockBtn)
        rotRow.addView(View(this), lp(0, 1, 1f))
        rotBtn = iconBtn(Ic.ROTATE, Color.WHITE, 44, 24) { rotate() }
        rotBtn.background = ring(44)
        rotRow.addView(rotBtn)
        botPanel.addView(rotRow)
        val tl = LinearLayout(this)
        tl.setPadding(dp(4), 0, dp(4), 0)
        curTxt = label("0:00", 14f, Color.WHITE, true)
        durTxt = label("0:00", 14f, 0xCCFFFFFF.toInt(), true)
        tl.addView(curTxt, lp(0, -2, 1f))
        tl.addView(durTxt)
        botPanel.addView(tl)
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(pal.bright)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) { if (u) { p.seekTo(v.toLong()); curTxt.text = Media.time(v.toLong()) } }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true; h.removeCallbacks(autoHide) }
            override fun onStopTrackingTouch(sb: SeekBar?) { userSeeking = false; show(true) }
        })
        botPanel.addView(seek, lp(-1, dp(32)))

        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER_VERTICAL
        playIc = PathIcon(Ic.PLAY, Color.WHITE)
        val playBtn = ImageView(this)
        playBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        playBtn.setImageDrawable(playIc)
        playBtn.background = ripple(null, dpf(28))
        playBtn.setOnClickListener {
            if (p.isPlaying) p.pause() else { if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L); p.play() }
        }
        ctl.addView(playBtn, lp(dp(56), dp(56)))
        ctl.addView(iconBtn(Ic.NEXT, Color.WHITE, 48, 28) { p.seekToNext() })
        ctl.addView(iconBtn(Ic.PREV, Color.WHITE, 48, 28) { p.seekToPrevious() })
        ctl.addView(View(this), lp(0, 1, 1f))
        ctl.addView(iconBtn(Ic.SPEED, Color.WHITE, 48, 26) { speedDialog() })
        ctl.addView(iconBtn(Ic.PIP, Color.WHITE, 48, 26) { popup() })
        ctl.addView(iconBtn(Ic.FIT, Color.WHITE, 48, 26) { cycleFit() })
        botPanel.addView(ctl)
        root.addView(botPanel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // Slim progress line stays visible while the playback controls auto-hide.
        edgeSeek = SeekBar(this)
        edgeSeek.max = 1000
        edgeSeek.progressTintList = ColorStateList.valueOf(pal.bright)
        edgeSeek.progressBackgroundTintList = ColorStateList.valueOf(0x66FFFFFF)
        edgeSeek.thumbTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        edgeSeek.setPadding(0, 0, 0, 0)
        edgeSeek.visibility = View.GONE
        edgeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                if (fromUser) { p.seekTo(v.toLong()); curTxt.text = Media.time(v.toLong()) }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true; h.removeCallbacks(autoHide) }
            override fun onStopTrackingTouch(sb: SeekBar?) { userSeeking = false; show(false) }
        })
        root.addView(edgeSeek, FrameLayout.LayoutParams(-1, dp(18), Gravity.BOTTOM).apply {
            leftMargin = dp(10); rightMargin = dp(10); bottomMargin = 0
        })

        flashTxt = label("", 18f, Color.WHITE, true)
        flashTxt.setPadding(dp(20), dp(10), dp(20), dp(10))
        flashTxt.background = rr(0xCC000000.toInt(), dpf(14))
        flashTxt.visibility = View.GONE
        root.addView(flashTxt, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(90) })
        seekFxL = SeekFx(this, false)
        seekFxR = SeekFx(this, true)
        root.addView(seekFxL, FrameLayout.LayoutParams(0, 0, Gravity.START or Gravity.CENTER_VERTICAL))
        root.addView(seekFxR, FrameLayout.LayoutParams(0, 0, Gravity.END or Gravity.CENTER_VERTICAL))
        // compact round bubble (square view): never stretched tall, same size in portrait and landscape
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val bw = minOf((r - l) / 3, (b - t) / 2, dp(190))
            val bh = bw
            for (v in arrayOf<View>(seekFxL, seekFxR)) {
                val lpp = v.layoutParams
                if (lpp.width != bw || lpp.height != bh) { lpp.width = bw; lpp.height = bh; v.layoutParams = lpp }
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            // same spacing in portrait and landscape; notch / cut-out and bars are respected on every side
            val i = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topPanel.setPadding(dp(8) + i.left, dp(4) + i.top, dp(8) + i.right, dp(24))
            botPanel.setPadding(dp(12) + i.left, dp(24), dp(12) + i.right, dp(8) + i.bottom)
            ins
        }
        topPanel.setPadding(dp(8), dp(4), dp(8), dp(24))
        botPanel.setPadding(dp(12), dp(24), dp(12), dp(8))

        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) showUnlock() else show(!shown || !isVideo)
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val third = root.width / 3f
                if (e.x > third && e.x < third * 2f) {
                    if (p.isPlaying) p.pause() else {
                        if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
                        p.play()
                    }
                    return true
                }
                val fwd = e.x > root.width / 2f
                val from = p.currentPosition
                val target = (from + if (fwd) 10_000L else -10_000L)
                    .coerceIn(0L, maxOf(p.duration, 0L))
                p.seekTo(target)
                // quick repeated double taps add up: +10s, +20s, +30s ...
                val now = android.os.SystemClock.uptimeMillis()
                if (fwd != dtFwd || now - dtLast > 900L) dtSum = 0
                dtFwd = fwd
                dtLast = now
                dtSum += (kotlin.math.abs(target - from) / 1000L).toInt()
                (if (fwd) seekFxR else seekFxL).show(dtSum)
                (if (fwd) seekFxL else seekFxR).visibility = View.GONE
                return true
            }
            override fun onLongPress(e: MotionEvent) {
                if (locked || inPip || !isVideo || gMode != 0 || holdActive) return
                holdActive = true
                holdPrevSpeed = p.playbackParameters.speed
                p.setPlaybackSpeed(pf.holdSpeed)
                h.removeCallbacks(hideFlash)
                flashTxt.text = "▶▶  " + fmtSpeedX(pf.holdSpeed) + "x"
                flashTxt.visibility = View.VISIBLE
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || inPip) return false
                if (gMode == 0) {
                    if (abs(e2.x - e1.x) > abs(e2.y - e1.y)) { gMode = 1; gStartPos = p.currentPosition; gTarget = gStartPos }
                    else if (!isVideo) return false
                    else if (e1.x < root.width / 2f) { gMode = 2; gStartB = curBright() }
                    else { gMode = 3; gStartV = am.getStreamVolume(AudioManager.STREAM_MUSIC); gStartVF = gStartV.toFloat() / maxOf(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)) }
                }
                when (gMode) {
                    1 -> {
                        val d = ((e2.x - e1.x) / root.width * 90000).toLong()
                        gTarget = (gStartPos + d).coerceIn(0L, maxOf(p.duration, 0L))
                        val diff = (gTarget - gStartPos) / 1000
                        flash(Media.time(gTarget) + "  (" + (if (diff >= 0) "+" else "") + diff + "s)")
                    }
                    2 -> {
                        val nb = (gStartB + (e1.y - e2.y) / root.height * 1.2f).coerceIn(0.02f, 1f)
                        window.attributes = window.attributes.apply { screenBrightness = nb }
                        flash("Brightness " + (nb * 100).roundToInt() + "%")
                    }
                    3 -> {
                        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        // follows the finger smoothly; shown as a percentage (0 - 100%) like brightness
                        val f = (gStartVF + (e1.y - e2.y) / root.height * 1.3f).coerceIn(0f, 1f)
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, (f * mx).roundToInt().coerceIn(0, mx), 0)
                        flash("Volume " + (f * 100).roundToInt() + "%")
                    }
                }
                return true
            }
        })
        root.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (holdActive) { holdActive = false; p.setPlaybackSpeed(holdPrevSpeed); flashTxt.visibility = View.GONE }
                if (gMode == 1) p.seekTo(gTarget)
                gMode = 0
            }
            true
        }
        setContentView(root)
    }

    /** soft translucent circle used behind the few floating buttons */
    fun ring(size: Int): GradientDrawable = rr(0x55000000, dpf(size / 2), dp(1), 0x44FFFFFF)

    // ------------------------------------------------------------------ visibility / feedback
    fun show(v: Boolean) {
        val vv = v || !isVideo
        shown = vv
        val vis = if (vv && !locked && !inPip) View.VISIBLE else View.GONE
        topPanel.visibility = vis
        botPanel.visibility = if (inPip) View.GONE else if (locked) (if (unlockShown) View.VISIBLE else View.GONE) else vis
        edgeSeek.visibility = if (!vv && isVideo && !locked && !inPip) View.VISIBLE else View.GONE
        h.removeCallbacks(autoHide)
        if (vv && isVideo && !locked && p.isPlaying) h.postDelayed(autoHide, 4000)
    }

    fun showUnlock() {
        unlockShown = true
        if (!inPip) botPanel.visibility = View.VISIBLE
        edgeSeek.visibility = View.GONE
        h.removeCallbacks(hideUnlock)
        h.postDelayed(hideUnlock, 2500)
    }

    /** Locked: only the unlock icon (same spot as the lock icon) stays, everything else is hidden. */
    fun setLockedUi(l: Boolean) {
        for (i in 0 until botPanel.childCount) {
            val c = botPanel.getChildAt(i)
            if (c !== rotRow) c.visibility = if (l) View.INVISIBLE else View.VISIBLE
        }
        rotBtn.visibility = if (l) View.INVISIBLE else View.VISIBLE
        botPanel.background = if (l) null else GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xDD000000.toInt(), 0))
        (lockBtn.drawable as PathIcon).set(if (l) Ic.UNLOCK else Ic.LOCK)
    }

    fun onLockTap() {
        if (!locked) {
            locked = true
            setLockedUi(true)
            show(false)
            showUnlock()
        } else {
            locked = false
            unlockShown = false
            h.removeCallbacks(hideUnlock)
            setLockedUi(false)
            show(true)
        }
    }

    fun flash(msg: String, force: Boolean = false) {
        // Gesture scrubbing can fire dozens of callbacks per second; cap overlay relayouts.
        val now = android.os.SystemClock.uptimeMillis()
        if (!force && now - lastFlashUpdate < 55L) return
        lastFlashUpdate = now
        if (flashTxt.visibility != View.VISIBLE || flashTxt.text.toString() != msg) {
            flashTxt.text = msg
            flashTxt.visibility = View.VISIBLE
        }
        h.removeCallbacks(hideFlash)
        h.postDelayed(hideFlash, 650)
    }

    fun curBright(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f } catch (e: Exception) { 0.5f }
    }

    fun finishUp() { savePos(); finish() }

    fun savePos() {
        if (uris.isEmpty()) return
        saveAt(p.currentMediaItemIndex.coerceIn(0, uris.size - 1), p.currentPosition, p.duration)
    }

    fun saveAt(i: Int, c: Long, d: Long) {
        if (i !in uris.indices) return
        val end = d > 0 && c > d - 3000
        val ed = pf.sp.edit().putLong("pos_" + uris[i], if (end || c < 3000) 0L else c)
        if (d > 0L) ed.putLong("dur_" + uris[i], d)
        ed.apply()
    }

    // ------------------------------------------------------------------ tools
    fun toggleNight() {
        night = !night
        if (night) {
            savedBright = window.attributes.screenBrightness
            window.attributes = window.attributes.apply { screenBrightness = 0.03f }
        } else {
            window.attributes = window.attributes.apply { screenBrightness = if (savedBright >= 0f) savedBright else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
        }
        flash(if (night) "Night mode on" else "Night mode off")
    }

    fun rotate() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    fun speedDialog() {
        speedPanel(p.playbackParameters.speed) { v -> p.setPlaybackSpeed(v) }
    }

    fun fmtSpeed(x: Float): String = String.format(java.util.Locale.US, "%.2f", x).trimEnd('0').trimEnd('.')

    fun timerDialog() {
        val m = intArrayOf(0, 15, 30, 45, 60, 90)
        choose("Sleep timer", m.map { if (it == 0) "Off" else "$it minutes" } + "Custom…", -1) {
            h.removeCallbacks(sleepRun)
            if (it == m.size) {
                askNumber("Custom timer", "Minutes (1 – 600)", "", false) { x ->
                    val mm = x.toInt().coerceIn(1, 600)
                    startSleep(mm)
                }
            } else if (m[it] > 0) startSleep(m[it]) else { sleepEnd = 0L; updateSleepChip(); flash("Timer off") }
        }
    }

    fun startSleep(mm: Int) {
        h.removeCallbacks(sleepRun)
        sleepEnd = android.os.SystemClock.elapsedRealtime() + mm * 60000L
        h.postDelayed(sleepRun, mm * 60000L)
        updateSleepChip()
        flash("Sleep in $mm min")
    }

    fun updateSleepChip() {
        if (!::sleepChip.isInitialized) return
        val left = if (sleepEnd == 0L) 0L else sleepEnd - android.os.SystemClock.elapsedRealtime()
        sleepChip.visibility = View.VISIBLE
        if (sleepEnd != 0L && left > 0L) {
            // timer running: icon + remaining time
            sleepChip.text = fmtRemain(left)
            sleepIc.setBounds(0, 0, dp(16), dp(16))
            sleepChip.compoundDrawablePadding = dp(4)
            sleepChip.setPadding(dp(8), dp(4), dp(10), dp(4))
            sleepChip.background = rr(0x66000000, dpf(16), dp(1), 0x88FFFFFF.toInt())
        } else {
            // idle: plain timer icon beside the queue icon
            sleepChip.text = ""
            sleepIc.setBounds(0, 0, dp(24), dp(24))
            sleepChip.compoundDrawablePadding = 0
            sleepChip.setPadding(dp(12), dp(12), dp(12), dp(12))
            sleepChip.background = ripple(null, dpf(24))
        }
        sleepChip.setCompoundDrawables(sleepIc, null, null, null)
    }

    fun abRepeat() {
        when {
            a < 0 -> { a = p.currentPosition; flash("A set  " + Media.time(a)) }
            b < 0 -> { b = p.currentPosition; flash("B set  " + Media.time(b)) }
            else -> { a = -1L; b = -1L; flash("A-B repeat off") }
        }
    }

    fun cycleFit() {
        val modes = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL)
        val nm = listOf("Fit", "Crop", "Stretch")
        resizeIdx = (resizeIdx + 1) % 3
        pv.resizeMode = modes[resizeIdx]
        flash(nm[resizeIdx])
    }

    fun setupFx(id: Int) {
        try { eq?.release() } catch (e: Exception) {}
        try { loud?.release() } catch (e: Exception) {}
        extras?.release()
        eq = null
        loud = null
        extras = null
        if (id == 0) return
        extras = FxExtras.create(id, pf)
        try {
            val e = Equalizer(0, id)
            for (bd in 0 until e.numberOfBands.toInt()) {
                val k = "eq$bd"
                if (pf.sp.contains(k)) e.setBandLevel(bd.toShort(), pf.i(k, 0).toShort())
            }
            e.setEnabled(pf.b("eq_on", true))
            applyBassFallback(e, extras, pf, pf.i("fx_bass", 0))
            eq = e
        } catch (e: Exception) {
        }
        try {
            val l = LoudnessEnhancer(id)
            l.setTargetGain(600)
            l.setEnabled(pf.smartVol)
            loud = l
        } catch (e: Exception) {
        }
    }

    fun eqDialog() {
        // same Equalizer panel as the music player (bands, presets, reverb, BassBooster, Virtualizer)
        eqPanel(eq, extras, p.audioSessionId, pf)
    }

    fun applyColor() {
        val cm = ColorMatrix()
        cm.setSaturation(cSat / 100f)
        val c = cContrast / 100f
        val t = (1f - c) * 128f + cBright
        cm.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        val tv = pv.videoSurfaceView as? TextureView
        tv?.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
    }

    fun seekRow(t: String, min: Int, max: Int, cur: Int, on: (Int) -> Unit): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(6), 0, dp(6))
        r.addView(label(t, 15f, pal.text), lp(dp(96), -2))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { if (u) on(v + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        r.addView(sb, lp(0, -2, 1f))
        return r
    }

    fun colorDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(8), dp(22), 0)
        box.addView(seekRow("Brightness", -60, 60, cBright) { cBright = it; applyColor() })
        box.addView(seekRow("Contrast", 50, 150, cContrast) { cContrast = it; applyColor() })
        box.addView(seekRow("Saturation", 0, 200, cSat) { cSat = it; applyColor() })
        MaterialAlertDialogBuilder(this).setTitle("Video color").setView(box)
            .setPositiveButton("Done", null)
            .setNeutralButton("Reset") { _, _ -> cBright = 0; cContrast = 100; cSat = 100; applyColor() }
            .show()
    }

    fun currentPlaybackMode(): Int = when {
        stopAfterCurrent -> 3
        p.shuffleModeEnabled -> 4
        p.repeatMode == Player.REPEAT_MODE_ONE -> 1
        p.repeatMode == Player.REPEAT_MODE_ALL -> 2
        else -> 0
    }

    fun cyclePlaybackMode() { setPlaybackMode((currentPlaybackMode() + 1) % 5) }

    fun setPlaybackMode(mode: Int) {
        stopAfterCurrent = mode == 3
        p.shuffleModeEnabled = mode == 4
        p.repeatMode = when (mode) {
            1 -> Player.REPEAT_MODE_ONE
            2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        p.pauseAtEndOfMediaItems = when (mode) {
            3 -> true
            0 -> !pf.auto
            else -> false
        }
        val label = AudioEngine.modeLabels.getOrElse(mode) { "Play in Order" }
        flash(label)
    }

    // ------------------------------------------------------------------ menus
    fun queueSheet() {
        val sourceUris = uris
        val sourceNames = names
        val entries = sourceUris.mapIndexed { i, u -> QueueEntry("$i|$u", sourceNames.getOrElse(i) { nameOf(Uri.parse(u)) }) }
        QueueSheet.show(this, "Playing Queue", entries, pal.accent, showMode = true,
            modeIndex = { currentPlaybackMode() }, onCycleMode = { cyclePlaybackMode() },
            currentKey = "${p.currentMediaItemIndex}|${uris.getOrNull(p.currentMediaItemIndex) ?: ""}",
            onSelect = { e ->
                val i = uris.indexOf(e.key.substringAfter("|"))
                if (i >= 0) { p.seekTo(i, 0L); p.play() }
            },
            onChange = { changed ->
                val ordered = changed.mapNotNull { e ->
                    val old = e.key.substringBefore("|").toIntOrNull() ?: -1
                    if (old in sourceUris.indices) old else -1
                }
                val newUris = ordered.map { sourceUris[it] }
                val newNames = ordered.map { sourceNames.getOrElse(it) { "Video" } }
                val currentUri = uris.getOrNull(p.currentMediaItemIndex)
                val pos = p.currentPosition
                val wasPlaying = p.isPlaying
                uris = newUris; names = newNames
                pf.lastQ = newUris; pf.lastQN = newNames
                if (newUris.isNotEmpty()) {
                    val currentNewIndex = newUris.indexOf(currentUri)
                    val idx = if (currentNewIndex >= 0) currentNewIndex else 0
                    p.setMediaItems(newUris.map { MediaItem.fromUri(it) }, idx, if (currentNewIndex >= 0) pos else 0L)
                    p.prepare(); p.playWhenReady = wasPlaying
                } else { p.stop(); finishUp() }
            })
    }

    fun moreMenu(anchor: View) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = rr(0xFF303030.toInt(), dpf(6))
        lateinit var pw: PopupWindow
        fun row(icon: String, text: String, trail: View?, click: () -> Unit) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(16), 0, dp(16), 0)
            r.background = ripple(null, 0f, 0x33FFFFFF)
            val iv = ImageView(this)
            iv.setImageDrawable(PathIcon(icon, Color.WHITE))
            r.addView(iv, lp(dp(26), dp(26)).apply { marginEnd = dp(16) })
            val t = label(text, 17f, Color.WHITE)
            t.maxLines = 1
            r.addView(t, lp(0, -2, 1f))
            if (trail != null) r.addView(trail)
            r.setOnClickListener { click() }
            col.addView(r, lp(-1, dp(48)))
        }
        fun close() { pw.dismiss() }
        val left = if (sleepEnd == 0L) 0L else sleepEnd - android.os.SystemClock.elapsedRealtime()
        val timerTxt = label(if (left > 0L) fmtRemain(left) else "", 13f, 0xFFAAAAAA.toInt())
        row(Ic.TIMER, "Timer", timerTxt) { close(); timerDialog() }
        row(Ic.HEADPHONES, "Background play", null) { close(); backgroundPlay() }
        val modeTxt = label(AudioEngine.modeLabels[currentPlaybackMode()], 13f, 0xFFAAAAAA.toInt())
        row(AudioEngine.modePath(currentPlaybackMode()), "Playback", modeTxt) {
            close()
            choose("Playback mode", AudioEngine.modeLabels, currentPlaybackMode()) { m -> setPlaybackMode(m) }
        }
        row(Ic.SWAP, "A-B repeat", null) { close(); abRepeat() }
        row(Ic.DETAILS, "Info", null) { close(); details() }
        row(Ic.DELETE, "Delete", null) { close(); deleteCurrent() }
        row(Ic.SHARE, "Send", null) { close(); share() }
        val sv = ScrollView(this)
        sv.addView(col)
        val maxH = resources.displayMetrics.heightPixels - dp(80)
        pw = PopupWindow(sv, dp(270), if (dp(48 * 7 + 8) > maxH) maxH else ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.elevation = dpf(8)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.showAsDropDown(anchor, 0, 0, Gravity.END)
    }

    /** Hands the video over to the music player service: it keeps playing (audio) with the screen off or the app closed. */
    fun backgroundPlay() {
        if (!isVideo || uris.isEmpty()) return
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val pos = p.currentPosition
        val spd = p.playbackParameters.speed
        savePos()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)
        }
        notifOff = true
        cancelVideoNotif()
        AudioEngine.start(this, uris.mapIndexed { k, u -> Track(u, names.getOrElse(k) { "" }.substringBeforeLast('.'), "", "", -1L) }, i, pos)
        AudioEngine.player?.setPlaybackSpeed(spd)
        p.pause()
        toast("Playing in background")
        finish()
    }

    /** Floating, resizable window (keeps playing from the same position). */
    fun popup() {
        if (!isVideo) return
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        if (startPopup(uris, names, i, p.currentPosition, p.playWhenReady)) {
            savePos()
            p.pause()
            finish()
        }
    }

    fun decoderDialog() {
        choose("Decoder", listOf("Hardware decoder", "Software decoder"), pf.decoder) {
            if (pf.decoder != it) { pf.decoder = it; rebuildPlayer(); flash(if (it == 0) "Hardware decoder" else "Software decoder") }
        }
    }

    fun playOptions() {
        val items = listOf(
            "Repeat mode", "Auto play next video: " + (if (pf.auto) "On" else "Off"),
            "Resume playback: " + (if (pf.resume) "On" else "Off"), "A-B repeat"
        )
        choose("Play options", items, -1) {
            when (it) {
                0 -> choose("Playback mode", AudioEngine.modeLabels, currentPlaybackMode()) { m -> setPlaybackMode(m) }
                1 -> { pf.auto = !pf.auto; if (!stopAfterCurrent && p.repeatMode == Player.REPEAT_MODE_OFF && !p.shuffleModeEnabled) p.pauseAtEndOfMediaItems = !pf.auto; flash(if (pf.auto) "Auto play next: On" else "Auto play next: Off") }
                2 -> { pf.resume = !pf.resume; flash(if (pf.resume) "Resume: On" else "Resume: Off") }
                3 -> abRepeat()
            }
        }
    }

    fun deleteCurrent() {
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val u = Uri.parse(uris[i])
        if (u.scheme != "content" || u.authority != "media") { toast("Cannot delete this file"); return }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startIntentSenderForResult(MediaStore.createDeleteRequest(contentResolver, listOf(u)).intentSender, 8, null, 0, 0, 0)
            } else {
                contentResolver.delete(u, null, null)
                finishUp()
            }
        } catch (e: Exception) {
            toast("Cannot delete: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 8 && res == RESULT_OK) finishUp()
    }

    fun share() {
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val u = Uri.parse(uris[i])
        val it = if (u.scheme == "content" || u.scheme == "file")
            Intent(Intent.ACTION_SEND).setType(if (isVideo) "video/*" else "audio/*").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        else Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, uris[i])
        startActivity(Intent.createChooser(it, "Send"))
    }

    fun details() {
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val vs = p.videoSize
        message(
            names.getOrElse(i) { "" },
            "Duration: ${Media.time(maxOf(p.duration, 0L))}" + (if (vs.width > 0) "\nResolution: ${vs.width}x${vs.height}" else "") + "\n${uris[i]}"
        )
    }

    fun enterPip() {
        if (!isVideo) return
        try {
            val vs = p.videoSize
            var ar = Rational(16, 9)
            if (vs.width > 0 && vs.height > 0) {
                val r = vs.width.toFloat() / vs.height
                ar = when {
                    r > 2.39f -> Rational(239, 100)
                    r < 0.42f -> Rational(42, 100)
                    else -> Rational(vs.width, vs.height)
                }
            }
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ar).build())
        } catch (e: Exception) {
            toast("Pop-up is not supported here")
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        show(!inPip)
    }

    // ------------------------------------------------------------------ lifecycle
    var bgMoved = false

    /** hand the running video over to the music engine so the sound keeps playing */
    fun transferToAudio() {
        if (uris.isEmpty()) return
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val pos = p.currentPosition
        val spd = p.playbackParameters.speed
        notifOff = true
        cancelVideoNotif()
        AudioEngine.start(this, uris.mapIndexed { k, u -> Track(u, names.getOrElse(k) { "" }.substringBeforeLast('.'), "", "", -1L) }, i, pos)
        AudioEngine.player?.setPlaybackSpeed(spd)
        p.pause()
    }

    override fun onStart() {
        super.onStart()
        if (bgMoved && ::p.isInitialized) {
            // back from the home screen: continue the picture from where the sound is now
            bgMoved = false
            notifOff = false
            msess?.setActive(true)
            val ap = AudioEngine.player
            if (ap != null) {
                val pos = ap.currentPosition
                val idx = ap.currentMediaItemIndex
                val playing = ap.isPlaying
                AudioEngine.stop(this)
                p.seekTo(idx, pos)
                p.playWhenReady = playing
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (uris.isNotEmpty() && ::p.isInitialized) {
            savePos()
            if (isVideo && !isInPictureInPictureMode) {
                if (pf.autoBg && p.isPlaying) {
                    transferToAudio()
                    if (!isFinishing) bgMoved = true
                } else p.pause()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
        try { sm?.unregisterListener(shakeL) } catch (e: Exception) {}
        try { eq?.release() } catch (e: Exception) {}
        try { loud?.release() } catch (e: Exception) {}
        try { extras?.release() } catch (e: Exception) {}
        try { unregisterReceiver(vRecv) } catch (e: Exception) {}
        cancelVideoNotif()
        try { msess?.release() } catch (e: Exception) {}
        if (::p.isInitialized) p.release()
    }
}
