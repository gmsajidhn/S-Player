package com.sajid.splayer

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import java.io.File
import java.util.concurrent.Executors

const val F_REC = "@@recent"
const val F_PL = "@@playlist"
const val F_PLN = "@@pln:"
const val F_ALB = "@@alb:"
const val F_ART = "@@art:"
const val F_GEN = "@@gen:"

fun View.roundClip(r: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
    }
    clipToOutline = true
}

class Row(
    val title: String, val sub: String, val isNew: Boolean, val item: Item?, val tint: Int,
    val accentSub: Boolean, val click: () -> Unit, val menu: (() -> Unit)?,
    val art: Item? = null, val kind: Int = 0,
    val selKey: String? = null, val selItems: List<Item> = emptyList()
)

class RH(val vh: VH, v: View, val handle: View?) : RecyclerView.ViewHolder(v)

class VH(
    val root: View, val grid: Boolean, val box: FrameLayout, val ph: ImageView, val thumb: ImageView,
    val dur: TextView, val title: TextView, val sub: TextView, val badge: TextView, val more: ImageView,
    val prog: ProgressLine, val sq: Boolean = false
)

class MainActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var barHost: FrameLayout
    lateinit var body: FrameLayout
    var video = true
    var page = 0
    var folder: String? = null
    var showLocked = false
    var searching = false
    var query = ""
    var permOk = false
    var all = listOf<Item>()
    var vaultItems = listOf<Item>()
    var vaultVerb = "locked"
    val pool = Executors.newFixedThreadPool(3)
    val cache = LruCache<String, Bitmap>(150)
    var pendingRename: Pair<Item, String>? = null
    var keepFirst = -1
    var lvRef: AbsListView? = null
    var tab = ""
    lateinit var miniHost: FrameLayout
    lateinit var selHost: FrameLayout
    fun miniReady() = ::miniHost.isInitialized
    var selMode = false
    val sel = LinkedHashMap<String, List<Item>>()
    var curRows: List<Row> = emptyList()
    var selBlock = false
    val miniCb: () -> Unit = { runOnUiThread { refreshMini() } }
    /** folder picker used by Copy / Move > "Choose any other folder in phone" */
    var treeCb: ((android.net.Uri) -> Unit)? = null
    val treePicker = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()) { u ->
        val cb = treeCb
        treeCb = null
        if (u != null && cb != null) cb(u)
    }

    companion object {
        const val RC_DEL = 2
        const val RC_WRITE = 3
        const val RC_VAULT = 4
    }

    // ---------------------------------------------------------------- lifecycle
    override fun onCreate(b: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(b)
        pal = Pal(pf.dark, pf.accent)
        video = !pf.musicFirst
        tab = pf.tabs(video).first()
        page = b?.getInt("page", 0) ?: 0
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        val wc = WindowInsetsControllerCompat(window, window.decorView)
        wc.isAppearanceLightStatusBars = !pal.dark
        wc.isAppearanceLightNavigationBars = !pal.dark
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (!goBack()) finish() }
        })
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.bg)
        barHost = FrameLayout(this)
        root.addView(barHost, lp(-1, -2))
        body = FrameLayout(this)
        root.addView(body, lp(-1, 0, 1f))
        selHost = FrameLayout(this)
        root.addView(selHost, lp(-1, -2))
        miniHost = FrameLayout(this)
        root.addView(miniHost, lp(-1, -2))
        setContentView(root)
        permOk = hasPerm()
        render()
        if (permOk) load() else requestPermissions(perms(), 1)
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); o.putInt("page", page) }
    override fun onStart() { super.onStart(); if (miniCb !in AudioEngine.listeners) AudioEngine.listeners.add(miniCb); refreshMini() }
    override fun onStop() { super.onStop(); miniHost.removeCallbacks(miniTickR); keepFirst = lvRef?.firstVisiblePosition ?: -1; AudioEngine.listeners.remove(miniCb) }
    override fun onResume() { super.onResume(); (lvRef?.adapter as? BaseAdapter)?.notifyDataSetChanged() }
    override fun onRestart() { super.onRestart(); cache.evictAll(); if (permOk) load() }
    override fun onDestroy() { super.onDestroy(); pool.shutdownNow() }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        permOk = hasPerm()
        if (permOk) load() else render()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == RC_VAULT) {
            if (Vault.inFlight.isNotEmpty()) {
                if (Build.VERSION.SDK_INT >= 30) finishVault(res == RESULT_OK)
                else if (res == RESULT_OK) removeOriginals() else finishVault(false)
            }
            return
        }
        if (rc == RC_WRITE && res == RESULT_OK) {
            pendingRename?.let { try { doRename(it.first, it.second) } catch (e: Exception) { toast("Cannot rename this file") } }
        }
        pendingRename = null
        load()
    }

    fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun hasPerm() = perms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    fun goBack(): Boolean {
        if (selMode) { exitSel(); return true }
        if (searching) { searching = false; query = ""; render(); return true }
        if (page != 0) { page = 0; render(); return true }
        if (folder != null) { folder = null; buildBody(); return true }
        if (showLocked) { showLocked = false; buildBody(); return true }
        return false
    }

    fun load() {
        Thread {
            Vault.recover(this)
            var l = Media.load(this, video)
            if (!video && pf.minSec > 0) l = l.filter { it.dur >= pf.minSec * 1000L }
            val vl = Vault.items(this, video, "lock")
            runOnUiThread { if (!isDestroyed) { all = l; vaultItems = vl; selMode = false; sel.clear(); buildSelBar(); render() } }
        }.start()
    }

    fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    fun fk(f: String) = (if (video) "v:" else "a:") + f
    fun isNew(added: Long) = System.currentTimeMillis() / 1000 - added < 2 * 86400
    fun wordOf(n: Int) = if (video) (if (n == 1) "video" else "videos") else (if (n == 1) "track" else "tracks")

    // ---------------------------------------------------------------- top bar
    fun render() { buildBar(); buildBody(); refreshMini() }

    fun buildBar() {
        barHost.removeAllViews()
        if (selMode) { barHost.addView(selTopBar()); return }
        if (searching) { barHost.addView(searchBar()); return }
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(16), dp(10), dp(8), dp(6))
        val order = if (pf.musicFirst) listOf(false, true) else listOf(true, false)
        for (v in order) bar.addView(tabPill(v), lp(dp(58), dp(40)).apply { marginEnd = dp(6) })
        bar.addView(View(this), lp(0, 1, 1f))
        bar.addView(iconBtn(Ic.SEARCH, pal.text) { searching = true; query = ""; page = 0; render() })
        val more = iconBtn(Ic.MORE, pal.text) {}
        more.setOnClickListener { topMenu(more) }
        bar.addView(more)
        barHost.addView(bar)
    }

    fun tabPill(v: Boolean): View {
        val sel = video == v
        val iv = ImageView(this)
        iv.setImageDrawable(PathIcon(if (v) Ic.MOVIE else Ic.MUSIC, if (sel) pal.onSel else pal.onUnsel))
        iv.setPadding(dp(17), dp(8), dp(17), dp(8))
        iv.background = ripple(if (sel) pal.selTab else pal.unselTab, dpf(20))
        iv.setOnClickListener {
            if (video != v || page != 0 || showLocked) {
                selMode = false; this@MainActivity.sel.clear(); buildSelBar()
                video = v; tab = pf.tabs(v).first(); page = 0; folder = null; query = ""; showLocked = false; load(); render()
            }
        }
        return iv
    }

    fun searchBar(): View {
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(8), dp(10), dp(8), dp(6))
        bar.addView(iconBtn(Ic.BACK, pal.text) { searching = false; query = ""; render() })
        val et = EditText(this)
        et.hint = "Search"
        et.setHintTextColor(pal.sub)
        et.setTextColor(pal.text)
        et.textSize = 18f
        et.background = null
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.imeOptions = EditorInfo.IME_ACTION_SEARCH
        et.setText(query)
        et.setSelection(et.text.length)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; buildBody() }
        })
        bar.addView(et, lp(0, -2, 1f))
        bar.addView(iconBtn(Ic.CLOSE, pal.text) { et.setText("") })
        et.requestFocus()
        et.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, 0) }
        return bar
    }

    fun topMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Settings")
        pm.menu.add(0, 2, 0, "Locked")
        pm.menu.add(0, 3, 0, "Refresh")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> { page = 1; searching = false; render() }
                2 -> openLocked()
                3 -> load()
            }
            true
        }
        pm.show()
    }

    // ---------------------------------------------------------------- body
    fun buildBody() {
        body.removeAllViews()
        lvRef = null
        if (page == 1) { body.addView(settingsView()); return }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        body.addView(col, FrameLayout.LayoutParams(-1, -1))
        if (!permOk) {
            col.addView(emptyView("Allow access to your media to see your videos and music.", "Grant permission") { requestPermissions(perms(), 1) }, lp(-1, 0, 1f))
            return
        }
        val cur = folder
        val root = cur == null && query.isBlank() && !showLocked && !searching
        if (root) col.addView(tabsRow())

        val rows = buildRows()
        curRows = rows
        selBlock = false
        val title = when {
            searching -> "Results"
            showLocked && cur == null -> "Locked"
            cur == F_REC -> "Recently added"
            cur == F_PL -> "Playlist"
            cur != null && cur.startsWith("@@") -> cur.substringAfter(':').ifEmpty { "<unknown>" }
            cur != null -> pf.alias(cur)
            else -> tabName(tab)
        }
        val fileMode = rows.isNotEmpty() && rows.all { it.item != null }
        val hr = LinearLayout(this)
        hr.gravity = Gravity.CENTER_VERTICAL
        hr.setPadding(dp(16), dp(10), dp(8), dp(2))
        val ht = label(title, 17f, pal.text, true)
        ht.maxLines = 1
        ht.ellipsize = TextUtils.TruncateAt.END
        hr.addView(ht, lp(0, -2, 1f))
        if (fileMode) hr.addView(iconBtn(if (pf.grid) Ic.LIST else Ic.GRID, pal.text) { pf.grid = !pf.grid; buildBody() })
        hr.addView(iconBtn(Ic.SORT, pal.text) { sortDialog() })
        col.addView(hr)

        if (rows.isEmpty()) {
            val msg = when {
                query.isNotBlank() -> "No results for \"${query.trim()}\""
                showLocked -> "Nothing is locked yet"
                cur != null && cur.startsWith(F_PLN) -> "This playlist is empty"
                cur == null && tab == "playlist" -> "No playlist yet. Tap \"Add to playlist\" on any item to create one."
                else -> if (video) "No videos found" else "No music found"
            }
            col.addView(emptyView(msg, null) {}, lp(-1, 0, 1f))
        } else {
            val albumGrid = rows.all { it.kind == 1 }
            val gridMode = albumGrid || (pf.grid && fileMode)
            val plIn = cur?.takeIf { it.startsWith(F_PLN) }?.removePrefix(F_PLN)
            val dragMode = plIn != null || (cur == null && tab == "playlist" && !showLocked && !searching && query.isBlank())
            if (dragMode) {
                selBlock = true
                col.addView(dragList(rows, gridMode, plIn), lp(-1, 0, 1f))
            } else {
            val ad = object : BaseAdapter() {
                override fun getCount() = rows.size
                override fun getItem(i: Int) = rows[i]
                override fun getItemId(i: Int) = i.toLong()
                override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                    var vh = v?.tag as? VH
                    if (vh == null || vh.grid != gridMode || vh.sq != albumGrid) vh = newVH(gridMode, albumGrid)
                    bind(vh, rows[i])
                    return vh.root
                }
            }
            val lv: AbsListView
            if (gridMode) {
                val g = GridView(this)
                g.numColumns = 2
                g.selector = ColorDrawable(Color.TRANSPARENT)
                g.setPadding(dp(8), 0, dp(8), dp(80))
                g.clipToPadding = false
                g.adapter = ad
                lv = g
            } else {
                val l = ListView(this)
                l.divider = null
                l.dividerHeight = 0
                l.selector = ColorDrawable(Color.TRANSPARENT)
                l.setPadding(0, 0, 0, dp(80))
                l.clipToPadding = false
                l.adapter = ad
                lv = l
            }
            col.addView(lv, lp(-1, 0, 1f))
            lvRef = lv
            if (keepFirst > 0) { lv.setSelection(keepFirst) }
            keepFirst = -1
            }
        }
    }

    fun emptyView(msg: String, btn: String?, click: () -> Unit): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(dp(32), dp(32), dp(32), dp(32))
        val ic = ImageView(this)
        ic.setImageDrawable(PathIcon(if (video) Ic.MOVIE else Ic.MUSIC, ColorUtils.setAlphaComponent(pal.sub, 110)))
        c.addView(ic, lp(dp(56), dp(56)))
        val t = label(msg, 16f, pal.sub)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(14), 0, 0)
        c.addView(t)
        if (btn != null) {
            val b = label(btn, 16f, Color.WHITE, true)
            b.gravity = Gravity.CENTER
            b.setPadding(dp(24), dp(12), dp(24), dp(12))
            b.background = ripple(pal.accent, dpf(24), 0x33FFFFFF)
            b.setOnClickListener { click() }
            c.addView(b, lp(-2, -2).apply { topMargin = dp(18) })
        }
        return c
    }

    fun tabName(k: String) = when (k) {
        "all" -> "All videos"
        "folder" -> "Folder"
        "playlist" -> "Playlist"
        "album" -> "Album"
        "songs" -> "Songs"
        "artist" -> "Artist"
        "recent" -> "Recently added"
        "genres" -> "Genres"
        "mini" -> "Mini tracks"
        else -> k
    }

    /** Tab strip: picks the biggest text size at which every tab name is fully visible; scrolls only if even the smallest cannot fit. */
    fun tabsRow(): View {
        val ks = pf.tabs(video)
        if (tab !in ks) tab = ks.first()
        val ac = if (pal.dark) pal.bright else pal.accent
        val dm = resources.displayMetrics
        val avail = dm.widthPixels - dp(12)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        fun txt(k: String, upper: Boolean) = if (upper) tabName(k).uppercase() else tabName(k)
        val padH = dp(10)
        fun widths(sz: Float, upper: Boolean): List<Float> {
            paint.textSize = android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP, sz, dm)
            return ks.map { paint.measureText(txt(it, upper)) + padH * 2 }
        }
        var size = 12f
        var upper = false
        var fit = false
        search@ for (u in listOf(true, false)) {
            var s = 16f
            while (s >= 11f) {
                if (widths(s, u).sum() <= avail) { size = s; upper = u; fit = true; break@search }
                s -= 0.5f
            }
        }
        val ws = widths(size, upper)
        val row = LinearLayout(this)
        row.setPadding(dp(6), 0, dp(6), 0)
        var selView: View? = null
        ks.forEachIndexed { i, k ->
            val sel = k == tab
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER_HORIZONTAL
            val t = label(txt(k, upper), size, if (sel) ac else pal.text, true)
            t.maxLines = 1
            t.gravity = Gravity.CENTER
            t.setPadding(padH, dp(14), padH, dp(10))
            val ind = View(this)
            ind.background = rr(ac, dpf(2))
            ind.visibility = if (sel) View.VISIBLE else View.INVISIBLE
            c.addView(t, lp(-2, -2))
            c.addView(ind, lp(dp(28), dp(3)))
            c.setOnClickListener { if (tab != k) { tab = k; folder = null; buildBody() } }
            if (fit) row.addView(c, lp(0, -2, ws[i])) else row.addView(c, lp(-2, -2))
            if (sel) selView = c
        }
        if (fit) return row
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(row)
        hs.post { selView?.let { v -> hs.scrollTo(maxOf(0, v.left - (hs.width - v.width) / 2), 0) } }
        return hs
    }

    /** Same look as the music mini player: close, thumbnail, title, play, queue. */
    fun resumeCard(): View? {
        if (!video || !pf.showLast || pf.lastUri.isEmpty() || folder != null || searching || showLocked || !permOk) return null
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(10), dp(4), dp(10))
        bar.setBackgroundColor(if (pal.dark) 0xFF595959.toInt() else pal.tile)
        val textCol = if (pal.dark) Color.WHITE else pal.text
        val subCol = if (pal.dark) 0xFFCFCFCF.toInt() else pal.sub
        val art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rr(pal.surface, dpf(26))
        art.roundClip(dpf(26))
        art.setImageDrawable(PathIcon(Ic.MOVIE, ColorUtils.setAlphaComponent(pal.sub, 140)).also { art.setPadding(dp(12), dp(12), dp(12), dp(12)) })
        bar.addView(art, lp(dp(52), dp(52)).apply { marginEnd = dp(14) })
        val u = pf.lastUri
        Thread {
            try {
                val bm = Art.load(this, u, -1L, 160)
                if (bm != null) runOnUiThread { art.setPadding(0, 0, 0, 0); art.setImageBitmap(bm) }
            } catch (e: Exception) {
            }
        }.start()
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        val t1 = label(pf.lastName.substringBeforeLast('.'), 18f, textCol, true)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        val saved = pf.sp.getLong("pos_$u", 0L)
        val t2 = label(if (saved > 0L) "Resume from " + Media.time(saved) else "Continue watching", 14f, subCol)
        t2.maxLines = 1
        tc.addView(t1)
        tc.addView(t2)
        bar.addView(tc, lp(0, -2, 1f))
        val open = {
            val q = pf.lastQ
            val qn = pf.lastQN
            val ix = q.indexOf(u)
            val us = if (ix >= 0) q else listOf(u)
            val ns = if (ix >= 0 && qn.size == q.size) qn else listOf(pf.lastName)
            startActivity(
                Intent(this, PlayerActivity::class.java)
                    .putStringArrayListExtra("u", ArrayList(us))
                    .putStringArrayListExtra("n", ArrayList(ns))
                    .putExtra("i", maxOf(ix, 0)).putExtra("v", true)
            )
        }
        bar.addView(iconBtn(Ic.QUEUE, textCol, 48, 26) { videoQueue() })
        bar.addView(iconBtn(Ic.PLAY, textCol, 48, 28) { open() })
        val sep = View(this)
        sep.setBackgroundColor(0x55FFFFFF)
        bar.addView(sep, lp(dp(1), dp(34)).apply { marginStart = dp(6); marginEnd = dp(2) })
        bar.addView(iconBtn(Ic.CLOSE, textCol, 48, 26) { pf.lastUri = ""; buildBody() })
        tc.setOnClickListener { open() }
        art.setOnClickListener { open() }
        return bar
    }

    fun videoQueue() {
        val q = pf.lastQ.toMutableList()
        val qn = pf.lastQN.toMutableList()
        if (q.isEmpty() || qn.size != q.size) { toast("No queue yet"); return }
        val entries = q.mapIndexed { i, u -> QueueEntry("$i|$u", qn[i]) }
        QueueSheet.show(this, "Playing Queue", entries, pal.accent,
            onSelect = { e ->
                val uri = e.key.substringAfter("|")
                val i = pf.lastQ.indexOf(uri)
                if (i >= 0) startActivity(Intent(this, PlayerActivity::class.java)
                    .putStringArrayListExtra("u", ArrayList(pf.lastQ))
                    .putStringArrayListExtra("n", ArrayList(pf.lastQN))
                    .putExtra("i", i).putExtra("v", true))
            },
            onChange = { changed ->
                val ids = changed.mapNotNull { it.key.substringBefore("|").toIntOrNull() }
                pf.lastQ = ids.mapNotNull { q.getOrNull(it) }
                pf.lastQN = ids.mapNotNull { qn.getOrNull(it) }
            })
    }

    /** Playlist screens: long-press (or the handle) and drag rows up/down; the new order is saved. */
    fun dragList(rows: List<Row>, grid: Boolean, plName: String?): View {
        val mrows = ArrayList(rows)
        val rv = RecyclerView(this)
        rv.layoutManager = if (grid) GridLayoutManager(this, 2) else LinearLayoutManager(this)
        rv.setPadding(if (grid) dp(8) else 0, 0, if (grid) dp(8) else 0, dp(90))
        rv.clipToPadding = false
        var helper: ItemTouchHelper? = null
        val adapter = object : RecyclerView.Adapter<RH>() {
            override fun getItemCount() = mrows.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RH {
                val vh = newVH(grid)
                if (grid) {
                    vh.root.layoutParams = RecyclerView.LayoutParams(-1, -2)
                    return RH(vh, vh.root, null)
                }
                val w = LinearLayout(this@MainActivity)
                w.gravity = Gravity.CENTER_VERTICAL
                val hd = ImageView(this@MainActivity)
                hd.setImageDrawable(PathIcon(Ic.DRAG, pal.sub))
                hd.setPadding(dp(10), dp(10), dp(2), dp(10))
                w.addView(hd, lp(dp(38), dp(44)))
                w.addView(vh.root, lp(0, -2, 1f))
                w.layoutParams = RecyclerView.LayoutParams(-1, -2)
                val holder = RH(vh, w, hd)
                hd.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_DOWN) helper?.startDrag(holder); false }
                return holder
            }
            override fun onBindViewHolder(h: RH, i: Int) { bind(h.vh, mrows[i]) }
        }
        rv.adapter = adapter
        val flags = if (grid) ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        else ItemTouchHelper.UP or ItemTouchHelper.DOWN
        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(flags, 0) {
            override fun isLongPressDragEnabled() = true
            override fun onMove(r: RecyclerView, a: RecyclerView.ViewHolder, b: RecyclerView.ViewHolder): Boolean {
                val f = a.bindingAdapterPosition
                val t = b.bindingAdapterPosition
                if (f < 0 || t < 0) return false
                mrows.add(t, mrows.removeAt(f))
                adapter.notifyItemMoved(f, t)
                return true
            }
            override fun onSwiped(v: RecyclerView.ViewHolder, d: Int) {}
            override fun clearView(r: RecyclerView, v: RecyclerView.ViewHolder) {
                super.clearView(r, v)
                if (plName != null) pf.plSetOrder(plName, mrows.mapNotNull { it.item?.key })
                else pf.plSetNameOrder(mrows.map { it.title })
            }
        })
        helper = touchHelper
        touchHelper.attachToRecyclerView(rv)
        return rv
    }

    // ---------------------------------------------------------------- rows
    fun sortItems(l: List<Item>): List<Item> {
        val c = Comparator<Item> { a, b ->
            when (pf.sortKey) {
                1 -> a.added.compareTo(b.added)
                2 -> a.size.compareTo(b.size)
                3 -> a.dur.compareTo(b.dur)
                else -> a.name.compareTo(b.name, true)
            }
        }
        val s = l.sortedWith(c)
        return if (pf.sortAsc) s else s.reversed()
    }

    fun sortGroups(g: List<Pair<String, List<Item>>>): List<Pair<String, List<Item>>> {
        val c = Comparator<Pair<String, List<Item>>> { a, b ->
            when (pf.sortKey) {
                1 -> a.second.maxOf { it.added }.compareTo(b.second.maxOf { it.added })
                2 -> a.second.sumOf { it.size }.compareTo(b.second.sumOf { it.size })
                else -> pf.alias(a.first).compareTo(pf.alias(b.first), true)
            }
        }
        val s = g.sortedWith(c)
        return if (pf.sortAsc) s else s.reversed()
    }

    fun itemRow(x: Item, list: List<Item>, i: Int): Row {
        val sub = if (x.video) "${Media.size(x.size)} • ${x.w}x${x.h}"
        else (if (x.artist.isNotEmpty()) x.artist + " • " else "") + Media.time(x.dur)
        return Row(x.title, sub, isNew(x.added), x, 0, false, { play(list, i) }, { itemSheet(x, list, i) }, selKey = x.key, selItems = listOf(x))
    }

    fun groupRow(title: String, sub: String, l: List<Item>, key: String, kind: Int): Row =
        Row(title, sub, false, null, 0, false, { folder = key; buildBody() }, { groupSheet(title, l) }, l[0], kind, "g:$key", l)

    fun buildRows(): List<Row> {
        val now = System.currentTimeMillis() / 1000
        val hidden = pf.strs("hide")
        val lf = pf.strs("lockf")
        val li = pf.strs("locki")
        val q = query.trim()
        fun match(x: Item) = q.isEmpty() || x.name.contains(q, true)
        // files locked with older versions of the app are only flagged (still in the gallery); new ones live in the vault
        fun legacyLocked(x: Item) = fk(x.folder) in lf || x.key in li
        val vis: List<Item> = if (showLocked) vaultItems.filter { match(it) } + all.filter { legacyLocked(it) && match(it) }
        else all.filter { fk(it.folder) !in hidden && !legacyLocked(it) && match(it) }
        val rows = ArrayList<Row>()
        val cur = folder
        if (q.isNotEmpty() || cur != null) {
            val c2 = cur ?: ""
            val l = when {
                q.isNotEmpty() -> vis
                c2 == F_REC -> vis.filter { now - it.added < 7 * 86400 }.take(20)
                c2.startsWith(F_PLN) -> pf.plList(c2.removePrefix(F_PLN)).mapNotNull { k -> vis.firstOrNull { it.key == k } }
                c2.startsWith(F_ALB) -> vis.filter { it.album == c2.removePrefix(F_ALB) }
                c2.startsWith(F_ART) -> vis.filter { it.artist == c2.removePrefix(F_ART) }
                c2.startsWith(F_GEN) -> vis.filter { it.genre == c2.removePrefix(F_GEN) }
                else -> vis.filter { it.folder == c2 }
            }
            val s = if (c2.startsWith(F_PLN)) l else sortItems(l)
            s.forEachIndexed { i, x -> rows.add(itemRow(x, s, i)) }
            return rows
        }
        if (!showLocked) {
            when (tab) {
                "all", "songs" -> { val s = sortItems(vis); s.forEachIndexed { i, x -> rows.add(itemRow(x, s, i)) }; return rows }
                "playlist" -> {
                    // "Create playlist" always first, then the playlists that already exist
                    rows.add(Row("Create playlist", "New empty playlist", false, null, 0, true, {
                        ask("New playlist", "Playlist name", "") { nm ->
                            val n = nm.trim()
                            if (n.isEmpty()) { toast("Enter a playlist name"); return@ask }
                            pf.plCreate(n, emptyList())
                            buildBody()
                        }
                    }, null, null, 3))
                    for (n in pf.plNames()) {
                        val set = pf.plItems(n)
                        val cnt = vis.count { it.key in set }
                        rows.add(Row(n, "$cnt ${wordOf(cnt)}", false, null, 0, false, { folder = F_PLN + n; buildBody() }, { plSheet(n) }, null, 3))
                    }
                    return rows
                }
                "recent" -> { val s = vis.filter { now - it.added < 7 * 86400 }.take(50); s.forEachIndexed { i, x -> rows.add(itemRow(x, s, i)) }; return rows }
                "mini" -> { val s = sortItems(vis.filter { it.dur in 1..59999 }); s.forEachIndexed { i, x -> rows.add(itemRow(x, s, i)) }; return rows }
                "album" -> {
                    for ((alb, l) in sortGroups(vis.groupBy { it.album }.toList())) {
                        val ar = l.map { it.artist }.filter { it.isNotEmpty() }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""
                        rows.add(groupRow(alb.ifEmpty { "<unknown>" }, ar.ifEmpty { "<unknown>" }, l, F_ALB + alb, 1))
                    }
                    return rows
                }
                "artist" -> {
                    for ((ar, l) in sortGroups(vis.groupBy { it.artist }.toList()))
                        rows.add(groupRow(ar.ifEmpty { "<unknown>" }, "${l.size} ${wordOf(l.size)}", l, F_ART + ar, 2))
                    return rows
                }
                "genres" -> {
                    for ((g, l) in sortGroups(vis.groupBy { it.genre }.toList()))
                        rows.add(groupRow(g.ifEmpty { "Unknown genre" }, "${l.size} ${wordOf(l.size)}", l, F_GEN + g, 2))
                    return rows
                }
            }
        }
        val inFolders: List<Item>
        val loose: List<Item>
        if (showLocked) {
            val pr = vis.partition { it.folderLock || fk(it.folder) in lf }
            inFolders = pr.first
            loose = pr.second
        } else {
            inFolders = vis
            loose = emptyList()
            val rec = vis.filter { now - it.added < 7 * 86400 }.take(20)
            if (rec.isNotEmpty()) rows.add(Row("Recently added", "${rec.size} ${wordOf(rec.size)}", false, null, 0, true, { folder = F_REC; buildBody() }, null))
        }
        for ((f, l) in sortGroups(inFolders.groupBy { it.folder }.toList())) {
            rows.add(
                Row(
                    pf.alias(f), "${l.size} ${wordOf(l.size)} • ${Media.size(l.sumOf { it.size })}",
                    l.any { isNew(it.added) }, null, pf.folderColor(f), false,
                    { folder = f; buildBody() }, { folderSheet(f, l) }, selKey = "f:$f", selItems = l
                )
            )
        }
        val ls = sortItems(loose)
        ls.forEachIndexed { i, x -> rows.add(itemRow(x, ls, i)) }
        return rows
    }

    fun newVH(g: Boolean, sq: Boolean = false): VH {
        val box = if (sq) SquareFrame(this) else FrameLayout(this)
        box.background = rr(pal.tile, dpf(12))
        box.roundClip(dpf(12))
        val ph = ImageView(this)
        val thumb = ImageView(this)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        val dur = label("", 12f, Color.WHITE, true)
        dur.setPadding(dp(6), dp(2), dp(6), dp(2))
        dur.background = rr(0xAA000000.toInt(), dpf(6))
        box.addView(ph, FrameLayout.LayoutParams(dp(if (sq) 64 else 28), dp(if (sq) 64 else 28), Gravity.CENTER))
        box.addView(thumb, FrameLayout.LayoutParams(-1, -1))
        box.addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(6), dp(8)) })
        // thin "watched so far" line under the thumbnail (videos that were started before)
        val prog = ProgressLine(this, pal.bright)
        prog.visibility = View.GONE
        box.addView(prog, FrameLayout.LayoutParams(-1, dp(4), Gravity.BOTTOM))
        val title = label("", 16.5f, pal.text, true)
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        val sub = label("", 14f, pal.sub)
        sub.maxLines = 1
        sub.ellipsize = TextUtils.TruncateAt.END
        sub.setPadding(0, dp(2), 0, 0)
        val badge = label("NEW", 11f, Color.WHITE, true)
        badge.setPadding(dp(7), dp(2), dp(7), dp(2))
        badge.background = rr(pal.newBadge, dpf(5))
        val tr = LinearLayout(this)
        tr.addView(title, lp(0, -2, 1f))
        tr.addView(badge, lp(-2, -2).apply { marginStart = dp(8); topMargin = dp(2) })
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        tc.addView(tr)
        tc.addView(sub)
        val more = iconBtn(Ic.MORE, pal.sub, 40, 22) {}
        if (sq) {
            title.maxLines = 1
            box.clipToOutline = false
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.background = rr(pal.surface, dpf(24), dp(1), pal.line)
            card.roundClip(dpf(24))
            card.addView(box, lp(-1, -2))
            val br = LinearLayout(this)
            br.gravity = Gravity.CENTER_VERTICAL
            br.setPadding(dp(16), dp(10), dp(4), dp(12))
            br.addView(tc, lp(0, -2, 1f))
            br.addView(more)
            card.addView(br)
            val wrap = FrameLayout(this)
            wrap.setPadding(dp(6), dp(6), dp(6), dp(6))
            wrap.addView(card, FrameLayout.LayoutParams(-1, -2))
            val svh = VH(wrap, true, box, ph, thumb, dur, title, sub, badge, more, prog, true)
            wrap.tag = svh
            return svh
        }
        val root = LinearLayout(this)
        root.background = ripple(null, 0f)
        if (g) {
            root.orientation = LinearLayout.VERTICAL
            root.setPadding(dp(8), dp(8), dp(8), dp(8))
            root.addView(box, lp(-1, dp(110)))
            val br = LinearLayout(this)
            br.gravity = Gravity.CENTER_VERTICAL
            br.setPadding(dp(4), dp(6), 0, 0)
            br.addView(tc, lp(0, -2, 1f))
            br.addView(more)
            root.addView(br)
        } else {
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding(dp(16), dp(8), dp(4), dp(8))
            root.addView(box, lp(dp(48), dp(48)))
            tc.setPadding(dp(16), 0, dp(4), 0)
            root.addView(tc, lp(0, -2, 1f))
            root.addView(more)
        }
        val vh = VH(root, g, box, ph, thumb, dur, title, sub, badge, more, prog)
        root.tag = vh
        return vh
    }

    fun bind(vh: VH, r: Row) {
        val x = r.item
        if (!vh.grid) {
            val wide = x != null && x.video
            val w = dp(if (wide) 120 else 48)
            val h = dp(if (wide) 68 else 48)
            val l = vh.box.layoutParams
            if (l.width != w || l.height != h) { l.width = w; l.height = h; vh.box.layoutParams = l }
        }
        vh.title.text = r.title
        vh.sub.text = r.sub
        vh.sub.setTextColor(if (r.accentSub) pal.subAccent else pal.sub)
        vh.badge.visibility = if (r.isNew) View.VISIBLE else View.GONE
        val sk = r.selKey
        val canSel = sk != null && !selBlock
        val picked = sk != null && canSel && selMode && sel.containsKey(sk)
        vh.more.visibility = if (r.menu != null || (selMode && canSel)) View.VISIBLE else View.GONE
        if (selMode && canSel) {
            vh.more.setImageDrawable(PathIcon(if (picked) Ic.CHECK else Ic.REMOVE, if (picked) pal.onSel else pal.sub))
            vh.more.background = if (picked) rr(pal.accent, dpf(20)) else rr(0, dpf(20), dp(2), pal.line)
            vh.more.setOnClickListener { toggleSel(sk!!, r.selItems) }
        } else {
            vh.more.setImageDrawable(PathIcon(Ic.MORE, pal.sub))
            vh.more.background = ripple(null, dpf(20))
            vh.more.setOnClickListener { r.menu?.invoke() }
        }
        vh.root.setBackgroundColor(if (picked) ColorUtils.setAlphaComponent(pal.accent, 46) else Color.TRANSPARENT)
        vh.root.setOnClickListener { if (selMode && canSel) toggleSel(sk!!, r.selItems) else if (!selMode) r.click() }
        if (canSel) vh.root.setOnLongClickListener { toggleSel(sk!!, r.selItems); true }
        else vh.root.setOnLongClickListener(null)
        vh.prog.visibility = View.GONE
        if (x != null && x.video && x.dur > 0) {
            val saved = pf.sp.getLong("pos_" + x.uri, 0L)
            if (saved > 0L) {
                vh.prog.frac = (saved.toFloat() / x.dur).coerceIn(0.03f, 1f)
                vh.prog.visibility = View.VISIBLE
            }
        }
        if (x == null) {
            val ai = r.art
            if (ai != null) {
                vh.dur.visibility = View.GONE
                vh.box.background = rr(pal.tile, if (vh.sq) 0f else dpf(12))
                vh.ph.setImageDrawable(PathIcon(Ic.MUSIC, ColorUtils.setAlphaComponent(pal.sub, 120)))
                vh.thumb.visibility = View.VISIBLE
                loadThumb(vh.thumb, ai)
                return
            }
            vh.thumb.visibility = View.GONE
            vh.dur.visibility = View.GONE
            if (r.kind == 3) {
                vh.ph.setImageDrawable(PathIcon(Ic.PL_PLAY, pal.accent))
                vh.box.background = rr(ColorUtils.blendARGB(pal.tile, pal.accent, 0.15f), dpf(12))
                return
            }
            val ic = if (r.tint != 0) r.tint else ColorUtils.blendARGB(pal.tile, pal.text, 0.35f)
            vh.ph.setImageDrawable(PathIcon(Ic.FOLDER, ic))
            vh.box.background = rr(if (r.tint != 0) ColorUtils.blendARGB(pal.tile, r.tint, 0.2f) else pal.tile, dpf(12))
            return
        }
        vh.box.background = rr(pal.tile, dpf(12))
        vh.ph.setImageDrawable(PathIcon(if (x.video) Ic.MOVIE else Ic.MUSIC, ColorUtils.setAlphaComponent(pal.sub, 120)))
        vh.thumb.visibility = View.VISIBLE
        if (x.video) { vh.dur.visibility = View.VISIBLE; vh.dur.text = Media.time(x.dur) } else vh.dur.visibility = View.GONE
        loadThumb(vh.thumb, x)
    }

    fun loadThumb(th: ImageView, x: Item) {
        th.tag = x.key
        val c = cache.get(x.key)
        if (c != null) { th.setImageBitmap(c); return }
        th.setImageDrawable(null)
        pool.execute {
            try {
                val bm = Art.load(this, x.uri.toString(), if (x.video) -1L else x.id, 360)
                if (bm != null) {
                    cache.put(x.key, bm)
                    runOnUiThread { if (th.tag == x.key) th.setImageBitmap(bm) }
                }
            } catch (e: Exception) {
            }
        }
    }

    // ---------------------------------------------------------------- mini player
    var miniLine: ProgressLine? = null
    val miniTickR = object : Runnable {
        override fun run() {
            val p = AudioEngine.player
            val ln = miniLine
            if (p != null && ln != null && ln.isAttachedToWindow) {
                val d = p.duration
                ln.frac = if (d > 0L) p.currentPosition.toFloat() / d else 0f
                miniHost.postDelayed(this, 500)
            }
        }
    }

    fun miniQueue() {
        val q = AudioEngine.queue
        if (q.isEmpty()) { toast("No queue yet"); return }
        val entries = q.mapIndexed { i, t -> QueueEntry("$i|${t.uri}", t.title) }
        QueueSheet.show(this, "Playing Queue", entries, pal.accent, showMode = true,
            onSelect = { e ->
                val uri = e.key.substringAfter("|")
                val i = AudioEngine.queue.indexOfFirst { it.uri == uri }
                if (i >= 0) { AudioEngine.player?.seekTo(i, 0L); AudioEngine.player?.play() }
            },
            onChange = { changed ->
                val reordered = changed.mapNotNull { e ->
                    e.key.substringBefore("|").toIntOrNull()?.let { q.getOrNull(it) }
                }
                AudioEngine.reorderQueue(this, reordered)
            })
    }

    fun groupSheet(title: String, l: List<Item>) {
        val acts = ArrayList<Act>()
        acts.add(Act(Ic.PLAY, "Play") { val s = sortItems(l); play(s, 0) })
        acts.add(Act(Ic.SHARE, "Send") { sendItems(l) })
        acts.add(Act(Ic.PL_ADD, "Add to playlist") { addPl(l) })
        if (l.isNotEmpty() && l.none { it.video && !it.vault } && l.all { !it.video && it.id > 0 }) {
            acts.add(Act(Ic.EDIT, "Edit tags (all ${l.size})") { tagEditAll(title, l) })
        }
        sheet(pal, null, title, "${l.size} ${wordOf(l.size)}", acts)
    }

    /** Edit tags of every track in an album / artist / folder at once. */
    fun tagEditAll(title: String, l: List<Item>) {
        val tracks = l.filter { !it.video && it.id > 0 }
        if (tracks.isEmpty()) { toast("Cannot edit these files"); return }
        startActivity(
            Intent(this, TagEditActivity::class.java)
                .putExtra("batch_title", title)
                .putExtra("ids", tracks.map { it.id }.toLongArray())
                .putStringArrayListExtra("uris", ArrayList(tracks.map { it.uri.toString() }))
                .putStringArrayListExtra("titles", ArrayList(tracks.map { it.title }))
                .putStringArrayListExtra("artists", ArrayList(tracks.map { it.artist }))
                .putStringArrayListExtra("albums", ArrayList(tracks.map { it.album }))
                .putStringArrayListExtra("genres", ArrayList(tracks.map { it.genre }))
        )
    }

    fun tagEdit(x: Item) {
        startActivity(
            Intent(this, TagEditActivity::class.java).putExtra("id", x.id).putExtra("uri", x.uri.toString())
                .putExtra("title", x.title).putExtra("artist", x.artist).putExtra("album", x.album).putExtra("genre", x.genre)
        )
    }

    // ---------------------------------------------------------------- dialogs / sheets
    val sortOpts = listOf(
        "Name (A–Z)" to (0 to true), "Name (Z–A)" to (0 to false),
        "Newest first" to (1 to false), "Oldest first" to (1 to true),
        "Largest first" to (2 to false), "Smallest first" to (2 to true),
        "Longest first" to (3 to false), "Shortest first" to (3 to true)
    )

    fun sortDialog() {
        val cur = sortOpts.indexOfFirst { it.second.first == pf.sortKey && it.second.second == pf.sortAsc }
        choose("Sort by", sortOpts.map { it.first }, cur) {
            pf.sortKey = sortOpts[it].second.first
            pf.sortAsc = sortOpts[it].second.second
            buildBody()
        }
    }

    fun play(l: List<Item>, i: Int, pip: Boolean = false) {
        if (l.isEmpty()) return
        if (!l[i.coerceIn(0, l.size - 1)].video) {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
            }
            AudioEngine.start(this, l.map { it.toTrack() }, i)
            startActivity(Intent(this, AudioPlayerActivity::class.java))
            return
        }
        if (pip) { startPopup(l.map { it.uri.toString() }, l.map { it.name }, i, -1L); return }
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putStringArrayListExtra("u", ArrayList(l.map { it.uri.toString() }))
                .putStringArrayListExtra("n", ArrayList(l.map { it.name }))
                .putExtra("i", i).putExtra("pip", pip).putExtra("v", video)
        )
    }

    /** "New playlist" first, then every playlist that already exists. */
    fun addPl(l: List<Item>) {
        val keys = l.map { it.key }
        val names = pf.plNames()
        choose("Add to playlist", listOf("+  New playlist") + names, -1) { i ->
            if (i == 0) {
                ask("New playlist", "Playlist name", "") { nm ->
                    val n = nm.trim()
                    if (n.isEmpty()) { toast("Enter a playlist name"); return@ask }
                    pf.plCreate(n, keys)
                    toast("Saved to \"$n\"")
                    if (tab == "playlist") buildBody()
                }
            } else {
                val n = names[i - 1]
                pf.plAdd(n, keys)
                toast("Added to \"$n\"")
                buildBody()
            }
        }
    }

    fun plSheet(n: String) {
        val set = pf.plItems(n)
        val items = all.filter { it.key in set }
        val acts = ArrayList<Act>()
        acts.add(Act(Ic.PLAY, "Play") { if (items.isNotEmpty()) play(sortItems(items), 0) else toast("Playlist is empty") })
        acts.add(Act(Ic.EDIT, "Rename") {
            ask("Rename playlist", "Playlist name", n) { nm ->
                val x = nm.trim()
                if (x.isNotEmpty() && x != n) { pf.plRename(n, x); buildBody() }
            }
        })
        acts.add(Act(Ic.DELETE, "Delete playlist", danger = true, div = true) { pf.plDelete(n); buildBody() })
        sheet(pal, null, n, "${items.size} ${wordOf(items.size)}", acts)
    }

    fun sendItems(l: List<Item>) {
        val type = if (video) "video/*" else "audio/*"
        val i = if (l.size == 1) Intent(Intent.ACTION_SEND).setType(type).putExtra(Intent.EXTRA_STREAM, l[0].uri)
        else Intent(Intent.ACTION_SEND_MULTIPLE).setType(type).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(l.map { it.uri }))
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Send"))
    }

    fun cutter(x: Item, audio: Boolean) {
        startActivity(
            Intent(this, CutterActivity::class.java).putExtra("uri", x.uri.toString()).putExtra("name", x.name)
                .putExtra("dur", x.dur).putExtra("size", x.size).putExtra("audio", audio)
        )
    }

    fun folderSheet(f: String, l: List<Item>) {
        val tile = FrameLayout(this)
        tile.background = rr(pal.tile, dpf(18), dp(2), pal.accent)
        val ic = ImageView(this)
        ic.setImageDrawable(PathIcon(Ic.FOLDER, if (pf.folderColor(f) != 0) pf.folderColor(f) else pal.text))
        tile.addView(ic, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
        val total = Media.size(l.sumOf { it.size })
        val inLocked = showLocked
        val acts = ArrayList<Act>()
        acts.add(Act(Ic.PLAY, "Play") { val s = sortItems(l); play(s, 0) })
        if (!inLocked) acts.add(Act(Ic.SHARE, "Send", div = true) { sendItems(l) })
        acts.add(Act(Ic.EDIT, "Rename") {
            ask("Rename folder", "Folder name", pf.alias(f)) { if (it.isNotBlank()) { pf.setAlias(f, it.trim()); buildBody() } }
        })
        if (!inLocked) acts.add(Act(Ic.PL_ADD, "Add to playlist") { addPl(l) })
        acts.add(Act(Ic.INFO, "Details") {
            val dir = if (inLocked) "Private storage (hidden from gallery and other apps)"
            else try { File(l[0].path).parent ?: "" } catch (e: Exception) { "" }
            message(pf.alias(f), "${l.size} ${wordOf(l.size)}\nTotal size: $total\n$dir")
        })
        acts.add(Act(Ic.PALETTE, "Set Color") {
            swatches("Folder color", folderCols, pf.folderColor(f)) { pf.setFolderColor(f, it); buildBody() }
        })
        if (inLocked) acts.add(Act(Ic.UNLOCK, "Unlock") { unlockItems(l) })
        else acts.add(Act(Ic.LOCK, "Lock") { lockItems(l, true) })
        if (!inLocked) acts.add(Act(Ic.EYE_OFF, "Hide from list", danger = true, div = true) { hideItems(l) })
        acts.add(Act(Ic.DELETE, "Delete", danger = true) { deleteItems(l) })
        sheet(pal, tile, pf.alias(f), "${l.size} ${wordOf(l.size)} • $total", acts)
    }

    val folderCols = intArrayOf(
        0xFFEF5350.toInt(), 0xFFEC407A.toInt(), 0xFFAB47BC.toInt(), 0xFF5C6BC0.toInt(),
        0xFF42A5F5.toInt(), 0xFF26A69A.toInt(), 0xFF66BB6A.toInt(), 0xFFFFCA28.toInt(),
        0xFFFFA726.toInt(), 0xFF8D6E63.toInt(), 0xFF78909C.toInt(), 0xFF9E9E9E.toInt()
    )

    fun itemSheet(x: Item, l: List<Item>, i: Int) {
        val head = ImageView(this)
        head.scaleType = ImageView.ScaleType.CENTER_CROP
        head.background = rr(pal.tile, dpf(if (x.video) 16 else 12))
        head.roundClip(dpf(if (x.video) 16 else 12))
        val c = cache.get(x.key)
        if (c != null) head.setImageBitmap(c)
        else head.setImageDrawable(PathIcon(if (x.video) Ic.MOVIE else Ic.MUSIC, ColorUtils.setAlphaComponent(pal.sub, 140)).also { head.setPadding(dp(16), dp(16), dp(16), dp(16)) })
        val inVault = x.vault
        val lockedNow = inVault || showLocked
        val legacyFolder = !inVault && fk(x.folder) in pf.strs("lockf")
        val acts = ArrayList<Act>()
        acts.add(Act(Ic.PLAY, "Play") { play(l, i) })
        if (x.video) acts.add(Act(Ic.PIP, "Pop-up video") { play(l, i, true) })
        if (!x.video) acts.add(Act(Ic.CUT, "Cut") { cutter(x, true) })
        if (!inVault) acts.add(Act(Ic.SHARE, "Send", div = true) { sendItems(listOf(x)) })
        if (!x.video) acts.add(Act(Ic.TIMER, "Timer") { sleepTimerDialog() })
        acts.add(Act(Ic.EDIT, "Rename") {
            ask("Rename", "File name", x.title) { nm ->
                val ext = if (x.name.contains('.')) "." + x.name.substringAfterLast('.') else ""
                if (nm.isNotBlank()) renameItem(x, nm.trim() + ext)
            }
        })
        if (!x.video && !inVault) acts.add(Act(Ic.EDIT, "Edit tag") { tagEdit(x) })
        if (!inVault) acts.add(Act(Ic.PL_ADD, "Add to playlist") { addPl(listOf(x)) })
        if (!x.video && !inVault) acts.add(Act(Ic.MUSIC, "Set as ringtone") { setRingtone(x.uri.toString()) })
        acts.add(Act(Ic.INFO, "Details") {
            message(
                x.title,
                "Size: ${Media.size(x.size)}\nDuration: ${Media.time(x.dur)}" +
                    (if (x.video) "\nResolution: ${x.w}x${x.h}" else "") +
                    "\nPath: ${if (inVault) "Private storage (hidden from gallery and other apps)" else x.path}"
            )
        })
        if (lockedNow) {
            acts.add(Act(Ic.UNLOCK, if (x.folderLock || legacyFolder) "Unlock folder" else "Unlock") {
                if (x.folderLock) unlockItems(l.filter { it.folder == x.folder && it.folderLock }.ifEmpty { listOf(x) })
                else unlockItems(listOf(x))
            })
        } else {
            acts.add(Act(Ic.LOCK, "Lock") { lockItems(listOf(x), false) })
        }
        if (x.video) {
            acts.add(Act(Ic.CUT, "Video edit") { cutter(x, false) })
        }
        val curPl = folder
        if (curPl != null && curPl.startsWith(F_PLN)) acts.add(Act(Ic.CLOSE, "Remove from playlist") {
            pf.plRemoveItem(curPl.removePrefix(F_PLN), x.key); buildBody()
        })
        acts.add(Act(Ic.DELETE, "Delete", danger = true, div = true) { deleteItems(listOf(x)) })
        if (x.video) sheet(pal, head, x.name, Media.size(x.size), acts)
        else sheet(pal, head, x.title, x.artist.ifEmpty { "<unknown>" }, acts, true)
    }

    // ---------------------------------------------------------------- file operations
    fun doRename(x: Item, nm: String) {
        contentResolver.update(x.uri, ContentValues().apply { put("_display_name", nm) }, null, null)
        toast("Renamed")
        load()
    }

    fun renameItem(x: Item, nm: String) {
        if (x.vault) { Vault.rename(this, x, nm); toast("Renamed"); load(); return }
        try {
            doRename(x, nm)
        } catch (e: SecurityException) {
            pendingRename = Pair(x, nm)
            try {
                val sender = if (Build.VERSION.SDK_INT >= 30) MediaStore.createWriteRequest(contentResolver, listOf(x.uri)).intentSender
                else (e as? RecoverableSecurityException)?.userAction?.actionIntent?.intentSender
                if (sender != null) startIntentSenderForResult(sender, RC_WRITE, null, 0, 0, 0) else toast("Cannot rename this file")
            } catch (e2: Exception) {
                toast("Cannot rename this file")
            }
        } catch (e: Exception) {
            toast("Cannot rename this file")
        }
    }

    fun deleteUris(u: List<Uri>) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startIntentSenderForResult(MediaStore.createDeleteRequest(contentResolver, u).intentSender, RC_DEL, null, 0, 0, 0)
            } else {
                u.forEach { contentResolver.delete(it, null, null) }
                load()
            }
        } catch (e: Exception) {
            toast("Cannot delete: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- lock / hide = private vault
    fun ensurePin(then: () -> Unit) {
        if (pf.pin.isEmpty()) ask("Create a PIN", "At least 4 digits", "", true) {
            if (it.length >= 4) { pf.pin = it; then() } else toast("PIN must be at least 4 digits")
        } else then()
    }

    fun openLocked() {
        ensurePin {
            ask("Enter PIN", "PIN", "", true) {
                if (it == pf.pin) {
                    page = 0; searching = false; folder = null; showLocked = true; render()
                    offerLegacy { }
                } else toast("Wrong PIN")
            }
        }
    }

    fun lockItems(items: List<Item>, folderLock: Boolean) {
        ensurePin { confirmMove("Lock", items) { vaultMove(items, { "lock" }, { folderLock }) } }
    }

    fun hideItems(items: List<Item>) {
        confirmMove("Hide", items) { vaultMove(items, { "hide" }, { true }) }
    }

    fun confirmMove(verb: String, items: List<Item>, go: () -> Unit) {
        val back = if (verb == "Lock") "unlock" else "unhide"
        MaterialAlertDialogBuilder(this).setTitle("$verb ${items.size} ${wordOf(items.size)}?")
            .setMessage(
                "To hide them everywhere, S Player moves the ${wordOf(items.size)} into its private storage. " +
                    "They disappear from the gallery, file manager and every other app until you $back them. " +
                    "Android will ask your permission to remove the originals."
            )
            .setPositiveButton(verb) { _, _ -> go() }
            .setNegativeButton("Cancel", null).show()
    }

    /** Copies the files into the private vault, then asks Android to delete the originals. */
    fun vaultMove(items: List<Item>, modeOf: (Item) -> String, folderLockOf: (Item) -> Boolean) {
        val src = items.filter { !it.vault }
        if (src.isEmpty()) return
        if (Vault.busy || Vault.inFlight.isNotEmpty()) { toast("Please wait, another move is running"); return }
        vaultVerb = if (modeOf(src[0]) == "lock") "locked" else "hidden"
        val d = busy("Moving ${src.size} ${wordOf(src.size)} to private storage…")
        Vault.copyIn(this, src, modeOf, folderLockOf) { moved, err ->
            d.dismiss()
            if (moved == null) {
                Vault.busy = false
                toast("Failed: $err")
                load()
            } else {
                Vault.inFlight = moved
                Vault.deleteQueue.clear()
                Vault.deleteQueue.addAll(moved.map { it.uri })
                removeOriginals()
            }
        }
    }

    fun removeOriginals() {
        val q = Vault.deleteQueue
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startIntentSenderForResult(MediaStore.createDeleteRequest(contentResolver, ArrayList(q)).intentSender, RC_VAULT, null, 0, 0, 0)
                return
            }
            while (q.isNotEmpty()) {
                try {
                    contentResolver.delete(q[0], null, null)
                    q.removeAt(0)
                } catch (e: RecoverableSecurityException) {
                    startIntentSenderForResult(e.userAction.actionIntent.intentSender, RC_VAULT, null, 0, 0, 0)
                    return
                }
            }
            finishVault(true)
        } catch (e: Exception) {
            toast("Cannot remove the originals: ${e.message}")
            finishVault(false)
        }
    }

    fun finishVault(ok: Boolean) {
        val moved = Vault.inFlight
        val left: Set<Uri> = if (Build.VERSION.SDK_INT >= 30) (if (ok) emptySet<Uri>() else moved.map { it.uri }.toSet())
        else Vault.deleteQueue.toSet()
        val good = moved.filter { it.uri !in left }
        val bad = moved.filter { it.uri in left }
        Vault.commit(this, good)
        Vault.rollback(this, bad)
        Vault.inFlight = emptyList()
        Vault.deleteQueue.clear()
        Vault.busy = false
        if (good.isNotEmpty()) {
            // forget the old in-app-only flags of everything that now really lives in the vault
            val lf = pf.strs("lockf"); val li = pf.strs("locki"); val hd = pf.strs("hide")
            for (m in good) {
                li.remove(m.key)
                val k = (if (m.entry.video) "v:" else "a:") + m.entry.folder
                lf.remove(k); hd.remove(k)
            }
            pf.putStrs("lockf", lf); pf.putStrs("locki", li); pf.putStrs("hide", hd)
        }
        toast(if (good.isNotEmpty()) "${good.size} ${wordOf(good.size)} $vaultVerb" else "Cancelled — nothing was moved")
        load()
    }

    /** Unlock / unhide: moves files back into the normal gallery folders. */
    fun unlockItems(items: List<Item>) {
        val legacy = items.filter { !it.vault }
        if (legacy.isNotEmpty()) {
            val s = pf.strs("lockf"); val i = pf.strs("locki")
            legacy.forEach { s.remove(fk(it.folder)); i.remove(it.key) }
            pf.putStrs("lockf", s); pf.putStrs("locki", i)
        }
        val ents = Vault.entriesOf(this, items)
        if (ents.isEmpty()) { toast("Unlocked"); load(); return }
        restoreEntries(ents)
    }

    fun restoreEntries(ents: List<Vault.Entry>) {
        val d = busy("Restoring ${ents.size} ${wordOf(ents.size)}…")
        Vault.restore(this, ents) { ok, err ->
            d.dismiss()
            toast(if (ok > 0) "Restored $ok" + (if (err.isNotEmpty()) " (some failed: $err)" else "") else "Failed: $err")
            load()
        }
    }

    fun deleteItems(l: List<Item>) {
        val v = l.filter { it.vault }
        val r = l.filter { !it.vault }
        if (v.isEmpty()) { deleteUris(r.map { it.uri }); return }
        MaterialAlertDialogBuilder(this).setTitle("Delete ${v.size} ${wordOf(v.size)}?")
            .setMessage("They will be deleted permanently and cannot be recovered.")
            .setPositiveButton("Delete") { _, _ ->
                Vault.delete(this, Vault.entriesOf(this, v))
                toast("Deleted")
                load()
                if (r.isNotEmpty()) deleteUris(r.map { it.uri })
            }
            .setNegativeButton("Cancel", null).show()
    }

    /** Files locked/hidden by older versions were only flagged inside the app (still visible in the gallery). */
    fun offerLegacy(then: () -> Unit) {
        val lf = pf.strs("lockf"); val li = pf.strs("locki"); val hd = pf.strs("hide")
        val locked = all.filter { fk(it.folder) in lf || it.key in li }
        val hidden = all.filter { fk(it.folder) in hd && it !in locked }
        val n = locked.size + hidden.size
        if (n == 0) { then(); return }
        MaterialAlertDialogBuilder(this).setTitle("Hide them everywhere?")
            .setMessage("$n ${wordOf(n)} are hidden only inside S Player, so the gallery and other apps still show them. Move them to private storage so they disappear everywhere?")
            .setPositiveButton("Move") { _, _ ->
                vaultMove(locked + hidden, { if (it in locked) "lock" else "hide" }, { fk(it.folder) in lf || it !in locked })
            }
            .setNegativeButton("Not now") { _, _ -> then() }.show()
    }

    // ---------------------------------------------------------------- settings
    fun settingsView(): View {
        val sv = ScrollView(this)
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(0, 0, 0, dp(24))
        sv.addView(c)
        c.addView(setRow(Ic.LOCK, "Locked", "Access password protected files", null) { openLocked() })
        c.addView(rule())
        c.addView(section("Appearance"))
        c.addView(switchRow(Ic.MOON, "Dark theme", "Switch between light and dark appearance", pf.dark) {
            pf.dark = it
            AppCompatDelegate.setDefaultNightMode(if (it) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
            recreate()
        })
        val dot = View(this)
        dot.background = rr(pal.accent, dpf(20))
        c.addView(setRow(Ic.PALETTE, "Primary color", "Choose your accent color", dot, 40) {
            colorPalette(pf.accent) { pf.accent = it; recreate() }
        })
        c.addView(rule())
        c.addView(section("Video"))
        c.addView(setRow(Ic.EYE_OFF, "Manage hide list", null, null) { hideDialog() })
        c.addView(setRow(Ic.ROTATE, "Video screen orientation", null, null) {
            choose("Video screen orientation", listOf("Auto (sensor)", "Portrait", "Landscape", "By video size"), pf.orient) { pf.orient = it }
        })
        c.addView(setRow(Ic.SPEED, "Long-press speed", "Hold a finger on the video to play at ${fmtSpeedX(pf.holdSpeed)}x", null) {
            speedPanel(pf.holdSpeed) { v -> pf.holdSpeed = v; buildBody() }
        })
        c.addView(switchRow(null, "Save resume time", "Continue playback from where you left", pf.resume) { pf.resume = it })
        c.addView(switchRow(null, "Show last played video", "Show last played video", pf.showLast) { pf.showLast = it })
        c.addView(switchRow(null, "Background play on exit", "Keep the sound playing when you leave the video player", pf.autoBg) { pf.autoBg = it })
        c.addView(switchRow(null, "Auto play next video", "Automatically play next video when current video ends", pf.auto) { pf.auto = it })
        c.addView(rule())
        c.addView(section("Audio"))
        c.addView(setRow(Ic.PLAY_CIRCLE, "Allow continuous background playback", "To prevent playback from being stopped by system, please give necessary permission", null) { batteryPerm() })
        c.addView(setRow(Ic.SORT, "Tab order", "Video and Audio tabs", null) { tabOrderDialog() })
        c.addView(switchRow(Ic.EQ, "Use system equalizer", null, pf.sysEq) { pf.sysEq = it })
        c.addView(switchRow(Ic.MUSIC, "Smart Volume", "Automatically balances loudness for supported tracks.", pf.smartVol) { pf.smartVol = it })
        c.addView(setRow(null, "Exclude tracks less than", "${pf.minSec} Seconds", null) {
            val v = listOf(0, 10, 30, 60, 120)
            choose("Exclude tracks shorter than", v.map { "$it seconds" }, v.indexOf(pf.minSec)) { pf.minSec = v[it]; load(); buildBody() }
        })
        c.addView(switchRow(null, "Broadcast music track", null, pf.broadcast) { pf.broadcast = it })
        c.addView(switchRow(null, "Enable shake", null, pf.shake) { pf.shake = it })
        val acts = listOf("Next track", "Previous track", "Play / Pause")
        c.addView(setRow(null, "Shake action", acts[pf.shakeAction.coerceIn(0, 2)], null) {
            choose("Shake action", acts, pf.shakeAction) { pf.shakeAction = it; buildBody() }
        })
        c.addView(shakeForceRow())
        return sv
    }

    fun shakeForceRow(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(8))
        val t = label("Shake force", 17f, pal.text, true)
        t.setPadding(dp(44), 0, 0, 0)
        col.addView(t)
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        val v = label(pf.shakeForce.toString(), 15f, pal.sub)
        val s = Slider(this)
        s.valueFrom = 10f
        s.valueTo = 100f
        s.stepSize = 1f
        s.value = pf.shakeForce.toFloat().coerceIn(10f, 100f)
        s.addOnChangeListener(Slider.OnChangeListener { _, value, fromUser ->
            if (fromUser) { pf.shakeForce = value.toInt(); v.text = value.toInt().toString() }
        })
        r.addView(s, lp(0, -2, 1f).apply { marginStart = dp(28) })
        r.addView(v, lp(dp(40), -2))
        col.addView(r)
        return col
    }

    fun section(t: String): View {
        val l = label(t, 14f, pal.subAccent, true)
        l.setPadding(dp(16), dp(18), dp(16), dp(6))
        return l
    }

    fun rule(): View {
        val v = View(this)
        v.setBackgroundColor(pal.line)
        v.layoutParams = lp(-1, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(4) }
        return v
    }

    fun setRow(icon: String?, title: String, sub: String?, trail: View?, trailSize: Int = 0, click: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(60)
        r.setPadding(dp(16), dp(10), dp(16), dp(10))
        r.background = ripple(null, 0f)
        val ic = ImageView(this)
        if (icon != null) ic.setImageDrawable(PathIcon(icon, pal.text))
        r.addView(ic, lp(dp(24), dp(24)).apply { marginEnd = dp(20) })
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        tc.addView(label(title, 17f, pal.text, true))
        if (sub != null) {
            val s = label(sub, 14f, pal.sub)
            s.setPadding(0, dp(2), 0, 0)
            tc.addView(s)
        }
        r.addView(tc, lp(0, -2, 1f))
        if (trail != null) r.addView(trail, if (trailSize > 0) lp(dp(trailSize), dp(trailSize)).apply { marginStart = dp(12) } else lp(-2, -2))
        if (click != null) r.setOnClickListener { click() }
        return r
    }

    fun switchRow(icon: String?, title: String, sub: String?, on: Boolean, change: (Boolean) -> Unit): View {
        val sw = MaterialSwitch(this)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, v -> change(v) }
        val r = setRow(icon, title, sub, sw, 0) { sw.toggle() }
        return r
    }

    fun hideDialog() {
        if (pf.pin.isNotEmpty()) ask("Enter PIN", "PIN", "", true) { if (it == pf.pin) hideList() else toast("Wrong PIN") }
        else hideList()
    }

    fun hideList() {
        offerLegacy { hideListReal() }
    }

    fun hideListReal() {
        val ents = Vault.load(this).filter { it.mode == "hide" && !it.pending }
        val groups = ents.groupBy { (if (it.video) "Video • " else "Music • ") + it.folder }.toList().sortedBy { it.first }
        val legacy = pf.strs("hide").toList().sorted()
        if (groups.isEmpty() && legacy.isEmpty()) { toast("No hidden folders"); return }
        val names = (groups.map { "${it.first} (${it.second.size})" } +
            legacy.map { (if (it.startsWith("v:")) "Video • " else "Music • ") + it.substring(2) }).toTypedArray()
        val checked = BooleanArray(names.size) { true }
        MaterialAlertDialogBuilder(this).setTitle("Hidden folders (uncheck to show)")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                val back = ArrayList<Vault.Entry>()
                groups.forEachIndexed { i, g -> if (!checked[i]) back.addAll(g.second) }
                val ls = pf.strs("hide")
                legacy.forEachIndexed { i, k -> if (!checked[groups.size + i]) ls.remove(k) }
                pf.putStrs("hide", ls)
                if (back.isNotEmpty()) restoreEntries(back) else buildBody()
            }
            .setNegativeButton("Cancel", null).show()
    }

    fun batteryPerm() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) toast("Already allowed")
            else startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { toast("Open system settings to allow background playback") }
        }
    }
}
