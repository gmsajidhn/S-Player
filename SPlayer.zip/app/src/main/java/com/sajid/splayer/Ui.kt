package com.sajid.splayer

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.PathParser

object Ic {
    const val ZOOM_IN = "M15.5,14h-0.79l-0.28,-0.27C15.41,12.59 16,11.11 16,9.5 16,5.91 13.09,3 9.5,3S3,5.91 3,9.5 5.91,16 9.5,16c1.61,0 3.09,-0.59 4.23,-1.57l0.27,0.28v0.79l5,4.99L20.49,19l-4.99,-5zM9.5,14C7.01,14 5,11.99 5,9.5S7.01,5 9.5,5 14,7.01 14,9.5 11.99,14 9.5,14zM12,10h-2v2H9v-2H7V9h2V7h1v2h2v1z"
    const val ZOOM_OUT = "M15.5,14h-0.79l-0.28,-0.27C15.41,12.59 16,11.11 16,9.5 16,5.91 13.09,3 9.5,3S3,5.91 3,9.5 5.91,16 9.5,16c1.61,0 3.09,-0.59 4.23,-1.57l0.27,0.28v0.79l5,4.99L20.49,19l-4.99,-5zM9.5,14C7.01,14 5,11.99 5,9.5S7.01,5 9.5,5 14,7.01 14,9.5 11.99,14 9.5,14zM7,9h5v1H7z"
    const val SEARCH = "M15.5,14h-0.79l-0.28,-0.27C15.41,12.59 16,11.11 16,9.5 16,5.91 13.09,3 9.5,3S3,5.91 3,9.5 5.91,16 9.5,16c1.61,0 3.09,-0.59 4.23,-1.57l0.27,0.28v0.79l5,4.99L20.49,19l-4.99,-5zM9.5,14C7.01,14 5,11.99 5,9.5S7.01,5 9.5,5 14,7.01 14,9.5 11.99,14 9.5,14z"
    const val MORE = "M12,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM12,16c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z"
    const val FOLDER = "M10,4H4c-1.1,0 -1.99,0.9 -1.99,2L2,18c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V8c0,-1.1 -0.9,-2 -2,-2h-8l-2,-2z"
    const val PLAY = "M8,5v14l11,-7z"
    const val PAUSE = "M6,19h4V5H6v14zM14,5v14h4V5h-4z"
    const val NEXT = "M6,18l8.5,-6L6,6v12zM16,6v12h2V6h-2z"
    const val PREV = "M6,6h2v12H6zM9.5,12l8.5,6V6z"
    const val BACK = "M20,11H7.83l5.59,-5.59L12,4l-8,8 8,8 1.41,-1.41L7.83,13H20v-2z"
    const val DELETE = "M6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6v12zM19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4z"
    const val EDIT = "M3,17.25V21h3.75L17.81,9.94l-3.75,-3.75L3,17.25zM20.71,7.04c0.39,-0.39 0.39,-1.02 0,-1.41l-2.34,-2.34c-0.39,-0.39 -1.02,-0.39 -1.41,0l-1.83,1.83 3.75,3.75 1.83,-1.83z"
    const val SHARE = "M18,16.08c-0.76,0 -1.44,0.3 -1.96,0.77L8.91,12.7c0.05,-0.23 0.09,-0.46 0.09,-0.7s-0.04,-0.47 -0.09,-0.7l7.05,-4.11c0.54,0.5 1.25,0.81 2.04,0.81 1.66,0 3,-1.34 3,-3s-1.34,-3 -3,-3 -3,1.34 -3,3c0,0.24 0.04,0.47 0.09,0.7L8.04,9.81C7.5,9.31 6.79,9 6,9c-1.66,0 -3,1.34 -3,3s1.34,3 3,3c0.79,0 1.5,-0.31 2.04,-0.81l7.12,4.16c-0.05,0.21 -0.08,0.43 -0.08,0.65 0,1.61 1.31,2.92 2.92,2.92 1.61,0 2.92,-1.31 2.92,-2.92s-1.31,-2.92 -2.92,-2.92z"
    const val PL_ADD = "M14,10H2v2h12v-2zM14,6H2v2h12V6zM18,14v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zM2,16h8v-2H2v2z"
    const val INFO = "M11,7h2v2h-2zM11,11h2v6h-2zM12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,20c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8z"
    const val LOCK = "M18,8h-1V6c0,-2.76 -2.24,-5 -5,-5S7,3.24 7,6v2H6c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V10c0,-1.1 -0.9,-2 -2,-2zM12,17c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2 2,0.9 2,2 -0.9,2 -2,2zM15.1,8H8.9V6c0,-1.71 1.39,-3.1 3.1,-3.1 1.71,0 3.1,1.39 3.1,3.1v2z"
    const val UNLOCK = "M12,17c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM18,8h-1V6c0,-2.76 -2.24,-5 -5,-5S7,3.24 7,6h1.9c0,-1.71 1.39,-3.1 3.1,-3.1 1.71,0 3.1,1.39 3.1,3.1v2H6c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V10c0,-1.1 -0.9,-2 -2,-2zM18,20H6V10h12v10z"
    const val EYE_OFF = "M12,7c2.76,0 5,2.24 5,5 0,0.65 -0.13,1.26 -0.36,1.83l2.92,2.92c1.51,-1.26 2.7,-2.89 3.43,-4.75 -1.73,-4.39 -6,-7.5 -11,-7.5 -1.4,0 -2.74,0.25 -3.98,0.7l2.16,2.16C10.74,7.13 11.35,7 12,7zM2,4.27l2.28,2.28 0.46,0.46C3.08,8.3 1.78,10.02 1,12c1.73,4.39 6,7.5 11,7.5 1.55,0 3.03,-0.3 4.38,-0.84l0.42,0.42L19.73,22 21,20.73 3.27,3 2,4.27zM7.53,9.8l1.55,1.55c-0.05,0.21 -0.08,0.43 -0.08,0.65 0,1.66 1.34,3 3,3 0.22,0 0.44,-0.03 0.65,-0.08l1.55,1.55c-0.67,0.33 -1.41,0.53 -2.2,0.53 -2.76,0 -5,-2.24 -5,-5 0,-0.79 0.2,-1.53 0.53,-2.2zM11.84,9.02l3.15,3.15 0.02,-0.16c0,-1.66 -1.34,-3 -3,-3l-0.17,0.01z"
    const val PALETTE = "M12,3c-4.97,0 -9,4.03 -9,9s4.03,9 9,9c0.83,0 1.5,-0.67 1.5,-1.5 0,-0.39 -0.15,-0.74 -0.39,-1.01 -0.23,-0.26 -0.38,-0.61 -0.38,-0.99 0,-0.83 0.67,-1.5 1.5,-1.5L16,16c2.76,0 5,-2.24 5,-5 0,-4.42 -4.03,-8 -9,-8zM6.5,12c-0.83,0 -1.5,-0.67 -1.5,-1.5S5.67,9 6.5,9 8,9.67 8,10.5 7.33,12 6.5,12zM9.5,8C8.67,8 8,7.33 8,6.5S8.67,5 9.5,5s1.5,0.67 1.5,1.5S10.33,8 9.5,8zM14.5,8c-0.83,0 -1.5,-0.67 -1.5,-1.5S13.67,5 14.5,5s1.5,0.67 1.5,1.5S15.33,8 14.5,8zM17.5,12c-0.83,0 -1.5,-0.67 -1.5,-1.5S16.67,9 17.5,9s1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5z"
    const val MOVIE = "M18,4l2,4h-3l-2,-4h-2l2,4h-3l-2,-4H8l2,4H7L5,4H4c-1.1,0 -1.99,0.9 -1.99,2L2,18c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V4h-4z"
    const val MUSIC = "M12,3v10.55c-0.59,-0.34 -1.27,-0.55 -2,-0.55 -2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4V7h4V3h-6z"
    const val CAST = "M21,3H3c-1.1,0 -2,0.9 -2,2v3h2V5h18v14h-7v2h7c1.1,0 2,-0.9 2,-2V5c0,-1.1 -0.9,-2 -2,-2zM1,18v3h3c0,-1.66 -1.34,-3 -3,-3zM1,14v2c2.76,0 5,2.24 5,5h2c0,-3.87 -3.13,-7 -7,-7zM1,10v2c4.97,0 9,4.03 9,9h2c0,-6.08 -4.93,-11 -11,-11z"
    const val SORT = "M3,18h6v-2H3v2zM3,6v2h18V6H3zM3,13h12v-2H3v2z"
    const val GRID = "M3,3v8h8V3H3zM9,9H5V5h4v4zM3,13v8h8v-8H3zM9,19H5v-4h4v4zM13,3v8h8V3h-8zM19,9h-4V5h4v4zM13,13v8h8v-8h-8zM19,19h-4v-4h4v4z"
    const val LIST = "M4,14h4v-4H4v4zM4,19h4v-4H4v4zM4,9h4V5H4v4zM9,14h12v-4H9v4zM9,19h12v-4H9v4zM9,5v4h12V5H9z"
    const val CLOSE = "M19,6.41L17.59,5 12,10.59 6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 12,13.41 17.59,19 19,17.59 13.41,12z"
    const val CHECK = "M9,16.17L4.83,12l-1.42,1.41L9,19 21,7l-1.41,-1.41z"
    const val CHEV_R = "M10,6L8.59,7.41 13.17,12l-4.58,4.59L10,18l6,-6z"
    const val CHEV_L = "M15.41,7.41L14,6l-6,6 6,6 1.41,-1.41L10.83,12z"
    const val LINK = "M3.9,12c0,-1.71 1.39,-3.1 3.1,-3.1h4V7H7c-2.76,0 -5,2.24 -5,5s2.24,5 5,5h4v-1.9H7c-1.71,0 -3.1,-1.39 -3.1,-3.1zM8,13h8v-2H8v2zM17,7h-4v1.9h4c1.71,0 3.1,1.39 3.1,3.1s-1.39,3.1 -3.1,3.1h-4V17h4c2.76,0 5,-2.24 5,-5s-2.24,-5 -5,-5z"
    const val DNS = "M20,13H4c-0.55,0 -1,0.45 -1,1v6c0,0.55 0.45,1 1,1h16c0.55,0 1,-0.45 1,-1v-6c0,-0.55 -0.45,-1 -1,-1zM7,19c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2 2,0.9 2,2 -0.9,2 -2,2zM20,3H4c-0.55,0 -1,0.45 -1,1v6c0,0.55 0.45,1 1,1h16c0.55,0 1,-0.45 1,-1V4c0,-0.55 -0.45,-1 -1,-1zM7,9c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2 2,0.9 2,2 -0.9,2 -2,2z"
    const val QUEUE = "M15,6H3v2h12V6zM15,10H3v2h12v-2zM3,16h8v-2H3v2zM17,6v8.18c-0.31,-0.11 -0.65,-0.18 -1,-0.18 -1.66,0 -3,1.34 -3,3s1.34,3 3,3 3,-1.34 3,-3V8h3V6h-5z"
    const val PL_PLAY = "M19,9H2v2h17V9zM19,5H2v2h17V5zM2,15h13v-2H2v2zM17,13v6l5,-3 -5,-3z"
    const val PIP = "M19,7h-8v6h8V7zM21,3H3c-1.1,0 -2,0.9 -2,2v14c0,1.1 0.9,1.98 2,1.98h18c1.1,0 2,-0.88 2,-1.98V5c0,-1.1 -0.9,-2 -2,-2zM21,19.01H3V4.98h18v14.03z"
    const val CUT = "M9.64,7.64c0.23,-0.5 0.36,-1.05 0.36,-1.64 0,-2.21 -1.79,-4 -4,-4S2,3.79 2,6s1.79,4 4,4c0.59,0 1.14,-0.13 1.64,-0.36L10,12l-2.36,2.36C7.14,14.13 6.59,14 6,14c-2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4c0,-0.59 -0.13,-1.14 -0.36,-1.64L12,14l7,7h3v-1L9.64,7.64zM6,8c-1.1,0 -2,-0.89 -2,-2s0.9,-2 2,-2 2,0.89 2,2 -0.9,2 -2,2zM6,20c-1.1,0 -2,-0.89 -2,-2s0.9,-2 2,-2 2,0.89 2,2 -0.9,2 -2,2zM12,12.5c-0.28,0 -0.5,-0.22 -0.5,-0.5s0.22,-0.5 0.5,-0.5 0.5,0.22 0.5,0.5 -0.22,0.5 -0.5,0.5zM19,3l-6,6 2,2 7,-7V3z"
    const val AUDIO = "M12,3v9.28c-0.47,-0.17 -0.97,-0.28 -1.5,-0.28C8.01,12 6,14.01 6,16.5S8.01,21 10.5,21c2.31,0 4.2,-1.75 4.45,-4H15V6h4V3h-7z"
    const val BULB = "M9,21c0,0.55 0.45,1 1,1h4c0.55,0 1,-0.45 1,-1v-1H9v1zM12,2C8.14,2 5,5.14 5,9c0,2.38 1.19,4.47 3,5.74V17c0,0.55 0.45,1 1,1h6c0.55,0 1,-0.45 1,-1v-2.26c1.81,-1.27 3,-3.36 3,-5.74 0,-3.86 -3.14,-7 -7,-7zM14.85,13.1l-0.85,0.6V16h-4v-2.3l-0.85,-0.6C7.8,12.16 7,10.63 7,9c0,-2.76 2.24,-5 5,-5s5,2.24 5,5c0,1.63 -0.8,3.16 -2.15,4.1z"
    const val ROTATE = "M16.48,2.52c3.27,1.55 5.61,4.72 5.97,8.48h1.5C23.44,4.84 18.29,0 12,0l-0.66,0.03 3.81,3.81 1.33,-1.32zM10.23,1.75c-0.59,-0.59 -1.54,-0.59 -2.12,0L1.75,8.11c-0.59,0.59 -0.59,1.54 0,2.12l12.02,12.02c0.59,0.59 1.54,0.59 2.12,0l6.36,-6.36c0.59,-0.59 0.59,-1.54 0,-2.12L10.23,1.75zM14.94,21.12L2.88,9.06l6.36,-6.36 12.06,12.06 -6.36,6.36zM7.52,21.48C4.25,19.94 1.91,16.76 1.55,13L0.05,13C0.56,19.16 5.71,24 12,24l0.66,-0.03 -3.81,-3.81 -1.33,1.32z"
    const val VOL = "M3,9v6h4l5,5V4L7,9H3zM16.5,12c0,-1.77 -1.02,-3.29 -2.5,-4.03v8.05c1.48,-0.73 2.5,-2.25 2.5,-4.02zM14,3.23v2.06c2.89,0.86 5,3.54 5,6.71s-2.11,5.85 -5,6.71v2.06c4.01,-0.91 7,-4.49 7,-8.77s-2.99,-7.86 -7,-8.77z"
    const val MUTE = "M16.5,12c0,-1.77 -1.02,-3.29 -2.5,-4.03v2.21l2.45,2.45c0.03,-0.2 0.05,-0.41 0.05,-0.63zM19,12c0,0.94 -0.2,1.82 -0.54,2.64l1.51,1.51C20.63,14.91 21,13.5 21,12c0,-4.28 -2.99,-7.86 -7,-8.77v2.06c2.89,0.86 5,3.54 5,6.71zM4.27,3L3,4.27 7.73,9H3v6h4l5,5v-6.73l4.25,4.25c-0.67,0.52 -1.42,0.93 -2.25,1.18v2.06c1.38,-0.31 2.63,-0.95 3.69,-1.81L19.73,21 21,19.73l-9,-9L4.27,3zM12,4L9.91,6.09 12,8.18V4z"
    const val SPEED = "M20.38,8.57l-1.23,1.85a8,8 0 0,1 -0.22,7.58H5.07A8,8 0 0,1 15.58,6.85l1.85,-1.23A10,10 0 0,0 3.35,19a2,2 0 0,0 1.72,1h13.85a2,2 0 0,0 1.74,-1 10,10 0 0,0 -0.27,-10.44zM10.59,15.41a2,2 0 0,0 2.83,0l5.66,-8.49 -8.49,5.66a2,2 0 0,0 0,2.83z"
    const val EQ = "M10,20h4V4h-4v16zM4,20h4v-8H4v8zM16,9v11h4V9h-4z"
    const val TIMER = "M15,1H9v2h6V1zM11,14h2V8h-2v6zM19.03,7.39l1.42,-1.42c-0.43,-0.51 -0.9,-0.99 -1.41,-1.41l-1.42,1.42C16.07,4.74 14.12,4 12,4c-4.97,0 -9,4.03 -9,9s4.02,9 9,9 9,-4.03 9,-9c0,-2.12 -0.74,-4.07 -1.97,-5.61zM12,20c-3.87,0 -7,-3.13 -7,-7s3.13,-7 7,-7 7,3.13 7,7 -3.13,7 -7,7z"
    const val SWAP = "M6.99,11L3,15l3.99,4v-3H14v-2H6.99v-3zM21,9l-3.99,-4v3H10v2h7.01v3L21,9z"
    const val FLIP = "M15,21h2v-2h-2v2zM19,9h2L21,7h-2v2zM3,5v14c0,1.1 0.9,2 2,2h4v-2H5V5h4V3H5c-1.1,0 -2,0.9 -2,2zM19,3v2h2c0,-1.1 -0.9,-2 -2,-2zM11,23h2V1h-2v22zM19,17h2v-2h-2v2zM15,5h2V3h-2v2zM19,13h2v-2h-2v2zM19,21c1.1,0 2,-0.9 2,-2h-2v2z"
    const val REPLAY = "M12,5V1L7,6l5,5V7c3.31,0 6,2.69 6,6s-2.69,6 -6,6 -6,-2.69 -6,-6H4c0,4.42 3.58,8 8,8s8,-3.58 8,-8 -3.58,-8 -8,-8z"
    const val FIT = "M19,12h-2v3h-3v2h5v-5zM7,9h3V7H5v5h2V9zM21,3H3c-1.1,0 -2,0.9 -2,2v14c0,1.1 0.9,2 2,2h18c1.1,0 2,-0.9 2,-2V5c0,-1.1 -0.9,-2 -2,-2zM21,19.01H3V4.99h18v14.02z"
    const val ADD = "M19,13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"
    const val REMOVE = "M19,13H5v-2h14v2z"
    const val MOON = "M12,3c-4.97,0 -9,4.03 -9,9s4.03,9 9,9 9,-4.03 9,-9c0,-0.46 -0.04,-0.92 -0.1,-1.36 -0.98,1.37 -2.58,2.26 -4.4,2.26 -2.98,0 -5.4,-2.42 -5.4,-5.4 0,-1.81 0.89,-3.42 2.26,-4.4C12.92,3.04 12.46,3 12,3z"
    const val PLAY_CIRCLE = "M10,16.5l6,-4.5 -6,-4.5v9zM12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,20c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8z"
    const val HEART = "M12,21.35l-1.45,-1.32C5.4,15.36 2,12.28 2,8.5 2,5.42 4.42,3 7.5,3c1.74,0 3.41,0.81 4.5,2.09C13.09,3.81 14.76,3 16.5,3 19.58,3 22,5.42 22,8.5c0,3.78 -3.4,6.86 -8.55,11.54L12,21.35z"
    const val HEART_O = "M16.5,3c-1.74,0 -3.41,0.81 -4.5,2.09C10.91,3.81 9.24,3 7.5,3 4.42,3 2,5.42 2,8.5c0,3.78 3.4,6.86 8.55,11.54L12,21.35l1.45,-1.32C18.6,15.36 22,12.28 22,8.5 22,5.42 19.58,3 16.5,3zM12.1,18.55l-0.1,0.1 -0.1,-0.1C7.14,14.24 4,11.39 4,8.5 4,6.5 5.5,5 7.5,5c1.54,0 3.04,0.99 3.57,2.36h1.87C13.46,5.99 14.96,5 16.5,5c2,0 3.5,1.5 3.5,3.5 0,2.89 -3.14,5.74 -7.9,10.05z"
    const val SHUFFLE = "M10.59,9.17L5.41,4 4,5.41l5.17,5.17 1.42,-1.41zM14.5,4l2.04,2.04L4,18.59 5.41,20 17.96,7.46 20,9.5V4h-5.5zM14.83,13.41l-1.41,1.41 3.13,3.13L14.5,20H20v-5.5l-2.04,2.04 -3.13,-3.13z"
    const val REPEAT_ONE = "M7,7h10v3l4,-4 -4,-4v3H5v6h2V7zM17,17H7v-3l-4,4 4,4v-3h12v-6h-2v4zM13,15h-1.1v-4.5h-0.9v-0.9H13V15z"
    const val MORE_H = "M6,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM18,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM12,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z"
    const val WAVE = "M7,18h2V6H7v12zM11,22h2V2h-2v20zM3,14h2v-4H3v4zM15,18h2V6h-2v12zM19,10v4h2v-4h-2z"
    const val DETAILS = "M3,13h2v-2H3v2zM3,17h2v-2H3v2zM3,9h2V7H3v2zM7,13h14v-2H7v2zM7,17h14v-2H7v2zM7,7v2h14V7H7z"
    const val IMAGE = "M21,19V5c0,-1.1 -0.9,-2 -2,-2H5c-1.1,0 -2,0.9 -2,2v14c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2zM8.5,13.5l2.5,3.01L14.5,12l4.5,6H5l3.5,-4.5z"
    const val CHIP = "M15,9H9v6h6V9zM13,13h-2v-2h2v2zM21,11V9h-2V7c0,-1.1 -0.9,-2 -2,-2h-2V3h-2v2h-2V3H9v2H7C5.9,5 5,5.9 5,7v2H3v2h2v2H3v2h2v2c0,1.1 0.9,2 2,2h2v2h2v-2h2v2h2v-2h2c1.1,0 2,-0.9 2,-2v-2h2v-2h-2v-2h2zM17,17H7V7h10v10z"
    const val HEADPHONES = "M12,1c-4.97,0 -9,4.03 -9,9v7c0,1.66 1.34,3 3,3h3v-8H5v-2c0,-3.87 3.13,-7 7,-7s7,3.13 7,7v2h-4v8h3c1.66,0 3,-1.34 3,-3v-7c0,-4.97 -4.03,-9 -9,-9z"
    const val TUNE = "M3,17v2h6v-2H3zM3,5v2h10V5H3zM13,21v-2h8v-2h-8v-2h-2v6h2zM7,9v2H3v2h4v2h2V9H7zM21,13v-2H11v2h10zM15,9h2V7h4V5h-4V3h-2v6z"
    const val REPEAT = "M7,7h10v3l4,-4 -4,-4v3H5v6h2V7zM17,17H7v-3l-4,4 4,4v-3h12v-6h-2v4z"
    const val ORDER = "M3,5h2v2H3zM7,5h14v2H7zM3,11h2v2H3zM7,11h14v2H7zM3,17h2v2H3zM7,17h14v2H7z"
    const val STOP_AFTER = "M12,2a10,10 0,1 0,0 20a10,10 0,0 0,0 -20zM9,9h6v6H9z"
    const val FULLSCREEN = "M7,14H5v5h5v-2H7v-3zM5,10h2V7h3V5H5v5zM17,17h-3v2h5v-5h-2v3zM14,5v2h3v3h2V5h-5z"
    const val DRAG = "M20,9H4v2h16V9zM4,15h16v-2H4v2z"
    const val RESIZE = "M21,11V3h-8l3.29,3.29 -10,10L3,13v8h8l-3.29,-3.29 10,-10z"
}

/** Vector icon drawn straight from Material path data (24x24 viewport), tintable at runtime. */
class PathIcon(data: String, color: Int) : Drawable() {
    private var path: Path = parse(data)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = color }
    private val m = Matrix()
    private val out = Path()

    private fun parse(d: String): Path {
        val p = try { PathParser.createPathFromPathData(d) } catch (e: Exception) { Path() }
        // Fit paths that spill outside the 24x24 box so no icon is ever cut off.
        val r = android.graphics.RectF()
        p.computeBounds(r, true)
        if (!r.isEmpty && (r.left < 0f || r.top < 0f || r.right > 24f || r.bottom > 24f)) {
            val sc = minOf(1f, 23f / maxOf(r.width(), r.height()))
            val fm = Matrix()
            fm.setScale(sc, sc)
            fm.postTranslate(12f - r.centerX() * sc, 12f - r.centerY() * sc)
            p.transform(fm)
        }
        return p
    }

    fun tint(c: Int) { paint.color = c; invalidateSelf() }
    fun set(d: String) { path = parse(d); invalidateSelf() }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        m.reset()
        // 3% safe margin on every side so edges of an icon are never clipped
        m.setScale(b.width() * .94f / 24f, b.height() * .94f / 24f)
        m.postTranslate(b.left + b.width() * .03f, b.top + b.height() * .03f)
        out.reset()
        path.transform(m, out)
        c.drawPath(out, paint)
    }

    override fun getIntrinsicWidth(): Int = -1
    override fun getIntrinsicHeight(): Int = -1
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

class Pal(val dark: Boolean, val accent: Int) {
    val bg = if (dark) 0xFF121316.toInt() else 0xFFFAF8FF.toInt()
    val surface = if (dark) 0xFF1F2025.toInt() else 0xFFF3F0F8.toInt()
    val tile = if (dark) 0xFF2B2C32.toInt() else 0xFFEAE9F0.toInt()
    val text = if (dark) 0xFFE4E2E6.toInt() else 0xFF1B1B1F.toInt()
    val sub = if (dark) 0xFFB4B5C0.toInt() else 0xFF5B5D6B.toInt()
    val line = if (dark) 0xFF3A3B42.toInt() else 0xFFD9D7DF.toInt()
    val danger = if (dark) 0xFFFFB4AB.toInt() else 0xFFBA1A1A.toInt()
    val newBadge = 0xFFD50000.toInt()
    val selTab = ColorUtils.blendARGB(accent, if (dark) Color.WHITE else 0xFF22242F.toInt(), if (dark) 0.35f else 0.55f)
    val onSel = if (dark) 0xFF121316.toInt() else Color.WHITE
    val unselTab = ColorUtils.blendARGB(accent, bg, if (dark) 0.75f else 0.86f)
    val onUnsel = ColorUtils.blendARGB(accent, text, 0.3f)
    val subAccent = ColorUtils.blendARGB(accent, text, 0.15f)
    val bright = ColorUtils.blendARGB(accent, Color.WHITE, 0.3f)
}

object Themes {
    val colors = intArrayOf(
        0xFF3F51B5.toInt(), 0xFF1E88E5.toInt(), 0xFF00897B.toInt(), 0xFF2E7D32.toInt(),
        0xFFEF6C00.toInt(), 0xFFD32F2F.toInt(), 0xFFD81B60.toInt(), 0xFF7B1FA2.toInt()
    )
    private val styles = intArrayOf(
        R.style.Theme_SPlayer, R.style.Theme_SPlayer_Blue, R.style.Theme_SPlayer_Teal, R.style.Theme_SPlayer_Green,
        R.style.Theme_SPlayer_Orange, R.style.Theme_SPlayer_Red, R.style.Theme_SPlayer_Pink, R.style.Theme_SPlayer_Purple
    )
    fun res(accent: Int): Int {
        var best = 0; var bd = Long.MAX_VALUE
        for (k in colors.indices) {
            val c = colors[k]
            val dr = ((accent shr 16) and 255) - ((c shr 16) and 255)
            val dg = ((accent shr 8) and 255) - ((c shr 8) and 255)
            val db = (accent and 255) - (c and 255)
            val d = (dr * dr + dg * dg + db * db).toLong()
            if (d < bd) { bd = d; best = k }
        }
        return styles[best]
    }
}

fun Context.dp(x: Int): Int = (x * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(x: Int): Float = x * resources.displayMetrics.density
fun Context.dpf(x: Float): Float = x * resources.displayMetrics.density

fun rr(color: Int, r: Float, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable = GradientDrawable().apply {
    setColor(color)
    cornerRadius = r
    if (stroke > 0) setStroke(stroke, strokeColor)
}

fun Context.ripple(fill: Int?, r: Float, rc: Int = 0x33808080): Drawable {
    val content: Drawable? = if (fill != null) rr(fill, r) else null
    return RippleDrawable(ColorStateList.valueOf(rc), content, rr(Color.BLACK, r))
}

fun Context.label(s: String, sp: Float, color: Int, medium: Boolean = false): TextView = TextView(this).apply {
    text = s
    textSize = sp
    setTextColor(color)
    if (medium) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
}

fun Context.iconBtn(path: String, tint: Int, box: Int = 44, ic: Int = 24, onClick: () -> Unit): ImageView {
    val v = ImageView(this)
    val pad = dp((box - ic) / 2)
    v.setPadding(pad, pad, pad, pad)
    v.scaleType = ImageView.ScaleType.FIT_CENTER
    v.clipToOutline = false
    v.setImageDrawable(PathIcon(path, tint))
    v.background = ripple(null, dpf(box / 2))
    v.layoutParams = LinearLayout.LayoutParams(dp(box), dp(box))
    v.setOnClickListener { onClick() }
    return v
}

class SquareFrame(c: Context) : android.widget.FrameLayout(c) {
    override fun onMeasure(w: Int, h: Int) { super.onMeasure(w, w) }
}

/** Thin "watched so far" line drawn under a video thumbnail. */
class ProgressLine(c: Context, private val fill: Int, trackColor: Int = 0x99000000.toInt()) : android.view.View(c) {
    var frac = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val track = Paint().apply { color = trackColor }
    private val bar = Paint().apply { color = fill }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, track)
        c.drawRect(0f, 0f, w * frac, h, bar)
    }
}


/** Thin progress line with a round knob. Only a touch on the knob moves the video; a touch anywhere else does nothing. */
class KnobSeek(c: android.content.Context, private val fillColor: Int) : android.view.View(c) {
    var max = 1000
        set(v) { field = maxOf(1, v); invalidate() }
    var progress = 0
        set(v) { if (!dragging) { field = v.coerceIn(0, max); invalidate() } }
    var onStart: (() -> Unit)? = null
    var onSeek: ((Int) -> Unit)? = null
    var onStop: (() -> Unit)? = null
    var enabledSeek = true
    private var dragging = false
    private var cur = 0
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun pad() = 12f * d
    private fun xFor(v: Int) = pad() + v.toFloat() / max * (width - 2 * pad())

    override fun onDraw(cv: Canvas) {
        val y = height - 14f * d
        val x = xFor(if (dragging) cur else progress)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3f * d
        p.color = 0x66FFFFFF
        cv.drawLine(pad(), y, width - pad(), y, p)
        p.color = fillColor
        cv.drawLine(pad(), y, x, y, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        cv.drawCircle(x, y, (if (dragging) 9f else 7f) * d, p)
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        val y = height - 14f * d
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> {
                val kx = xFor(progress)
                if (enabledSeek && Math.abs(e.x - kx) <= 26f * d && Math.abs(e.y - y) <= 26f * d) {
                    dragging = true
                    cur = progress
                    parent.requestDisallowInterceptTouchEvent(true)
                    onStart?.invoke()
                    invalidate()
                }
                return true                       // swallowed: tapping the bar elsewhere does nothing
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                if (!dragging) return true
                cur = (((e.x - pad()) / (width - 2 * pad())).coerceIn(0f, 1f) * max).toInt()
                onSeek?.invoke(cur)
                invalidate()
                return true
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    progress = cur
                    parent.requestDisallowInterceptTouchEvent(false)
                    onStop?.invoke()
                    invalidate()
                }
                return true
            }
        }
        return true
    }
}
