package com.sajid.splayer

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.nio.ByteBuffer
import kotlin.math.abs

fun Context.busy(msg: String): androidx.appcompat.app.AlertDialog {
    val pf = Prefs(this)
    val pal = Pal(pf.dark, pf.accent)
    val row = LinearLayout(this)
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(24), dp(20), dp(24), dp(20))
    row.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(20) })
    row.addView(label(msg, 16f, pal.text))
    return MaterialAlertDialogBuilder(this).setView(row).setCancelable(false).show()
}

/** Video trim and audio export. Completion is reported on the main thread. */
object Exporter {
    fun run(
        c: Context, uri: Uri, name: String, startMs: Long, endMs: Long, audio: Boolean, totalMs: Long = 0L,
        progress: ((Int) -> Unit)? = null, done: (Boolean, String) -> Unit,
        exclude: Boolean = false, bitrate: Int = 192, volume: Int = 100,
        fadeIn: Int = 0, fadeOut: Int = 0, silenceIn: Int = 0, silenceOut: Int = 0
    ) {
        if (audio) { Mp3.run(c, uri, name, startMs, endMs, totalMs, progress, done, exclude, bitrate, volume, fadeIn, fadeOut, silenceIn, silenceOut); return }
        Thread {
            var ok = false
            var msg = ""
            var ex: MediaExtractor? = null
            var mux: MediaMuxer? = null
            var pfd: ParcelFileDescriptor? = null
            var out: Uri? = null
            try {
                ex = MediaExtractor()
                ex.setDataSource(c, uri, null)
                val cv = ContentValues()
                cv.put("_display_name", name.substringBeforeLast('.') + if (audio) "_audio.m4a" else "_cut.mp4")
                cv.put("mime_type", if (audio) "audio/mp4" else "video/mp4")
                cv.put("relative_path", if (audio) "Music/SPlayer" else "Movies/SPlayer")
                val col = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                out = c.contentResolver.insert(col, cv)
                if (out == null) throw Exception("Cannot create output file")
                pfd = c.contentResolver.openFileDescriptor(out, "w")
                if (pfd == null) throw Exception("Cannot open output file")
                mux = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                if (!audio) {
                    try {
                        val r = MediaMetadataRetriever()
                        r.setDataSource(c, uri)
                        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                        r.release()
                        mux.setOrientationHint(rot)
                    } catch (e: Exception) {
                    }
                }
                val map = HashMap<Int, Int>()
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/") || (!audio && mime.startsWith("video/"))) {
                        ex.selectTrack(i)
                        map[i] = mux.addTrack(f)
                    }
                }
                if (map.isEmpty()) throw Exception("No audio/video track found")
                mux.start()
                val stUs = startMs * 1000
                ex.seekTo(stUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val buf = ByteBuffer.allocate(4 * 1024 * 1024)
                val info = MediaCodec.BufferInfo()
                val spanUs = (if (endMs > 0) endMs else totalMs) * 1000 - stUs
                var lastPct = -1
                while (true) {
                    if (ExportJob.cancel) throw Exception("Cancelled")
                    buf.clear()
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) break
                    val t = ex.sampleTime
                    if (endMs > 0 && t > endMs * 1000) break
                    if (progress != null && spanUs > 0 && t >= stUs) {
                        val pc = ((t - stUs) * 100 / spanUs).toInt().coerceIn(0, 99)
                        if (pc != lastPct) { lastPct = pc; progress(pc) }
                    }
                    val tr = map[ex.sampleTrackIndex]
                    if (tr != null) {
                        info.set(0, n, maxOf(0L, t - stUs), ex.sampleFlags)
                        mux.writeSampleData(tr, buf, info)
                    }
                    ex.advance()
                }
                mux.stop()
                ok = true
                msg = if (audio) "Music/SPlayer" else "Movies/SPlayer"
            } catch (e: Exception) {
                msg = e.message ?: "unknown error"
                try { out?.let { c.contentResolver.delete(it, null, null) } } catch (e2: Exception) {}
            } finally {
                try { mux?.release() } catch (e: Exception) {}
                try { pfd?.close() } catch (e: Exception) {}
                try { ex?.release() } catch (e: Exception) {}
            }
            Handler(Looper.getMainLooper()).post { done(ok, msg) }
        }.start()
    }
}

class TrimBar(c: Context, val pal: Pal) : View(c) {
    var dur = 1L
    var audioMode = false
    var waveform = FloatArray(320)
    var start = 0L
    var end = 1L
    var pos = 0L
    val thumbs = arrayOfNulls<Bitmap>(8)
    var onStart: ((Long) -> Unit)? = null
    var onEnd: ((Long) -> Unit)? = null
    var onSeek: ((Long) -> Unit)? = null

    private val pad = c.dp(16).toFloat()
    private val hit = c.dp(30).toFloat()
    private val r6 = c.dpf(6)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = c.dpf(2); strokeCap = Paint.Cap.ROUND }
    private val src = Rect()
    private val dst = RectF()
    private var drag = 0

    private fun x0() = pad
    private fun x1() = width - pad
    private fun xAt(t: Long) = x0() + (x1() - x0()) * (t.toFloat() / maxOf(dur, 1L).toFloat())
    private fun tAt(x: Float): Long = (((x - x0()) / (x1() - x0())) * dur).toLong().coerceIn(0L, dur)

    fun loadThumbs(c: Context, uri: Uri) {
        val d = dur
        Thread {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(c, uri)
                for (i in thumbs.indices) {
                    val t = (d * (i + 0.5) / thumbs.size).toLong() * 1000
                    val bm = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    val sc = if (bm != null) Bitmap.createScaledBitmap(bm, 160, 112, true) else null
                    post { thumbs[i] = sc; invalidate() }
                }
            } catch (e: Exception) {
            } finally {
                try { r.release() } catch (e: Exception) {}
            }
        }.start()
    }

    fun loadAudioWaveform(c: Context, uri: Uri) {
        audioMode = true
        Thread {
            val values = FloatArray(320)
            var ex: MediaExtractor? = null
            var codec: MediaCodec? = null
            try {
                ex = MediaExtractor()
                ex.setDataSource(c, uri, null)
                var track = -1
                var format: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; format = f; break }
                }
                if (track >= 0 && format != null) {
                    ex.selectTrack(track)
                    var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 48000
                    var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
                    codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
                    codec.configure(format, null, null, 0); codec.start()
                    val info = MediaCodec.BufferInfo()
                    var inputDone = false; var outputDone = false
                    var sampleCount = 0L
                    while (!outputDone && sampleCount < 200_000_000L) {
                        if (!inputDone) {
                            val ii = codec.dequeueInputBuffer(10000)
                            if (ii >= 0) {
                                val ib = codec.getInputBuffer(ii)!!
                                val n = ex.readSampleData(ib, 0)
                                val tm = ex.sampleTime
                                if (n < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                                else { codec.queueInputBuffer(ii, 0, n, tm, 0); ex.advance() }
                            }
                        }
                        val oi = codec.dequeueOutputBuffer(info, 10000)
                        if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            val decoded = codec.outputFormat
                            if (decoded.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = decoded.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (decoded.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = decoded.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        } else if (oi >= 0) {
                            if (info.size > 0) {
                                val bb = codec.getOutputBuffer(oi)!!
                                bb.position(info.offset); bb.limit(info.offset + info.size)
                                val shorts = bb.slice().order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                                val n = shorts.remaining()
                                val stride = maxOf(1, n / 8000)
                                var j = 0
                                while (shorts.hasRemaining()) {
                                    val v = shorts.get().toInt()
                                    if (j % stride == 0) {
                                        val totalSamples = maxOf(1L, dur * sampleRate.toLong() * channels.toLong() / 1000L)
                                        val bucket = ((sampleCount * values.size) / totalSamples).toInt().coerceIn(0, values.lastIndex)
                                        values[bucket] = maxOf(values[bucket], kotlin.math.abs(v / 32768f))
                                    }
                                    j++; sampleCount++
                                }
                            }
                            codec.releaseOutputBuffer(oi, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { codec?.stop() } catch (_: Exception) {}
                try { codec?.release() } catch (_: Exception) {}
                try { ex?.release() } catch (_: Exception) {}
            }
            post { waveform = values; invalidate() }
        }.start()
    }

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val top = h * 0.12f
        val bot = h * 0.88f
        val a = x0()
        val b = x1()
        if (audioMode) {
            fill.color = Color.BLACK
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
            val mid = h * 0.52f
            val step = (b - a) / waveform.size
            for (i in waveform.indices) {
                val x = a + i * step
                val amp = maxOf(2f * resources.displayMetrics.density, waveform[i] * h * 0.43f)
                val t = (i.toFloat() / waveform.size * dur).toLong()
                fill.color = if (t in start..end) 0xFF42B9FF.toInt() else 0x553F6F91
                c.drawRect(x, mid - amp, x + maxOf(1f, step * 0.65f), mid + amp, fill)
            }
            fill.color = 0xFFEAEAEA.toInt()
            fill.textSize = 12f * resources.displayMetrics.density
            fill.style = Paint.Style.FILL
            val minuteCount = (dur / 60000L).toInt().coerceAtMost(120)
            for (minute in 0..minuteCount) {
                val x = xAt(minute * 60000L)
                c.drawLine(x, context.dpf(30), x, context.dpf(38), fill)
                c.drawText("${minute}:00", x + context.dpf(4), context.dpf(24), fill)
            }
            val xs = xAt(start); val xe = xAt(end)
            fill.color = 0x99000000.toInt()
            c.drawRect(a, 0f, xs, h, fill); c.drawRect(xe, 0f, b, h, fill)
            line.color = 0xFF42B9FF.toInt(); line.strokeWidth = context.dpf(2)
            c.drawLine(xs, 0f, xs, h, line); c.drawLine(xe, 0f, xe, h, line)
            fill.color = Color.WHITE
            c.drawRoundRect(xs - hit / 2, h * .42f, xs + hit / 2, h * .58f, r6, r6, fill)
            c.drawRoundRect(xe - hit / 2, h * .42f, xe + hit / 2, h * .58f, r6, r6, fill)
            val px = xAt(pos.coerceIn(0L, dur))
            line.color = Color.WHITE; line.strokeWidth = context.dpf(1.5f)
            c.drawLine(px, 0f, px, h, line)
            return
        }
        fill.color = pal.tile
        c.drawRoundRect(a, top, b, bot, r6, r6, fill)
        val n = thumbs.size
        val w = (b - a) / n
        for (i in 0 until n) {
            val bm = thumbs[i] ?: continue
            dst.set(a + i * w, top, a + (i + 1) * w, bot)
            val dr = dst.width() / dst.height()
            val br = bm.width.toFloat() / bm.height
            if (br > dr) {
                val nw = (bm.height * dr).toInt()
                src.set((bm.width - nw) / 2, 0, (bm.width + nw) / 2, bm.height)
            } else {
                val nh = (bm.width / dr).toInt()
                src.set(0, (bm.height - nh) / 2, bm.width, (bm.height + nh) / 2)
            }
            c.drawBitmap(bm, src, dst, null)
        }
        val xs = xAt(start)
        val xe = xAt(end)
        fill.color = 0xAA000000.toInt()
        c.drawRect(a, top, xs, bot, fill)
        c.drawRect(xe, top, b, bot, fill)
        line.color = Color.WHITE
        line.strokeWidth = r6 / 3f
        c.drawLine(xs, top, xe, top, line)
        c.drawLine(xs, bot, xe, bot, line)
        // handles
        fill.color = Color.WHITE
        dst.set(xs - pad, top - r6 / 3f, xs, bot + r6 / 3f)
        c.drawRoundRect(dst, r6, r6, fill)
        dst.set(xe, top - r6 / 3f, xe + pad, bot + r6 / 3f)
        c.drawRoundRect(dst, r6, r6, fill)
        line.color = 0xFF555560.toInt()
        line.strokeWidth = r6 / 2.5f
        val cy = (top + bot) / 2
        val k = r6 * 0.8f
        val lx = xs - pad / 2
        c.drawLine(lx + k / 2, cy - k, lx - k / 2, cy, line)
        c.drawLine(lx - k / 2, cy, lx + k / 2, cy + k, line)
        val rx = xe + pad / 2
        c.drawLine(rx - k / 2, cy - k, rx + k / 2, cy, line)
        c.drawLine(rx + k / 2, cy, rx - k / 2, cy + k, line)
        // playhead
        if (pos in 0..dur) {
            val px = xAt(pos)
            line.color = pal.bright
            line.strokeWidth = r6 / 2f
            c.drawLine(px, top - r6, px, bot + r6, line)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val xs = xAt(start) - pad / 2
                val xe = xAt(end) + pad / 2
                drag = when {
                    abs(e.x - xs) < hit && abs(e.x - xs) <= abs(e.x - xe) -> 1
                    abs(e.x - xe) < hit -> 2
                    else -> 3
                }
                move(e.x)
            }
            MotionEvent.ACTION_MOVE -> move(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                drag = 0
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    private fun move(x: Float) {
        val t = tAt(x)
        when (drag) {
            1 -> { start = maxOf(0L, minOf(t, end - 500L)); onStart?.invoke(start) }
            2 -> { end = minOf(dur, maxOf(t, start + 500L)); onEnd?.invoke(end) }
            3 -> { pos = t; onSeek?.invoke(t) }
        }
        invalidate()
    }
}

class CutterActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var p: ExoPlayer
    lateinit var trim: TrimBar
    lateinit var curTxt: TextView
    lateinit var totTxt: TextView
    lateinit var startTxt: TextView
    lateinit var midTxt: TextView
    lateinit var endTxt: TextView
    lateinit var qualTxt: TextView
    lateinit var sizeTxt: TextView
    lateinit var playIc: PathIcon
    lateinit var headerTxt: TextView
    var uri: Uri = Uri.EMPTY
    var name = ""
    var dur = 0L
    var size = 0L
    var abr = 128000L
    var start = 0L
    var end = 0L
    var audio = false
    val h = Handler(Looper.getMainLooper())

    val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
            setSource(u, nameOf(u), -1L, -1L)
        }
    }

    val tick = object : Runnable {
        override fun run() {
            if (dur > 0) {
                val c = p.currentPosition
                if (p.isPlaying && c >= end) { p.pause(); p.seekTo(start) }
                trim.pos = c
                trim.invalidate()
                curTxt.text = Media.time(c)
                playIc.set(if (p.isPlaying) Ic.PAUSE else Ic.PLAY)
            }
            h.postDelayed(this, 100)
        }
    }

    override fun onCreate(b: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(b)
        audio = intent.getBooleanExtra("audio", false)
        pal = Pal(if (audio) false else pf.dark, pf.accent)
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        val wc = WindowInsetsControllerCompat(window, window.decorView)
        wc.isAppearanceLightStatusBars = !pal.dark
        wc.isAppearanceLightNavigationBars = !pal.dark
        p = ExoPlayer.Builder(this).build()
        buildUi()
        val u = intent.getStringExtra("uri")
        if (u != null) setSource(Uri.parse(u), intent.getStringExtra("name") ?: "", intent.getLongExtra("dur", 0L), intent.getLongExtra("size", 0L))
        else picker.launch(arrayOf(if (audio) "audio/*" else "video/*"))
        h.post(tick)
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(if (audio) 0xFFF7F6FB.toInt() else pal.bg)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(10), dp(12), dp(6))
        bar.addView(iconBtn(Ic.BACK, pal.text) { finish() })
        headerTxt = label(if (audio) "Audio Editor" else "Video cutter", 22f, pal.text, true)
        headerTxt.setPadding(dp(12), 0, 0, 0)
        headerTxt.maxLines = 1
        headerTxt.ellipsize = android.text.TextUtils.TruncateAt.END
        bar.addView(headerTxt, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(iconBtn(Ic.FOLDER, pal.text) { picker.launch(arrayOf(if (audio) "audio/*" else "video/*")) })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        val sv = ScrollView(this)
        sv.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val pv = PlayerView(this)
        pv.useController = false
        pv.player = p
        pv.setBackgroundColor(Color.BLACK)
        col.addView(pv, LinearLayout.LayoutParams(-1, dp(230)))
        if (audio) pv.visibility = View.GONE

        trim = TrimBar(this, pal)
        trim.audioMode = audio
        trim.onStart = { t -> start = t; p.seekTo(t); refreshUi() }
        trim.onEnd = { t -> end = t; p.seekTo(maxOf(start, t - 1500L)); refreshUi() }
        trim.onSeek = { t -> p.seekTo(t) }
        col.addView(trim, LinearLayout.LayoutParams(-1, dp(if (audio) 420 else 64)).apply { topMargin = dp(10) })

        val tr = LinearLayout(this)
        tr.setPadding(dp(18), 0, dp(18), 0)
        curTxt = label("0:00", 15f, pal.text, true)
        totTxt = label("0:00", 15f, pal.text, true)
        tr.addView(curTxt, LinearLayout.LayoutParams(0, -2, 1f))
        tr.addView(totTxt)
        col.addView(tr, LinearLayout.LayoutParams(-1, -2))

        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER
        ctl.addView(iconBtn(Ic.PREV, pal.text, 48, 26) { p.seekTo(start) })
        val pb = iconBtn(Ic.PLAY, pal.text, 56, 34) { togglePlay() }
        playIc = pb.drawable as PathIcon
        ctl.addView(pb, LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(dp(24), 0, dp(24), 0) })
        ctl.addView(iconBtn(Ic.NEXT, pal.text, 48, 26) { p.seekTo(maxOf(start, end - 1500L)) })
        col.addView(ctl, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        if (audio) {
            val opts = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(4)) }
            val mode = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
            val cut = RadioButton(this).apply { text = "Cut"; setTextColor(pal.text); buttonTintList = ColorStateList.valueOf(pal.accent); id = 701 }
            val exclude = RadioButton(this).apply { text = "Exclude"; setTextColor(pal.text); buttonTintList = ColorStateList.valueOf(pal.accent); id = 702 }
            mode.addView(cut); mode.addView(exclude); mode.check(if (pf.b("audio_exclude", false)) 702 else 701)
            mode.setOnCheckedChangeListener { _, id -> pf.put("audio_exclude", id == 702) }
            opts.addView(mode, LinearLayout.LayoutParams(0, -2, 1f))
            opts.addView(iconBtn(Ic.TUNE, pal.text) { advancedAudioOptions() })
            col.addView(opts)
        }

        val sr = LinearLayout(this)
        sr.gravity = Gravity.CENTER_VERTICAL
        sr.setPadding(dp(12), dp(10), dp(12), 0)
        val (sBox, sTxt) = stepper(true)
        val (eBox, eTxt) = stepper(false)
        startTxt = sTxt
        endTxt = eTxt
        midTxt = label("", 12f, pal.text, true)
        midTxt.gravity = Gravity.CENTER
        sr.addView(sBox, LinearLayout.LayoutParams(0, dp(48), 1.3f))
        sr.addView(midTxt, LinearLayout.LayoutParams(0, -2, 1f))
        sr.addView(eBox, LinearLayout.LayoutParams(0, dp(48), 1.3f))
        col.addView(sr, LinearLayout.LayoutParams(-1, -2))

        val sa = label(if (audio) "Output" else "Save as", 20f, pal.text, true)
        sa.setPadding(dp(20), dp(24), dp(20), dp(4))
        col.addView(sa)
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.HORIZONTAL
        rg.setPadding(dp(12), 0, dp(12), 0)
        fun radio(id: Int, t: String): RadioButton {
            val r = RadioButton(this)
            r.id = id
            r.text = t
            r.textSize = 17f
            r.setTextColor(pal.text)
            r.buttonTintList = ColorStateList.valueOf(pal.accent)
            r.setPadding(dp(6), dp(10), dp(24), dp(10))
            return r
        }
        rg.addView(radio(101, "Video"))
        rg.addView(radio(102, "Audio (M4A)"))
        if (intent.getBooleanExtra("audio", false)) { audio = true; rg.check(102) } else rg.check(101)
        rg.setOnCheckedChangeListener { _, id -> audio = id == 102; refreshUi() }
        col.addView(rg)
        if (audio) rg.visibility = View.GONE

        val line = View(this)
        line.setBackgroundColor(pal.line)
        col.addView(line, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(8) })
        val qr = LinearLayout(this)
        qr.gravity = Gravity.CENTER_VERTICAL
        qr.setPadding(dp(20), dp(18), dp(20), dp(6))
        qualTxt = label("", 17f, pal.text, true)
        sizeTxt = label("", 17f, pal.text, true)
        qr.addView(qualTxt, LinearLayout.LayoutParams(0, -2, 1f))
        qr.addView(sizeTxt)
        col.addView(qr)
        val note = label(if (audio) "Audio export • MP3 encoding with the selected trim and effects." else "Lossless cut — the original quality is kept, nothing is re-encoded.", 13f, pal.sub)
        note.setPadding(dp(20), 0, dp(20), dp(20))
        col.addView(note)

        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val saveBtn = LinearLayout(this)
        saveBtn.gravity = Gravity.CENTER
        saveBtn.background = ripple(pal.accent, dpf(28), 0x33FFFFFF)
        val ck = ImageView(this)
        ck.setImageDrawable(PathIcon(Ic.CHECK, Color.WHITE))
        saveBtn.addView(ck, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(10) })
        saveBtn.addView(label("Save", 18f, Color.WHITE, true))
        saveBtn.setOnClickListener { save() }
        root.addView(saveBtn, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(dp(48), dp(8), dp(48), dp(20)) })
        setContentView(root)
    }

    private fun stepper(isStart: Boolean): Pair<LinearLayout, TextView> {
        val l = LinearLayout(this)
        l.gravity = Gravity.CENTER_VERTICAL
        l.background = rr(pal.tile, dpf(10))
        l.addView(iconBtn(Ic.REMOVE, pal.text, 30, 16) { nudge(isStart, -100L) })
        val t = label("", 12f, pal.text, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        l.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        l.addView(iconBtn(Ic.ADD, pal.text, 30, 16) { nudge(isStart, 100L) })
        return Pair(l, t)
    }

    private fun nudge(isStart: Boolean, d: Long) {
        if (dur <= 0) return
        if (isStart) start = minOf(maxOf(start + d, 0L), maxOf(end - 500L, 0L))
        else end = minOf(maxOf(end + d, minOf(start + 500L, dur)), dur)
        trim.start = start
        trim.end = end
        trim.invalidate()
        p.seekTo(if (isStart) start else maxOf(start, end - 1500L))
        refreshUi()
    }

    private fun togglePlay() {
        if (dur <= 0) return
        if (p.isPlaying) p.pause()
        else {
            if (p.currentPosition < start || p.currentPosition >= end - 100) p.seekTo(start)
            p.play()
        }
    }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "video"
            }
        } catch (e: Exception) {
        }
        return "video"
    }

    private fun setSource(u: Uri, nm: String, d: Long, s: Long) {
        uri = u
        name = nm
        headerTxt.text = nm.ifBlank { if (audio) "Audio Editor" else "Video cutter" }
        var dd = d
        if (dd <= 0) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, u)
                dd = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                r.release()
            } catch (e: Exception) {
            }
        }
        var ss = s
        if (ss <= 0) {
            try {
                contentResolver.query(u, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                    if (it.moveToFirst()) ss = it.getLong(0)
                }
            } catch (e: Exception) {
            }
        }
        dur = dd
        size = ss
        start = 0
        end = dur
        p.setMediaItem(MediaItem.fromUri(u))
        p.prepare()
        p.playWhenReady = false
        trim.dur = maxOf(dur, 1L)
        trim.audioMode = audio
        trim.start = 0
        trim.end = maxOf(dur, 1L)
        trim.pos = 0
        for (i in trim.thumbs.indices) trim.thumbs[i] = null
        if (audio) trim.loadAudioWaveform(this, u) else trim.loadThumbs(this, u)
        trim.invalidate()
        Thread {
            var br = 128000L
            val ex = MediaExtractor()
            try {
                ex.setDataSource(this, u, null)
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/") && f.containsKey(MediaFormat.KEY_BIT_RATE)) {
                        br = f.getInteger(MediaFormat.KEY_BIT_RATE).toLong()
                        break
                    }
                }
            } catch (e: Exception) {
            } finally {
                try { ex.release() } catch (e: Exception) {}
            }
            runOnUiThread { abr = br; refreshUi() }
        }.start()
        refreshUi()
    }

    private fun refreshUi() {
        val sel = maxOf(end - start, 0L)
        startTxt.text = Media.stamp(start)
        endTxt.text = Media.stamp(end)
        midTxt.text = Media.stamp(sel)
        totTxt.text = Media.time(dur)
        val bitrate = listOf(96, 128, 160, 192, 256, 320)[pf.i("ae_bitrate_idx", 3).coerceIn(0, 5)]
        val exportDuration = if (audio && pf.b("audio_exclude", false)) maxOf(0L, dur - sel) else sel
        val est = if (audio) (bitrate * 1000L / 8) * exportDuration / 1000 else if (dur > 0) size * sel / dur else 0L
        qualTxt.text = if (audio) "Quality : MP3 $bitrate kbps" else "Quality : Original"
        sizeTxt.text = "Size  " + Media.size2(est)
    }

    private fun advancedAudioOptions() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        fun optionRow(labelText: String, key: String, values: List<String>, defaultIndex: Int): Spinner {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
            val label = label(labelText, 16f, pal.text, true)
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
            sp.setSelection(pf.i(key, defaultIndex).coerceIn(0, values.lastIndex))
            row.addView(sp, LinearLayout.LayoutParams(dp(150), dp(48)))
            box.addView(row)
            val divider = View(this).apply { setBackgroundColor(pal.line) }
            box.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
            return sp
        }
        val fadeIn = optionRow("Fade start", "ae_fade_in", listOf("Off", "0.5 sec", "1 sec", "2 sec", "3 sec", "5 sec"), 0)
        val fadeOut = optionRow("Fade end", "ae_fade_out", listOf("Off", "0.5 sec", "1 sec", "2 sec", "3 sec", "5 sec"), 0)
        val silenceIn = optionRow("Silence start", "ae_silence_in", listOf("Off", "0.5 sec", "1 sec", "2 sec", "3 sec", "5 sec"), 0)
        val silenceOut = optionRow("Silence end", "ae_silence_out", listOf("Off", "0.5 sec", "1 sec", "2 sec", "3 sec", "5 sec"), 0)
        val bitrate = optionRow("Bitrate", "ae_bitrate_idx", listOf("96 kbps", "128 kbps", "160 kbps", "192 kbps", "256 kbps", "320 kbps"), 3)
        val format = optionRow("Format", "ae_format", listOf("MP3 (Default)"), 0)
        val volRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(14), 0, dp(10)) }
        val vr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        vr.addView(label("Volume", 17f, pal.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        val value = label(pf.i("ae_volume", 100).toString(), 16f, pal.text, true)
        vr.addView(value)
        val reset = TextView(this).apply {
            text = "↻"; textSize = 25f; setTextColor(pal.sub)
            gravity = Gravity.CENTER; setPadding(dp(14), 0, dp(4), 0)
        }
        vr.addView(reset)
        volRow.addView(vr)
        val volume = SeekBar(this).apply {
            max = 100; progress = pf.i("ae_volume", 100).coerceIn(0, 100)
            progressTintList = ColorStateList.valueOf(pal.accent)
            thumbTintList = ColorStateList.valueOf(pal.accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) { value.text = v.toString() }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        volRow.addView(volume)
        reset.setOnClickListener { volume.progress = 100 }
        box.addView(volRow)
        MaterialAlertDialogBuilder(this).setTitle("Advanced options").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("OK") { _, _ ->
                pf.put("ae_fade_in", fadeIn.selectedItemPosition)
                pf.put("ae_fade_out", fadeOut.selectedItemPosition)
                pf.put("ae_silence_in", silenceIn.selectedItemPosition)
                pf.put("ae_silence_out", silenceOut.selectedItemPosition)
                pf.put("ae_bitrate_idx", bitrate.selectedItemPosition)
                pf.put("ae_format", format.selectedItemPosition)
                pf.put("ae_volume", volume.progress)
                toast("Audio options saved")
            }.show()
    }

    private var progDlg: androidx.appcompat.app.AlertDialog? = null
    private var progMsg: TextView? = null
    private var progBar: ProgressBar? = null
    private val progCb: () -> Unit = { runOnUiThread { updateProgress() } }

    private fun save() {
        if (dur <= 0) { toast(if (audio) "Pick an audio file first" else "Pick a video first"); return }
        p.pause()
        if (ExportJob.active) { toast("Another save is already running"); showProgress(); return }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)
        ExportJob.active = true
        ExportJob.cancel = false
        ExportJob.pct = 0
        ExportJob.resultMsg = ""
        val i = Intent(this, ExportService::class.java)
            .putExtra("uri", uri.toString()).putExtra("name", name).putExtra("start", start)
            .putExtra("end", if (end >= dur) 0L else end).putExtra("audio", audio).putExtra("total", dur)
            .putExtra("exclude", audio && pf.b("audio_exclude", false))
            .putExtra("bitrate", listOf(96, 128, 160, 192, 256, 320)[pf.i("ae_bitrate_idx", 3).coerceIn(0, 5)])
            .putExtra("volume", pf.i("ae_volume", 100))
            .putExtra("fadeIn", listOf(0, 500, 1000, 2000, 3000, 5000)[pf.i("ae_fade_in", 0).coerceIn(0, 5)])
            .putExtra("fadeOut", listOf(0, 500, 1000, 2000, 3000, 5000)[pf.i("ae_fade_out", 0).coerceIn(0, 5)])
            .putExtra("silenceIn", listOf(0, 500, 1000, 2000, 3000, 5000)[pf.i("ae_silence_in", 0).coerceIn(0, 5)])
            .putExtra("silenceOut", listOf(0, 500, 1000, 2000, 3000, 5000)[pf.i("ae_silence_out", 0).coerceIn(0, 5)])
        androidx.core.content.ContextCompat.startForegroundService(this, i)
        showProgress()
    }

    /** Progress window with a Hide button: the save keeps running in the background. */
    private fun showProgress() {
        progDlg?.dismiss()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(16), dp(24), dp(4))
        val msg = label("Saving… 0%", 16f, pal.text, true)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progressTintList = ColorStateList.valueOf(pal.accent)
        val hint = label("Tap Hide to keep using the app. Saving continues in the background and you get a notification when it is done.", 13f, pal.sub)
        hint.setPadding(0, dp(12), 0, 0)
        box.addView(msg)
        box.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        box.addView(hint)
        progMsg = msg
        progBar = bar
        progDlg = MaterialAlertDialogBuilder(this).setTitle(if (audio) "Exporting audio" else "Cutting video").setView(box)
            .setCancelable(false)
            .setPositiveButton("Hide") { _, _ ->
                toast("Running in the background")
                ExportJob.listeners.remove(progCb)
                progDlg = null
            }
            .setNegativeButton("Cancel") { _, _ ->
                ExportJob.cancel = true
                ExportJob.listeners.remove(progCb)
                progDlg = null
            }.show()
        ExportJob.listeners.add(progCb)
        updateProgress()
    }

    private fun updateProgress() {
        val d = progDlg ?: return
        if (!ExportJob.active) {
            d.dismiss()
            progDlg = null
            ExportJob.listeners.remove(progCb)
            toast(ExportJob.resultMsg)
            return
        }
        progBar?.progress = ExportJob.pct
        progMsg?.text = "Saving… ${ExportJob.pct}%"
    }

    override fun onStop() {
        super.onStop()
        p.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        ExportJob.listeners.remove(progCb)
        h.removeCallbacksAndMessages(null)
        p.release()
    }
}
