package com.sajid.splayer

import android.content.ContentValues
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object Ic2 {
    const val COPY = "M16,1H4C2.9,1 2,1.9 2,3v14h2V3h12V1zM19,5H8C6.9,5 6,5.9 6,7v14c0,1.1 0.9,2 2,2h11c1.1,0 2,-0.9 2,-2V7C21,5.9 20.1,5 19,5zM19,21H8V7h11V21z"
    const val MOVE = "M20,6h-8l-2,-2H4c-1.1,0 -1.99,0.9 -1.99,2L2,18c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V8c0,-1.1 -0.9,-2 -2,-2zM12,17v-3H8v-2h4V9l4,4 -4,4z"
}

// ================================================================== selection mode (folders + files together)

fun MainActivity.selFiles(): List<Item> = sel.values.flatten().distinctBy { it.key }

fun MainActivity.refreshSelUi() {
    buildBar()
    buildSelBar()
    (lvRef?.adapter as? BaseAdapter)?.notifyDataSetChanged()
}

fun MainActivity.toggleSel(key: String, items: List<Item>) {
    if (key in sel) sel.remove(key) else sel[key] = items
    selMode = sel.isNotEmpty()
    refreshSelUi()
}

fun MainActivity.exitSel() {
    selMode = false
    sel.clear()
    refreshSelUi()
}

fun MainActivity.selectAllRows() {
    for (r in curRows) { val k = r.selKey; if (k != null) sel[k] = r.selItems }
    selMode = sel.isNotEmpty()
    refreshSelUi()
}

fun MainActivity.selTopBar(): View {
    val bar = LinearLayout(this)
    bar.gravity = Gravity.CENTER_VERTICAL
    bar.setPadding(dp(8), dp(10), dp(8), dp(6))
    bar.addView(iconBtn(Ic.CLOSE, pal.text) { exitSel() })
    val n = selFiles().size
    val t = label("${sel.size} selected", 19f, pal.text, true)
    t.setPadding(dp(8), 0, 0, 0)
    bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
    if (n > 0) bar.addView(label("$n ${wordOf(n)}", 13f, pal.sub).also { it.setPadding(0, 0, dp(8), 0) })
    val all = iconBtn(Ic.CHECK, pal.accent) { selectAllRows() }
    all.contentDescription = "Select all"
    bar.addView(all)
    return bar
}

private fun MainActivity.selAct(icon: String, text: String, tint: Int, click: () -> Unit): View {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.gravity = Gravity.CENTER
    c.background = ripple(null, dpf(14))
    val ic = ImageView(this)
    ic.setImageDrawable(PathIcon(icon, tint))
    c.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
    val tv = label(text, 10.5f, tint)
    tv.maxLines = 1
    tv.gravity = Gravity.CENTER
    c.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(3) })
    c.setOnClickListener { click() }
    return c
}

fun MainActivity.buildSelBar() {
    selHost.removeAllViews()
    if (!selMode) return
    val bar = LinearLayout(this)
    bar.setPadding(dp(6), dp(8), dp(6), dp(8))
    bar.background = rr(pal.surface, dpf(22), dp(1), pal.line)
    bar.elevation = dpf(10)
    val danger = 0xFFEF5350.toInt()
    fun add(icon: String, text: String, tint: Int, f: () -> Unit) =
        bar.addView(selAct(icon, text, tint, f), LinearLayout.LayoutParams(0, dp(52), 1f))
    add(Ic.DELETE, "Delete", danger) { selDelete() }
    add(Ic2.COPY, "Copy", pal.text) { selDest(false) }
    add(Ic2.MOVE, "Move", pal.text) { selDest(true) }
    add(Ic.SHARE, "Send", pal.text) { selSend() }
    add(Ic.PL_ADD, "Playlist", pal.text) { selPlaylist() }
    add(Ic.QUEUE, "Queue", pal.text) { selQueue() }
    if (!video) add(Ic.EDIT, "Tags", pal.text) { selTags() }
    selHost.addView(bar, FrameLayout.LayoutParams(-1, -2).apply { setMargins(dp(8), dp(4), dp(8), dp(6)) })
}

private fun MainActivity.realFiles(): List<Item> {
    val l = selFiles().filter { !it.vault }
    if (l.isEmpty()) toast("Not available for locked files")
    return l
}

fun MainActivity.selDelete() {
    val l = selFiles()
    if (l.isEmpty()) { toast("No files in the selection"); return }
    MaterialAlertDialogBuilder(this).setTitle("Delete ${l.size} ${wordOf(l.size)}?")
        .setMessage("The selected folders' files and the selected files will be deleted.")
        .setPositiveButton("Delete") { _, _ -> exitSel(); deleteItems(l) }
        .setNegativeButton("Cancel", null).show()
}

fun MainActivity.selSend() {
    val l = realFiles()
    if (l.isNotEmpty()) sendItems(l)
}

fun MainActivity.selPlaylist() {
    val l = realFiles()
    if (l.isNotEmpty()) { addPl(l); exitSel() }
}

fun MainActivity.selQueue() {
    val l = realFiles()
    if (l.isEmpty()) return
    if (video) {
        val q = pf.lastQ.toMutableList()
        val qn = pf.lastQN.toMutableList()
        if (qn.size != q.size) { q.clear(); qn.clear() }
        var added = 0
        for (x in l) { val u = x.uri.toString(); if (u !in q) { q.add(u); qn.add(x.name); added++ } }
        pf.lastQ = q
        pf.lastQN = qn
        if (pf.lastUri.isEmpty() && q.isNotEmpty()) { pf.lastUri = q[0]; pf.lastName = qn[0] }
        toast("$added added to the video queue")
        refreshMini()
    } else {
        AudioEngine.addToQueue(this, l.map { it.toTrack() })
        toast("${l.size} added to the playing queue")
    }
    exitSel()
}

fun MainActivity.selTags() {
    val l = selFiles().filter { !it.video && it.id > 0 }
    when {
        l.isEmpty() -> toast("Select music files to edit tags")
        l.size == 1 -> { tagEdit(l[0]); }
        else -> tagEditAll("${l.size} tracks", l)
    }
}

// ------------------------------------------------------------------ copy / move

fun MainActivity.selDest(move: Boolean) {
    val l = realFiles()
    if (l.isEmpty()) return
    val okPre = if (video) listOf("DCIM/", "Movies/", "Pictures/")
    else listOf("Music/", "Podcasts/", "Ringtones/", "Alarms/", "Notifications/", "Audiobooks/", "Recordings/")
    val rels = all.filter { !it.vault && it.rel.isNotEmpty() && okPre.any { p -> it.rel.startsWith(p) } }.map { it.rel }.distinct().sorted()
    val labels = listOf("+  New folder") + rels.map { it.trimEnd('/') }
    val base = if (video) "Movies/" else "Music/"
    choose(if (move) "Move ${l.size} ${wordOf(l.size)} to" else "Copy ${l.size} ${wordOf(l.size)} to", labels, -1) { i ->
        if (i == 0) {
            ask("New folder", "Folder name", "") { nm ->
                val n = nm.trim().trim('/').replace("\\", "/")
                if (n.isEmpty()) { toast("Enter a folder name"); return@ask }
                copyItems(l, base + n + "/", move)
            }
        } else copyItems(l, rels[i - 1], move)
    }
}

fun MainActivity.copyItems(items: List<Item>, rel: String, move: Boolean) {
    val todo = items.filter { it.rel != rel }
    if (todo.isEmpty()) { toast("Already in that folder"); return }
    val dlg = MaterialAlertDialogBuilder(this)
        .setTitle(if (move) "Moving…" else "Copying…")
        .setMessage("0 / ${todo.size}")
        .setCancelable(false).show()
    val vid = video
    Thread {
        val coll = if (vid) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val done = ArrayList<Item>()
        var failed = 0
        for ((n, x) in todo.withIndex()) {
            var dst: android.net.Uri? = null
            try {
                val ext = x.name.substringAfterLast('.', "").lowercase()
                val mime = x.mime.ifEmpty { android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: (if (vid) "video/mp4" else "audio/mpeg") }
                val cv = ContentValues()
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, x.name)
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
                val d = contentResolver.insert(coll, cv)
                dst = d
                if (d == null) { failed++; continue }
                contentResolver.openInputStream(x.uri)!!.use { i ->
                    contentResolver.openOutputStream(d)!!.use { o -> i.copyTo(o) }
                }
                val cv2 = ContentValues()
                cv2.put(MediaStore.MediaColumns.IS_PENDING, 0)
                contentResolver.update(d, cv2, null, null)
                if (!vid) {
                    val nid = ContentUris.parseId(d)
                    for (k in listOf("title", "artist", "album", "genre", "year", "track", "comment")) {
                        val v = pf.tag(x.id, k)
                        if (v.isNotEmpty()) pf.setTag(nid, k, v)
                    }
                }
                done.add(x)
            } catch (e: Exception) {
                failed++
                try { dst?.let { contentResolver.delete(it, null, null) } } catch (e2: Exception) {}
            }
            runOnUiThread { dlg.setMessage("${n + 1} / ${todo.size}") }
        }
        runOnUiThread {
            dlg.dismiss()
            val verb = if (move) "Moved" else "Copied"
            toast(if (failed == 0) "$verb ${done.size} ${wordOf(done.size)}" else "$verb ${done.size}, $failed failed")
            exitSel()
            if (move && done.isNotEmpty()) deleteUris(done.map { it.uri }) else load()
        }
    }.start()
}

// ================================================================== premium mini player (music + video, every folder)

fun MainActivity.openLastVideo() {
    val u = pf.lastUri
    if (u.isEmpty()) return
    val q = pf.lastQ
    val qn = pf.lastQN
    val ix = q.indexOf(u)
    val us = if (ix >= 0) q else listOf(u)
    val ns = if (ix >= 0 && qn.size == q.size) qn else listOf(pf.lastName)
    startActivity(
        Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra("u", ArrayList(us))
            .putStringArrayListExtra("n", ArrayList(ns))
            .putExtra("i", maxOf(ix, 0)).putExtra("v", true)
    )
}

/** Floating glass-like card: cover - name - queue - big round play/pause - close, with a thin progress line. */
fun MainActivity.premiumBar(
    title: String, sub: String, playing: Boolean, withProgress: Boolean,
    loadArt: (ImageView) -> Unit, onOpen: () -> Unit, onQueue: () -> Unit, onToggle: () -> Unit, onClose: () -> Unit
): View {
    val outer = FrameLayout(this)
    outer.setPadding(dp(10), dp(4), dp(10), dp(8))
    val card = FrameLayout(this)
    val g = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(ColorUtils.blendARGB(pal.surface, pal.accent, if (pal.dark) .34f else .22f), pal.surface)
    )
    g.cornerRadius = dpf(24)
    g.setStroke(dp(1), ColorUtils.setAlphaComponent(pal.accent, 90))
    card.background = g
    card.roundClip(dpf(24))
    card.elevation = dpf(10)

    val row = LinearLayout(this)
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(10), dp(9), dp(6), dp(11))
    val art = ImageView(this)
    art.scaleType = ImageView.ScaleType.CENTER_CROP
    art.background = rr(pal.tile, dpf(16))
    art.roundClip(dpf(16))
    art.setImageDrawable(PathIcon(if (withProgress) Ic.MUSIC else Ic.MOVIE, ColorUtils.setAlphaComponent(pal.sub, 150)).also { art.setPadding(dp(13), dp(13), dp(13), dp(13)) })
    row.addView(art, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(12) })
    loadArt(art)
    val tc = LinearLayout(this)
    tc.orientation = LinearLayout.VERTICAL
    val t1 = label(title, 16f, pal.text, true)
    t1.maxLines = 1
    t1.ellipsize = android.text.TextUtils.TruncateAt.END
    val t2 = label(sub, 13f, pal.sub)
    t2.maxLines = 1
    t2.ellipsize = android.text.TextUtils.TruncateAt.END
    tc.addView(t1)
    tc.addView(t2)
    row.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
    row.addView(iconBtn(Ic.QUEUE, pal.text, 42, 22) { onQueue() })
    val tg = ImageView(this)
    tg.setImageDrawable(PathIcon(if (playing) Ic.PAUSE else Ic.PLAY, if (ColorUtils.calculateLuminance(pal.accent) > .55) 0xFF121316.toInt() else Color.WHITE))
    tg.setPadding(dp(10), dp(10), dp(10), dp(10))
    tg.background = rr(pal.accent, dpf(24))
    tg.elevation = dpf(3)
    tg.setOnClickListener { onToggle() }
    row.addView(tg, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(2); marginEnd = dp(2) })
    row.addView(iconBtn(Ic.CLOSE, pal.sub, 40, 20) { onClose() })
    tc.setOnClickListener { onOpen() }
    art.setOnClickListener { onOpen() }
    card.addView(row, FrameLayout.LayoutParams(-1, -2))
    if (withProgress) {
        val ln = ProgressLine(this, pal.accent)
        miniLine = ln
        card.addView(ln, FrameLayout.LayoutParams(-1, dp(3), Gravity.BOTTOM))
    }
    outer.addView(card, FrameLayout.LayoutParams(-1, -2))
    return outer
}

fun MainActivity.refreshMini() {
    if (!miniReady()) return
    miniHost.removeCallbacks(miniTickR)
    miniHost.removeAllViews()
    miniLine = null
    if (searching || page != 0 || !permOk) return
    val t = AudioEngine.current
    if (t != null) {
        val bar = premiumBar(
            t.title, t.shownArtist, AudioEngine.player?.isPlaying == true, true,
            { art ->
                val cached = cache.get("a" + t.id)
                if (cached != null) art.setImageBitmap(cached)
                else Thread {
                    val bm = Art.load(this, t.uri, t.id, 200)
                    if (bm != null) runOnUiThread { art.setPadding(0, 0, 0, 0); art.setImageBitmap(bm) }
                }.start()
            },
            { startActivity(Intent(this, AudioPlayerActivity::class.java)) },
            { miniQueue() },
            { AudioEngine.toggle() },
            { AudioEngine.stop(this) }
        )
        miniHost.addView(bar, FrameLayout.LayoutParams(-1, -2))
        miniHost.post(miniTickR)
        return
    }
    if (video && pf.showLast && pf.lastUri.isNotEmpty() && !showLocked) {
        val u = pf.lastUri
        val saved = pf.sp.getLong("pos_$u", 0L)
        val bar = premiumBar(
            pf.lastName.substringBeforeLast('.'), if (saved > 0L) "Resume from " + Media.time(saved) else "Continue watching", false, false,
            { art ->
                Thread {
                    try {
                        val bm = Art.load(this, u, -1L, 200)
                        if (bm != null) runOnUiThread { art.setPadding(0, 0, 0, 0); art.setImageBitmap(bm) }
                    } catch (e: Exception) {}
                }.start()
            },
            { openLastVideo() }, { videoQueue() }, { openLastVideo() },
            { pf.lastUri = ""; refreshMini() }
        )
        miniHost.addView(bar, FrameLayout.LayoutParams(-1, -2))
    }
}
