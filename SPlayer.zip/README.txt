S Player v3 - Android video/music player (Material 3 UI).
Upload all files to a GitHub repo (main branch). Actions > Build S Player APK builds app-debug.apk (artifact S-Player-APK).

New in v3: private vault for Lock/Hide, real ID3 tag writing, round static cover, floating resizable pop-up, background export, resume bars.

v3.1: new player control layout, named playlists, thumbnail progress line.

v3.2: fixed signing key (app/splayer.jks) - APKs from every build update over each other. Do not delete this file.

Updated implementation notes:
- All in-app audio/video Playing Queue sheets use a draggable handle on the left and a remove control on the right. Reorder/remove changes are saved.
- Audio Player uses a radial cover visualizer, a single repeat/shuffle cycle control, and an audio-only Favourites playlist action.
- Primary colour settings include preset swatches and a custom HEX colour entry.
- Audio Editor includes decoded PCM waveform display, Cut/Exclude selection, trim handles, fade/silence/volume/bitrate controls and MP3 export.
- Video playback keeps a slim seek progress line visible when the main controls auto-hide.

GitHub Actions:
- The Android project is located in the SPlayer/ directory.
- The workflow installs Java 17, Android SDK platform 34 and Gradle 8.7, then builds SPlayer/app/build/outputs/apk/debug/app-debug.apk.

v3.4:
- Video: 3-dot menu order = Timer, Background play, Playback, A-B repeat, Info, Delete, Send. Double tap left/right shows the half-screen bubble with chevrons and +10s / +20s ... Long press on the video plays at a hold speed (default 3x, change it in Settings > Video > Long-press speed).
- Speed screen (0.25x - 8x slider + preset buttons) is shared by video and music (music: 3-dot menu > Speed).
- Music: live radial spectrum ring around the round cover is always on; Equalizer screen (ON switch, presets, 5 vertical bands, Reverb, BassBooster, Virtualizer); Timer button shows the remaining time; album/artist/folder > menu > "Edit tags (all N)" edits every track together.
- Mini player: thumbnail, name, queue, play/pause, close with a progress line.
- Icons are auto-fitted so none are cut off.

v3.4.1: smaller double-tap bubble; system media session (lock screen / Bluetooth / headset controls) for music and video; "Open with S Player" now works from file managers and gallery for more audio/video files; video "continue watching" bar uses the same mini-player look.

v3.5: auto background play when leaving the video player (Settings > Background play on exit); popup player progress line is seekable; premium floating mini player for music and video in every folder; long-press selection of folders + files (Delete, Copy, Move, Send, Playlist, Queue, Tags for music).

v3.5.1: smaller APK - the workflow now builds the signed *release* APK (R8 code shrinking + unused resources removed, phone ABIs only, English/Bangla library strings). Same signing key, same features.

v3.6:
- Mini player (music + video) is now smaller: plain black (dark mode) / white (light mode) card, play/pause is an icon without a background circle. The video mini player has the same look with a progress line.
- System media card: music AND video now show in the phone's Control Center / lock screen / Bluetooth controls (title, cover, play/pause/next/previous). Allow notifications for S Player on Android 13+.
- Copy / Move: new option "Choose any other folder in phone" (system folder picker, with its own "create new folder" button) besides the existing Music/Movies folders and "+ New folder".
