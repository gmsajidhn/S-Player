S Player v3 - Android video/music player (Material 3 UI).
Upload all files to a GitHub repo (main branch). Actions > Build S Player APK builds app-debug.apk (artifact S-Player-APK).

New in v3: private vault for Lock/Hide, real ID3 tag writing, round static cover, floating resizable pop-up, background export, resume bars.

v3.1: new player control layout, named playlists, thumbnail progress line.

v3.2: fixed signing key (app/splayer.jks) - APKs from every build update over each other. Do not delete this file.

Updated implementation notes:
- All in-app audio/video Playing Queue sheets use a draggable handle on the left and a remove control on the right. Reorder/remove changes are saved.
- Audio Player uses a radial cover visualizer, a single repeat/shuffle cycle control, and an audio-only Favourites playlist action.
- Primary colour settings include preset swatches and a custom HEX colour entry.
- Audio Editor includes decoded PCM waveform display, Cut/Exclude selection, trim handles, fade/silence/volume/bitrate controls and MP3 export.
- Video playback keeps a slim seek progress line visible when the main controls auto-hide.

GitHub Actions:
- The Android project is located in the SPlayer/ directory.
- The workflow installs Java 17, Android SDK platform 34 and Gradle 8.7, then builds SPlayer/app/build/outputs/apk/debug/app-debug.apk.

v3.4:
- Video: 3-dot menu order = Timer, Background play, Playback, A-B repeat, Info, Delete, Send. Double tap left/right shows the half-screen bubble with chevrons and +10s / +20s ... Long press on the video plays at a hold speed (default 3x, change it in Settings > Video > Long-press speed).
- Speed screen (0.25x - 8x slider + preset buttons) is shared by video and music (music: 3-dot menu > Speed).
- Music: live radial spectrum ring around the round cover is always on; Equalizer screen (ON switch, presets, 5 vertical bands, Reverb, BassBooster, Virtualizer); Timer button shows the remaining time; album/artist/folder > menu > "Edit tags (all N)" edits every track together.
- Mini player: thumbnail, name, queue, play/pause, close with a progress line.
- Icons are auto-fitted so none are cut off.

v3.4.1: smaller double-tap bubble; system media session (lock screen / Bluetooth / headset controls) for music and video; "Open with S Player" now works from file managers and gallery for more audio/video files; video "continue watching" bar uses the same mini-player look.

v3.5: auto background play when leaving the video player (Settings > Background play on exit); popup player progress line is seekable; premium floating mini player for music and video in every folder; long-press selection of folders + files (Delete, Copy, Move, Send, Playlist, Queue, Tags for music).

v3.5.1: smaller APK - the workflow now builds the signed *release* APK (R8 code shrinking + unused resources removed, phone ABIs only, English/Bangla library strings). Same signing key, same features.

v72543.0 (Sajid Player): premium icon, MP4/MP3 Save as in Video Edit.

v3.6:
- Mini player (music + video) is now smaller: plain black (dark mode) / white (light mode) card, play/pause is an icon without a background circle. The video mini player has the same look with a progress line.
- System media card: music AND video now show in the phone's Control Center / lock screen / Bluetooth controls (title, cover, play/pause/next/previous). Allow notifications for S Player on Android 13+.
- Copy / Move: new option "Choose any other folder in phone" (system folder picker, with its own "create new folder" button) besides the existing Music/Movies folders and "+ New folder".

v3.7:
- Music player: background is the app background (no gradient); icons/text follow the light/dark theme; play/pause is only the icon (no circle). Same for the floating popup player.
- Vertical swipe on the music cover changes the volume smoothly (follows the finger) and shows a pill with 0-100%.
- Video volume gesture also shows 0-100% and follows the finger smoothly.
- Double-tap seek animation redesigned: compact round glass bubble with ripple, animated chevrons and "10 sec" text (no more tall oval).
- Icons are drawn with a small safe margin so none is clipped.

v72543.0 (Sajid Player): premium icon, MP4/MP3 Save as in Video Edit.

v3.6:
- Mini players: video "continue watching" bar sits above the music mini player (music stays at the bottom).
- "Video to audio" removed. "Video cutter" renamed "Video edit": tap the arrow handles to move the cut edge to the white playhead, quality slider re-encodes to a smaller file (far right = original, lossless).
- Audio editor: zoom +/- and pinch zoom, handle time tags, info line (Hz / kbps / length), selection length in the middle, compact bottom controls.
- Editor folder button lists only folders/files inside the player (no phone file picker). Copy/Move no longer offers the phone folder picker.
- Playlist tab: "Create playlist" first, then existing playlists.
- Equalizer is a bottom panel over the player.

v3.6:
- Seek bar: the knob keeps the exact grab point and glides to the finger (no shaking when a finger rests on it); the time bubble has a fixed width; ticks every 120 ms.
- Video and music keep their own playback speed. Custom equalizer curve is saved on its own (presets never overwrite it; tap "Custom" to bring it back).
- A video playing in the background stays in the VIDEO mini player (live time + progress, play/pause, queue); it never shows in the music player. Its saved position updates every second.
- Video queue rows show a thumbnail and the duration.
- The NEW tag of a video / song disappears after it has been played once.
- Settings > Player controls: Seek bar style (line / knob colour, thickness, size) separately for the main player, the pop-up player and the line shown when icons are hidden; Video player layout (drag every icon, change its size; portrait and landscape separately).
- Two-finger pinch on the video resizes it, the percentage is shown (Fit button resets).
- Video playlists and music playlists are separate (old playlists stay with music).

v3.6.1:
- Video player layout editor is now full screen (same geometry as the player, portrait and landscape separate). Every item can be dragged and resized: icons, title, current / total time and the seek bar (size = length).
- Main player seek bar: line thickness / knob size from Settings now really apply (the track used to fill the whole bar height). Time texts have a fixed width, so the bar no longer shakes while dragging.
- Every video, song and folder can be hidden or locked on its own (item menu: Lock / Hide from list). Settings > Manage hide list now lists every hidden file separately (folder row switches all its files).

Lock v4: Lock now only puts a "." in front of the file name (file stays on the phone, nothing is copied into the app, survives uninstall). Locked screen lists the dot-files; Unlock removes the ".". Needs "All files access". Hide function removed.
Locked screen opens with app PIN or the phone lock.
v4.1: folder lock renames the folder to .Folder (marker file .splayer_lock inside); equalizer: + Save custom equalizers (long-press to delete).
Seek bar style: side gap slider per bar; Settings > Video: Auto play on tap switch.
