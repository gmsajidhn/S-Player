# MP3 encoder uses native (JNI) methods
-keep class com.naman14.androidlame.** { *; }
-keepclassmembers class * { native <methods>; }
# do not stop the build for optional classes referenced by libraries
-ignorewarnings
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn com.google.errorprone.annotations.**
