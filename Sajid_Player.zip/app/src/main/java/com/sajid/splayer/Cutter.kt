package com.sajid.splayer

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.nio.ByteBuffer
import kotlin.math.abs

fun Context.busy(msg: String): androidx.appcompat.app.AlertDialog {
    val pf = Prefs(this)
    val pal = Pal(pf.dark, pf.accent)
    val row = LinearLayout(this)
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(24), dp(20), dp(24), dp(20))
    row.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(20) })
    row.addView(label(msg, 16f, pal.text))
    return MaterialAlertDialogBuilder(this).setView(row).setCancelable(false).show()
}

/** Video trim and audio export. Completion is reported on the main thread. */
object Exporter {
    /** Smaller / lower quality video: re-encodes with the chosen video bitrate (Media3 Transformer). */
    private fun reencode(
        c: Context, uri: Uri, name: String, startMs: Long, endMs: Long, totalMs: Long, vbps: Int, abps: Int,
        progress: ((Int) -> Unit)?, done: (Boolean, String) -> Unit
    ) {
        val main = Handler(Looper.getMainLooper())
        main.post {
            val tmp = java.io.File(c.cacheDir, "vedit_" + System.currentTimeMillis() + ".mp4")
            val finished = java.util.concurrent.atomic.AtomicBoolean(false)
            val stop = if (endMs > 0) endMs else totalMs
            // Include = keep [start, end]; Exclude = keep everything except [start, end]
            val segs = ArrayList<Pair<Long, Long>>()
            if (VideoEditSpec.exclude) {
                if (startMs > 0L) segs.add(Pair(0L, startMs))
                if (totalMs > 0L && stop < totalMs - 50L) segs.add(Pair(stop, totalMs))
            } else segs.add(Pair(startMs, stop))
            if (segs.isEmpty()) { done(false, "Nothing is left to save (everything is excluded)"); return@post }
            val span = maxOf(1L, segs.fold(0L) { a, sg -> a + (sg.second - sg.first) })
            val expected = maxOf(1L, (vbps + abps).toLong() * span / 8000L)
            try {
                val items = ArrayList<androidx.media3.transformer.EditedMediaItem>()
                for (sg in segs) {
                    val clip = MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(sg.first)
                        .setEndPositionMs(sg.second)
                        .build()
                    val mi = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()
                    items.add(
                        androidx.media3.transformer.EditedMediaItem.Builder(mi)
                            .setEffects(androidx.media3.transformer.Effects(emptyList(), OverlayRender.videoEffects(c, uri)))
                            .build()
                    )
                }
                val comp = androidx.media3.transformer.Composition.Builder(
                    androidx.media3.transformer.EditedMediaItemSequence(items)
                ).build()
                val enc = androidx.media3.transformer.DefaultEncoderFactory.Builder(c)
                    .setRequestedVideoEncoderSettings(
                        androidx.media3.transformer.VideoEncoderSettings.Builder().setBitrate(vbps).build()
                    )
                    .setEnableFallback(true)
                    .build()
                val tr = androidx.media3.transformer.Transformer.Builder(c)
                    .setEncoderFactory(enc)
                    .addListener(object : androidx.media3.transformer.Transformer.Listener {
                        override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult) {
                            finished.set(true)
                            Thread {
                                var ok = false
                                var msg = ""
                                var out: Uri? = null
                                try {
                                    val cv = ContentValues()
                                    cv.put("_display_name", name.substringBeforeLast('.') + "_edit.mp4")
                                    cv.put("mime_type", "video/mp4")
                                    cv.put("relative_path", "Movies/SPlayer")
                                    out = c.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                                    if (out == null) throw Exception("Cannot create output file")
                                    c.contentResolver.openOutputStream(out)!!.use { os -> tmp.inputStream().use { it.copyTo(os) } }
                                    ok = true
                                    msg = "Movies/SPlayer"
                                } catch (e: Exception) {
                                    msg = e.message ?: "unknown error"
                                    try { out?.let { c.contentResolver.delete(it, null, null) } } catch (e2: Exception) {}
                                } finally {
                                    tmp.delete()
                                }
                                main.post { done(ok, msg) }
                            }.start()
                        }

                        override fun onError(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                            finished.set(true)
                            tmp.delete()
                            done(false, exportException.message ?: "encode error")
                        }
                    })
                    .build()
                tr.start(comp, tmp.absolutePath)
                val poll = object : Runnable {
                    override fun run() {
                        if (finished.get()) return
                        if (ExportJob.cancel) {
                            finished.set(true)
                            try { tr.cancel() } catch (e: Exception) {}
                            tmp.delete()
                            done(false, "Cancelled")
                            return
                        }
                        progress?.invoke((tmp.length() * 100 / expected).toInt().coerceIn(0, 99))
                        main.postDelayed(this, 500)
                    }
                }
                main.postDelayed(poll, 500)
            } catch (e: Exception) {
                finished.set(true)
                tmp.delete()
                done(false, e.message ?: "unknown error")
            }
        }
    }

    fun run(
        c: Context, uri: Uri, name: String, startMs: Long, endMs: Long, audio: Boolean, totalMs: Long = 0L,
        progress: ((Int) -> Unit)? = null, done: (Boolean, String) -> Unit,
        exclude: Boolean = false, bitrate: Int = 192, volume: Int = 100,
        fadeIn: Int = 0, fadeOut: Int = 0, silenceIn: Int = 0, silenceOut: Int = 0,
        videoBps: Int = 0, audioBps: Int = 128000
    ) {
        if (!audio && (videoBps > 0 || VideoEditSpec.active())) { reencode(c, uri, name, startMs, endMs, totalMs, videoBps, audioBps, progress, done); return }
        if (audio) { Mp3.run(c, uri, name, startMs, endMs, totalMs, progress, done, exclude, bitrate, volume, fadeIn, fadeOut, silenceIn, silenceOut); return }
        Thread {
            var ok = false
            var msg = ""
            var ex: MediaExtractor? = null
            var mux: MediaMuxer? = null
            var pfd: ParcelFileDescriptor? = null
            var out: Uri? = null
            try {
                ex = MediaExtractor()
                ex.setDataSource(c, uri, null)
                val cv = ContentValues()
                cv.put("_display_name", name.substringBeforeLast('.') + if (audio) "_audio.m4a" else "_cut.mp4")
                cv.put("mime_type", if (audio) "audio/mp4" else "video/mp4")
                cv.put("relative_path", if (audio) "Music/SPlayer" else "Movies/SPlayer")
                val col = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                out = c.contentResolver.insert(col, cv)
                if (out == null) throw Exception("Cannot create output file")
                pfd = c.contentResolver.openFileDescriptor(out, "rw")
                if (pfd == null) throw Exception("Cannot open output file")
                mux = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                if (!audio) {
                    try {
                        val r = MediaMetadataRetriever()
                        r.setDataSource(c, uri)
                        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                        r.release()
                        mux.setOrientationHint(rot)
                    } catch (e: Exception) {
                    }
                }
                val map = HashMap<Int, Int>()
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/") || (!audio && mime.startsWith("video/"))) {
                        try {
                            map[i] = mux.addTrack(f)
                            ex.selectTrack(i)
                        } catch (e: Exception) {
                            if (mime.startsWith("video/")) throw Exception("Video format not supported for lossless save. Move the quality slider left and save again.")
                        }
                    }
                }
                if (map.isEmpty()) throw Exception("No audio/video track found")
                mux.start()
                val stUs = startMs * 1000
                ex.seekTo(stUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val buf = ByteBuffer.allocate(4 * 1024 * 1024)
                val info = MediaCodec.BufferInfo()
                val spanUs = (if (endMs > 0) endMs else totalMs) * 1000 - stUs
                var lastPct = -1
                while (true) {
                    if (ExportJob.cancel) throw Exception("Cancelled")
                    buf.clear()
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) break
                    val t = ex.sampleTime
                    if (endMs > 0 && t > endMs * 1000) break
                    if (progress != null && spanUs > 0 && t >= stUs) {
                        val pc = ((t - stUs) * 100 / spanUs).toInt().coerceIn(0, 99)
                        if (pc != lastPct) { lastPct = pc; progress(pc) }
                    }
                    val tr = map[ex.sampleTrackIndex]
                    if (tr != null) {
                        info.set(0, n, maxOf(0L, t - stUs), ex.sampleFlags)
                        mux.writeSampleData(tr, buf, info)
                    }
                    ex.advance()
                }
                mux.stop()
                ok = true
                msg = if (audio) "Music/SPlayer" else "Movies/SPlayer"
            } catch (e: Throwable) {
                msg = e.message ?: e.javaClass.simpleName
                try { out?.let { c.contentResolver.delete(it, null, null) } } catch (e2: Exception) {}
            } finally {
                try { mux?.release() } catch (e: Exception) {}
                try { pfd?.close() } catch (e: Exception) {}
                try { ex?.release() } catch (e: Exception) {}
            }
            Handler(Looper.getMainLooper()).post { done(ok, msg) }
        }.start()
    }
}

class TrimBar(c: Context, val pal: Pal) : View(c) {
    var dur = 1L
    var audioMode = false
    var exclude = false
    var info = ""
    var waveform = FloatArray(1200)
    var start = 0L
    var end = 1L
    var pos = 0L
    var vs = 0L          // zoom window start (audio)
    var vd = 0L          // zoom window length (audio), 0 = whole file
    val thumbs = arrayOfNulls<Bitmap>(10)
    var onStart: ((Long) -> Unit)? = null
    var onEnd: ((Long) -> Unit)? = null
    var onSeek: ((Long) -> Unit)? = null
    var onEdge: (() -> Unit)? = null

    private val pad = c.dp(16).toFloat()
    private val hit = c.dp(36).toFloat()
    private val r6 = c.dpf(6)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = c.dpf(2); strokeCap = Paint.Cap.ROUND }
    private val src = Rect()
    private val dst = RectF()
    private var drag = 0
    private var downX = 0f
    private var downVs = 0L
    private var moved = false
    private var pinPos = 0L          // white line position when the finger went down on an arrow / grip
    private val slop = c.dp(24).toFloat()
    private val scaler = android.view.ScaleGestureDetector(c, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: android.view.ScaleGestureDetector): Boolean { zoomBy(d.scaleFactor, tAt(d.focusX)); return true }
    })

    fun vDur(): Long = if (!audioMode || vd <= 0L || vd >= dur) maxOf(dur, 1L) else vd
    fun isZoomed() = audioMode && vDur() < dur
    private fun vStart(): Long = if (isZoomed()) vs.coerceIn(0L, dur - vDur()) else 0L
    private fun x0() = pad
    private fun x1() = width - pad
    private fun xAt(t: Long) = x0() + (x1() - x0()) * ((t - vStart()).toFloat() / vDur().toFloat())
    private fun tAt(x: Float): Long = (vStart() + ((x - x0()) / (x1() - x0())) * vDur()).toLong().coerceIn(0L, dur)

    /** + / - buttons and pinch: make the waveform bigger or smaller. */
    fun zoomBy(f: Float, focusT: Long = vStart() + vDur() / 2) {
        if (!audioMode || dur <= 0) return
        val old = vDur()
        val nd = (old / f).toLong().coerceIn(minOf(3000L, dur), dur)
        val frac = (focusT - vStart()).toFloat() / old
        vd = nd
        vs = (focusT - (frac * nd).toLong()).coerceIn(0L, maxOf(0L, dur - nd))
        invalidate()
    }

    fun loadThumbs(c: Context, uri: Uri) {
        val d = dur
        Thread {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(c, uri)
                for (i in thumbs.indices) {
                    val t = (d * (i + 0.5) / thumbs.size).toLong() * 1000
                    val bm = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    val sc = if (bm != null) Bitmap.createScaledBitmap(bm, 160, 112, true) else null
                    post { thumbs[i] = sc; invalidate() }
                }
            } catch (e: Exception) {
            } finally {
                try { r.release() } catch (e: Exception) {}
            }
        }.start()
    }

    fun loadAudioWaveform(c: Context, uri: Uri) {
        audioMode = true
        Thread {
            val values = FloatArray(1200)
            var ex: MediaExtractor? = null
            var codec: MediaCodec? = null
            try {
                ex = MediaExtractor()
                ex.setDataSource(c, uri, null)
                var track = -1
                var format: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; format = f; break }
                }
                if (track >= 0 && format != null) {
                    ex.selectTrack(track)
                    var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 48000
                    var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
                    codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
                    codec.configure(format, null, null, 0); codec.start()
                    val info = MediaCodec.BufferInfo()
                    var inputDone = false; var outputDone = false
                    var sampleCount = 0L
                    while (!outputDone && sampleCount < 200_000_000L) {
                        if (!inputDone) {
                            val ii = codec.dequeueInputBuffer(10000)
                            if (ii >= 0) {
                                val ib = codec.getInputBuffer(ii)!!
                                val n = ex.readSampleData(ib, 0)
                                val tm = ex.sampleTime
                                if (n < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                                else { codec.queueInputBuffer(ii, 0, n, tm, 0); ex.advance() }
                            }
                        }
                        val oi = codec.dequeueOutputBuffer(info, 10000)
                        if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            val decoded = codec.outputFormat
                            if (decoded.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = decoded.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (decoded.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = decoded.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        } else if (oi >= 0) {
                            if (info.size > 0) {
                                val bb = codec.getOutputBuffer(oi)!!
                                bb.position(info.offset); bb.limit(info.offset + info.size)
                                val shorts = bb.slice().order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                                val n = shorts.remaining()
                                val stride = maxOf(1, n / 8000)
                                var j = 0
                                while (shorts.hasRemaining()) {
                                    val v = shorts.get().toInt()
                                    if (j % stride == 0) {
                                        val totalSamples = maxOf(1L, dur * sampleRate.toLong() * channels.toLong() / 1000L)
                                        val bucket = ((sampleCount * values.size) / totalSamples).toInt().coerceIn(0, values.lastIndex)
                                        values[bucket] = maxOf(values[bucket], kotlin.math.abs(v / 32768f))
                                    }
                                    j++; sampleCount++
                                }
                            }
                            codec.releaseOutputBuffer(oi, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { codec?.stop() } catch (_: Exception) {}
                try { codec?.release() } catch (_: Exception) {}
                try { ex?.release() } catch (_: Exception) {}
            }
            post { waveform = values; invalidate() }
        }.start()
    }

    private fun tag(c: Canvas, text: String, x: Float, y: Float, leftOfX: Boolean) {
        val d = resources.displayMetrics.density
        fill.style = Paint.Style.FILL
        fill.textSize = 13f * d
        val tw = fill.measureText(text)
        val w = tw + 12f * d
        val l = if (leftOfX) x - w + 4f * d else x - 4f * d
        fill.color = 0xFFFF0000.toInt()
        c.drawRoundRect(l, y - 12f * d, l + w, y + 12f * d, 12f * d, 12f * d, fill)
        fill.color = Color.WHITE
        c.drawText(text, l + 6f * d, y + 5f * d, fill)
    }

    private fun grip(c: Canvas, x: Float, top: Boolean) {
        val d = resources.displayMetrics.density
        val w = 66f * d
        val h = 36f * d
        val y0 = if (top) 34f * d else height - 78f * d
        fill.style = Paint.Style.FILL
        fill.color = 0xFFF2F2F2.toInt()
        c.drawRoundRect(x - w / 2, y0, x + w / 2, y0 + h, 4f * d, 4f * d, fill)
        // little pointer towards the line
        val p = android.graphics.Path()
        if (top) { p.moveTo(x - 7f * d, y0 + h); p.lineTo(x + 7f * d, y0 + h); p.lineTo(x, y0 + h + 8f * d) }
        else { p.moveTo(x - 7f * d, y0); p.lineTo(x + 7f * d, y0); p.lineTo(x, y0 - 8f * d) }
        p.close()
        c.drawPath(p, fill)
        line.color = Color.BLACK
        line.strokeWidth = 2.2f * d
        for (k in -2..2) c.drawLine(x + k * 6f * d, y0 + 8f * d, x + k * 6f * d, y0 + h - 8f * d, line)
        fill.color = 0xFF999999.toInt()
        val cy = y0 + h / 2
        val l = android.graphics.Path(); l.moveTo(x - 24f * d, cy); l.lineTo(x - 18f * d, cy - 5f * d); l.lineTo(x - 18f * d, cy + 5f * d); l.close(); c.drawPath(l, fill)
        val r = android.graphics.Path(); r.moveTo(x + 24f * d, cy); r.lineTo(x + 18f * d, cy - 5f * d); r.lineTo(x + 18f * d, cy + 5f * d); r.close(); c.drawPath(r, fill)
    }

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val top = h * 0.12f
        val bot = h * 0.88f
        val a = x0()
        val b = x1()
        val d = resources.displayMetrics.density
        if (audioMode) {
            fill.style = Paint.Style.FILL
            fill.color = Color.BLACK
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
            val mid = h * 0.52f
            val vD = vDur()
            val v0 = vStart()
            val barW = (b - a) * (dur.toFloat() / waveform.size) / vD
            for (i in waveform.indices) {
                val t = (i.toLong() * dur / waveform.size)
                if (t < v0 - dur / waveform.size || t > v0 + vD) continue
                val x = xAt(t)
                val amp = maxOf(1.5f * d, waveform[i] * h * 0.36f)
                val inside = t in start..end
                fill.color = if (inside != exclude) 0xFF42B9FF.toInt() else 0xFF2B3050.toInt()
                c.drawRect(x, mid - amp, x + maxOf(1f, barW * 0.7f), mid + amp, fill)
            }
            // time ruler
            fill.color = 0xFFEAEAEA.toInt()
            fill.textSize = 13f * d
            val steps = longArrayOf(1000, 2000, 5000, 10000, 15000, 30000, 60000, 120000, 300000, 600000, 1800000, 3600000)
            val pxPerMs = (b - a) / vD.toFloat()
            val step = steps.firstOrNull { it * pxPerMs >= 80f * d } ?: steps.last()
            var tk = (v0 / step) * step
            while (tk <= v0 + vD) {
                if (tk >= v0) {
                    val x = xAt(tk)
                    c.drawLine(x, 26f * d, x, 34f * d, fill)
                    c.drawText(Media.time(tk), x - fill.measureText(Media.time(tk)) / 2, 20f * d, fill)
                }
                tk += step
            }
            val xs = xAt(start)
            val xe = xAt(end)
            line.color = 0xFF2E86C1.toInt()
            line.strokeWidth = 1.2f * d
            line.pathEffect = android.graphics.DashPathEffect(floatArrayOf(6f * d, 4f * d), 0f)
            c.drawLine(xs, 0f, xs, h - 24f * d, line)
            c.drawLine(xe, 0f, xe, h - 24f * d, line)
            line.pathEffect = null
            tag(c, Media.time(start), xs, h * 0.66f, true)
            tag(c, Media.time(end), xe, h * 0.40f, false)
            grip(c, xs, true)
            grip(c, xe, false)
            val px = xAt(pos.coerceIn(0L, dur))
            if (px in a..b) {
                line.color = Color.WHITE
                line.strokeWidth = 1.5f * d
                c.drawLine(px, 0f, px, h - 24f * d, line)
            }
            fill.color = Color.WHITE
            fill.textSize = 15f * d
            c.drawText(info, (width - fill.measureText(info)) / 2, h - 6f * d, fill)
            return
        }
        fill.color = pal.tile
        c.drawRoundRect(a, top, b, bot, r6, r6, fill)
        val n = thumbs.size
        val w = (b - a) / n
        for (i in 0 until n) {
            val bm = thumbs[i] ?: continue
            dst.set(a + i * w, top, a + (i + 1) * w, bot)
            val dr = dst.width() / dst.height()
            val br = bm.width.toFloat() / bm.height
            if (br > dr) {
                val nw = (bm.height * dr).toInt()
                src.set((bm.width - nw) / 2, 0, (bm.width + nw) / 2, bm.height)
            } else {
                val nh = (bm.width / dr).toInt()
                src.set(0, (bm.height - nh) / 2, bm.width, (bm.height + nh) / 2)
            }
            c.drawBitmap(bm, src, dst, null)
        }
        val xs = xAt(start)
        val xe = xAt(end)
        fill.color = 0xAA000000.toInt()
        if (exclude) c.drawRect(xs, top, xe, bot, fill)
        else { c.drawRect(a, top, xs, bot, fill); c.drawRect(xe, top, b, bot, fill) }
        line.color = Color.WHITE
        line.strokeWidth = r6 / 3f
        c.drawLine(xs, top, xe, top, line)
        c.drawLine(xs, bot, xe, bot, line)
        // handles
        fill.color = Color.WHITE
        dst.set(xs - pad, top - r6 / 3f, xs, bot + r6 / 3f)
        c.drawRoundRect(dst, r6, r6, fill)
        dst.set(xe, top - r6 / 3f, xe + pad, bot + r6 / 3f)
        c.drawRoundRect(dst, r6, r6, fill)
        line.color = 0xFF555560.toInt()
        line.strokeWidth = r6 / 2.5f
        val cy = (top + bot) / 2
        val k = r6 * 0.8f
        val lx = xs - pad / 2
        c.drawLine(lx - k / 2, cy - k, lx + k / 2, cy, line)
        c.drawLine(lx + k / 2, cy, lx - k / 2, cy + k, line)
        val rx = xe + pad / 2
        c.drawLine(rx + k / 2, cy - k, rx - k / 2, cy, line)
        c.drawLine(rx - k / 2, cy, rx + k / 2, cy + k, line)
        // playhead
        if (pos in 0..dur) {
            val px = xAt(pos)
            line.color = Color.WHITE
            line.strokeWidth = r6 / 1.6f
            c.drawLine(px, top - r6 * 1.5f, px, bot + r6 * 1.5f, line)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (audioMode) {
            scaler.onTouchEvent(e)
            if (scaler.isInProgress || e.pointerCount > 1) { drag = 0; return true }
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val d = resources.displayMetrics.density
                if (audioMode) {
                    // grips: start grip on top, end grip at the bottom; touching anywhere else moves the white line
                    val xs = xAt(start)
                    val xe = xAt(end)
                    val topGrip = e.y < 78f * d
                    val botGrip = e.y > height - 100f * d
                    drag = when {
                        topGrip && abs(e.x - xs) < 40f * d -> 1
                        botGrip && abs(e.x - xe) < 40f * d -> 2
                        else -> 3
                    }
                } else {
                    // arrow handles sit just outside the strip; the strip itself moves the white line
                    val cs = xAt(start) - pad / 2
                    val ce = xAt(end) + pad / 2
                    val reach = pad / 2 + 16f * d
                    drag = when {
                        abs(e.x - cs) < reach && abs(e.x - cs) <= abs(e.x - ce) -> 1
                        abs(e.x - ce) < reach -> 2
                        else -> 3
                    }
                }
                pinPos = pos
                downX = e.x
                downVs = vStart()
                moved = false
                if (drag == 3 && !isZoomed()) { moved = true; move(e.x) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && abs(e.x - downX) > slop) moved = true
                if (moved) move(e.x)
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    when (drag) {
                        // tap on the arrow handles: the cut edge jumps to the white playhead line
                        1 -> if (pinPos < end - 500L) { start = maxOf(0L, pinPos); onEdge?.invoke() }
                        2 -> if (pinPos > start + 500L) { end = minOf(dur, pinPos); onEdge?.invoke() }
                        3 -> { pos = tAt(downX); onSeek?.invoke(pos) }
                    }
                    invalidate()
                }
                // arrow / grip touches never move the white line: it stays exactly where it was
                if ((drag == 1 || drag == 2) && pos != pinPos) { pos = pinPos; onSeek?.invoke(pinPos); invalidate() }
                drag = 0
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                drag = 0
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    private fun move(x: Float) {
        val t = tAt(x)
        when (drag) {
            1 -> { start = maxOf(0L, minOf(t, end - 500L)); onStart?.invoke(start) }
            2 -> { end = minOf(dur, maxOf(t, start + 500L)); onEnd?.invoke(end) }
            3 -> {
                if (isZoomed()) {
                    val dt = ((downX - x) / (x1() - x0()) * vDur()).toLong()
                    vs = (downVs + dt).coerceIn(0L, maxOf(0L, dur - vDur()))
                } else { pos = t; onSeek?.invoke(t) }
            }
        }
        invalidate()
    }
}

class CutterActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var p: ExoPlayer
    lateinit var trim: TrimBar
    lateinit var curTxt: TextView
    lateinit var totTxt: TextView
    lateinit var startTxt: TextView
    lateinit var midTxt: TextView
    lateinit var endTxt: TextView
    lateinit var qualTxt: TextView
    lateinit var sizeTxt: TextView
    lateinit var playIc: PathIcon
    lateinit var headerTxt: TextView
    var uri: Uri = Uri.EMPTY
    var name = ""
    var dur = 0L
    var size = 0L
    var abr = 128000L
    var srate = 0
    var start = 0L
    var end = 0L
    var audio = false
    val h = Handler(Looper.getMainLooper())

    var asMp3 = false
    var vProg = 90
    var mProg = 30
    var qPct = 100                       // video quality slider: 100 = original (lossless cut)
    lateinit var qSeek: SeekBar
    lateinit var modeCut: RadioButton
    var ov: EditOverlayView? = null
    var pvRef: PlayerView? = null
    var cropBar: LinearLayout? = null
    private val imgPick = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            val bm = OverlayRender.decode(this, u)
            if (bm == null) toast("Cannot open this picture")
            else {
                val o = VOverlay(image = bm, size = 0.3f, alpha = 1f)
                overlayDialog(o, true)
            }
        }
    }

    /** Folder button: shows only the folders / files that are inside this player (no phone file picker). */
    private fun pickFromPlayer() {
        Thread {
            val all = Media.load(this, !audio)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                val groups = all.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() }
                if (groups.isEmpty()) { toast(if (audio) "No audio found" else "No videos found"); return@runOnUiThread }
                choose(if (audio) "Audio folders" else "Video folders", groups.map { it.first + "  (" + it.second.size + ")" }, -1) { gi ->
                    val files = groups[gi].second.sortedBy { it.name.lowercase() }
                    choose(groups[gi].first, files.map { it.name }, -1) { fi ->
                        val x = files[fi]
                        setSource(x.uri, x.name, x.dur, x.size)
                    }
                }
            }
        }.start()
    }

    val tick = object : Runnable {
        override fun run() {
            if (dur > 0) {
                val c = p.currentPosition
                if (!audio && VideoEditSpec.exclude) {
                    if (p.isPlaying && c >= start && c < end) { if (end >= dur - 50L) { p.pause(); p.seekTo(0L) } else p.seekTo(end) }
                } else if (p.isPlaying && c >= end) { p.pause(); p.seekTo(start) }
                ov?.invalidate()
                trim.pos = c
                trim.invalidate()
                curTxt.text = if (audio) clock(c) else Media.time(c)
                playIc.set(if (p.isPlaying) Ic.PAUSE else Ic.PLAY)
            }
            h.postDelayed(this, 100)
        }
    }

    override fun onCreate(b: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(b)
        audio = intent.getBooleanExtra("audio", false)
        pal = Pal(pf.dark, pf.accent)
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        val wc = WindowInsetsControllerCompat(window, window.decorView)
        wc.isAppearanceLightStatusBars = !pal.dark
        wc.isAppearanceLightNavigationBars = !pal.dark
        p = ExoPlayer.Builder(this).build()
        buildUi()
        val u = intent.getStringExtra("uri")
        if (u != null) setSource(Uri.parse(u), intent.getStringExtra("name") ?: "", intent.getLongExtra("dur", 0L), intent.getLongExtra("size", 0L))
        else pickFromPlayer()
        h.post(tick)
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.bg)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(10), dp(12), dp(6))
        bar.addView(iconBtn(Ic.BACK, pal.text) { finish() })
        headerTxt = label(if (audio) "Audio Editor" else "Video Edit", 22f, pal.text, true)
        headerTxt.setPadding(dp(12), 0, 0, 0)
        headerTxt.maxLines = 1
        headerTxt.ellipsize = android.text.TextUtils.TruncateAt.END
        bar.addView(headerTxt, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(iconBtn(Ic.FOLDER, pal.text) { pickFromPlayer() })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        trim = TrimBar(this, pal)
        trim.audioMode = audio
        trim.onStart = { t -> start = t; refreshUi() }
        trim.onEnd = { t -> end = t; refreshUi() }
        trim.onSeek = { t -> p.seekTo(t) }
        trim.onEdge = { start = trim.start; end = trim.end; refreshUi() }
        qualTxt = label("", 17f, pal.text, true)
        sizeTxt = label("", 17f, pal.text, true)
        curTxt = label("00:00", 15f, pal.text, true)
        totTxt = label("00:00", 15f, pal.text, true)
        midTxt = label("", 13f, pal.text, true)
        midTxt.gravity = Gravity.CENTER
        val (sBox, sTxt) = stepper(true)
        val (eBox, eTxt) = stepper(false)
        startTxt = sTxt
        endTxt = eTxt

        fun controls(): LinearLayout {
            val ctl = LinearLayout(this)
            ctl.gravity = Gravity.CENTER
            ctl.addView(iconBtn(Ic.NEXT, pal.text, 48, 26) { edgeToLine(true) })
            val pb = iconBtn(Ic.PLAY, pal.text, 56, 34) { togglePlay() }
            playIc = pb.drawable as PathIcon
            ctl.addView(pb, LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(dp(24), 0, dp(24), 0) })
            ctl.addView(iconBtn(Ic.PREV, pal.text, 48, 26) { edgeToLine(false) })
            return ctl
        }

        fun stepRow(): LinearLayout {
            val sr = LinearLayout(this)
            sr.gravity = Gravity.CENTER_VERTICAL
            sr.setPadding(dp(12), dp(10), dp(12), 0)
            sr.addView(sBox, LinearLayout.LayoutParams(0, dp(48), 1.3f))
            sr.addView(midTxt, LinearLayout.LayoutParams(0, -2, 1f))
            sr.addView(eBox, LinearLayout.LayoutParams(0, dp(48), 1.3f))
            return sr
        }

        if (audio) {
            // ---------- Audio editor: waveform fills the screen, controls at the bottom
            val frame = FrameLayout(this)
            frame.addView(trim, FrameLayout.LayoutParams(-1, -1))
            val zoom = LinearLayout(this)
            zoom.orientation = LinearLayout.VERTICAL
            zoom.addView(iconBtn(Ic.ZOOM_IN, Color.WHITE, 48, 28) { trim.zoomBy(1.6f) })
            zoom.addView(iconBtn(Ic.ZOOM_OUT, Color.WHITE, 48, 28) { trim.zoomBy(1f / 1.6f) })
            frame.addView(zoom, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { topMargin = dp(40); marginEnd = dp(8) })
            root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
            // left corner: where the white line is now (starts at 00:00), right corner: total length of the music
            val tl = LinearLayout(this)
            tl.setPadding(dp(18), dp(4), dp(18), 0)
            curTxt.textSize = 15f
            tl.addView(curTxt, LinearLayout.LayoutParams(0, -2, 1f))
            tl.addView(totTxt)
            root.addView(tl, LinearLayout.LayoutParams(-1, -2))

            val opts = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(6), dp(18), 0) }
            val mode = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
            modeCut = RadioButton(this).apply { text = "Cut"; setTextColor(pal.text); buttonTintList = ColorStateList.valueOf(pal.accent); id = 701 }
            val exclude = RadioButton(this).apply { text = "Exclude"; setTextColor(pal.text); buttonTintList = ColorStateList.valueOf(pal.accent); id = 702 }
            mode.addView(modeCut); mode.addView(exclude); mode.check(if (pf.b("audio_exclude", false)) 702 else 701)
            trim.exclude = pf.b("audio_exclude", false)
            mode.setOnCheckedChangeListener { _, id -> pf.put("audio_exclude", id == 702); trim.exclude = id == 702; trim.invalidate(); refreshUi() }
            opts.addView(mode, LinearLayout.LayoutParams(0, -2, 1f))
            opts.addView(iconBtn(Ic.TUNE, pal.text) { advancedAudioOptions() })
            root.addView(opts)
            // quality / file size slider: real MP3 bitrates, 32 kbps (smallest file) ... 320 kbps (best sound)
            val rates = intArrayOf(32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320)
            val qrA = LinearLayout(this)
            qrA.gravity = Gravity.CENTER_VERTICAL
            qrA.setPadding(dp(18), dp(4), dp(18), 0)
            qualTxt.textSize = 15f
            sizeTxt.textSize = 15f
            qrA.addView(qualTxt, LinearLayout.LayoutParams(0, -2, 1f))
            qrA.addView(sizeTxt)
            root.addView(qrA)
            qSeek = SeekBar(this)
            qSeek.max = rates.size - 1
            val saved = pf.i("ae_kbps", 192)
            qSeek.progress = rates.indices.minByOrNull { Math.abs(rates[it] - saved) } ?: 10
            pf.put("ae_kbps", rates[qSeek.progress])
            qSeek.progressTintList = ColorStateList.valueOf(pal.accent)
            qSeek.thumbTintList = ColorStateList.valueOf(pal.accent)
            qSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) { pf.put("ae_kbps", rates[v.coerceIn(0, rates.size - 1)]); refreshUi() }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            root.addView(qSeek, LinearLayout.LayoutParams(-1, dp(40)).apply { setMargins(dp(10), 0, dp(10), 0) })
            val qEnds = LinearLayout(this)
            qEnds.setPadding(dp(18), 0, dp(18), 0)
            qEnds.addView(label("32 kbps  smaller file", 12f, pal.sub), LinearLayout.LayoutParams(0, -2, 1f))
            qEnds.addView(label("320 kbps  best quality", 12f, pal.sub))
            root.addView(qEnds)
            root.addView(stepRow())

            val bottom = LinearLayout(this)
            bottom.gravity = Gravity.CENTER_VERTICAL
            bottom.setPadding(dp(16), dp(8), dp(16), dp(16))
            bottom.addView(controls(), LinearLayout.LayoutParams(0, -2, 1f))
            val save = LinearLayout(this)
            save.gravity = Gravity.CENTER
            save.background = ripple(pal.accent, dpf(28), 0x33FFFFFF)
            val ck = ImageView(this)
            ck.setImageDrawable(PathIcon(Ic.CHECK, Color.WHITE))
            save.addView(ck, LinearLayout.LayoutParams(dp(26), dp(26)))
            save.setOnClickListener { save() }
            bottom.addView(save, LinearLayout.LayoutParams(dp(110), dp(56)))
            root.addView(bottom)
            setContentView(root)
            return
        }

        // ---------- Video edit
        val sv = ScrollView(this)
        sv.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val pv = PlayerView(this)
        pv.useController = false
        pv.player = p
        pv.setBackgroundColor(Color.BLACK)
        pvRef = pv
        val pvFrame = FrameLayout(this)
        pvFrame.addView(pv, FrameLayout.LayoutParams(-1, -1))
        val ovl = EditOverlayView(this) { videoRectNow() }
        ovl.onTapOverlay = { o -> overlayDialog(o, false) }
        ov = ovl
        pvFrame.addView(ovl, FrameLayout.LayoutParams(-1, -1))
        col.addView(pvFrame, LinearLayout.LayoutParams(-1, dp(230)))

        col.addView(trim, LinearLayout.LayoutParams(-1, dp(72)).apply { topMargin = dp(10) })
        val tr = LinearLayout(this)
        tr.setPadding(dp(18), 0, dp(18), 0)
        tr.addView(curTxt, LinearLayout.LayoutParams(0, -2, 1f))
        tr.addView(totTxt)
        col.addView(tr, LinearLayout.LayoutParams(-1, -2))
        col.addView(controls(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        col.addView(stepRow())

        // ---- Include / Exclude
        val modeRow = LinearLayout(this)
        modeRow.gravity = Gravity.CENTER_VERTICAL
        modeRow.setPadding(dp(20), dp(14), dp(20), 0)
        val mg = RadioGroup(this)
        mg.orientation = RadioGroup.HORIZONTAL
        fun mRadio(id: Int, t: String): RadioButton = RadioButton(this).apply {
            this.id = id; text = t; textSize = 17f; setTextColor(pal.text)
            buttonTintList = ColorStateList.valueOf(pal.accent); setPadding(dp(6), dp(8), dp(24), dp(8))
        }
        mg.addView(mRadio(801, "Include"))
        mg.addView(mRadio(802, "Exclude"))
        mg.check(if (VideoEditSpec.exclude) 802 else 801)
        modeRow.addView(mg)
        col.addView(modeRow)
        val modeNote = label(
            if (VideoEditSpec.exclude) "Exclude: the selected part is removed, everything else is saved."
            else "Include: only the selected part is saved.", 13f, pal.sub
        )
        modeNote.setPadding(dp(20), 0, dp(20), dp(4))
        col.addView(modeNote)
        mg.setOnCheckedChangeListener { _, id ->
            VideoEditSpec.exclude = id == 802
            trim.exclude = VideoEditSpec.exclude
            trim.invalidate()
            modeNote.text = if (VideoEditSpec.exclude) "Exclude: the selected part is removed, everything else is saved." else "Include: only the selected part is saved."
            refreshUi()
        }
        trim.exclude = VideoEditSpec.exclude

        // ---- Text & Picture, Crop
        val tools = LinearLayout(this)
        tools.setPadding(dp(16), dp(10), dp(16), 0)
        fun toolBtn(icon: String, t: String, click: () -> Unit): LinearLayout {
            val b = LinearLayout(this)
            b.gravity = Gravity.CENTER
            b.background = rr(pal.tile, dpf(14))
            b.setPadding(dp(8), 0, dp(8), 0)
            b.addView(ImageView(this).apply { setImageDrawable(PathIcon(icon, pal.text)) }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(8) })
            b.addView(label(t, 15f, pal.text, true))
            b.setOnClickListener { click() }
            return b
        }
        tools.addView(toolBtn(Ic.IMAGE, "Text & Picture") {
            choose("Add to video", listOf("Add text", "Add picture"), -1) { i ->
                if (i == 0) overlayDialog(VOverlay(text = "Your text", color = Color.WHITE, size = 0.08f), true)
                else imgPick.launch("image/*")
            }
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(8) })
        tools.addView(toolBtn(Ic.FIT, "Crop") { setCropMode(true) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        col.addView(tools)
        val hint = label("Tap a text / picture on the video to edit or delete it. Drag it to move it anywhere.", 13f, pal.sub)
        hint.setPadding(dp(20), dp(6), dp(20), 0)
        col.addView(hint)
        val cb = LinearLayout(this)
        cb.gravity = Gravity.CENTER_VERTICAL
        cb.setPadding(dp(20), dp(8), dp(20), 0)
        cb.visibility = View.GONE
        cb.addView(label("Drag the corners to crop", 14f, pal.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        cb.addView(label("Reset", 15f, pal.accent, true).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { VideoEditSpec.crop = null; setCropMode(false); toast("Crop removed") }
        })
        cb.addView(label("Done", 15f, pal.accent, true).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { setCropMode(false) }
        })
        cropBar = cb
        col.addView(cb)

        val sa = label("Save as", 20f, pal.text, true)
        sa.setPadding(dp(20), dp(20), dp(20), dp(4))
        col.addView(sa)
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.HORIZONTAL
        rg.setPadding(dp(12), 0, dp(12), 0)
        fun radio(id: Int, t: String): RadioButton {
            val r = RadioButton(this)
            r.id = id; r.text = t; r.textSize = 17f
            r.setTextColor(pal.text)
            r.buttonTintList = ColorStateList.valueOf(pal.accent)
            r.setPadding(dp(6), dp(10), dp(24), dp(10))
            return r
        }
        rg.addView(radio(101, "Video (MP4)"))
        rg.addView(radio(102, "MP3"))
        rg.check(101)
        col.addView(rg)
        val line = View(this)
        line.setBackgroundColor(pal.line)
        col.addView(line, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(8) })
        val qr = LinearLayout(this)
        qr.gravity = Gravity.CENTER_VERTICAL
        qr.setPadding(dp(20), dp(18), dp(20), dp(6))
        qr.addView(qualTxt, LinearLayout.LayoutParams(0, -2, 1f))
        qr.addView(sizeTxt)
        col.addView(qr)
        qSeek = SeekBar(this)
        qSeek.max = 90                       // 10% .. 100% of the original video bitrate
        qSeek.progress = 90
        qSeek.progressTintList = ColorStateList.valueOf(pal.accent)
        qSeek.thumbTintList = ColorStateList.valueOf(pal.accent)
        qSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                if (asMp3) mProg = v else { vProg = v; qPct = v + 10 }
                refreshUi()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        col.addView(qSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(dp(14), dp(4), dp(14), dp(10)) })
        val note = label("Slide left to make the file smaller (lower quality). At the far right the original quality is kept (lossless cut).", 13f, pal.sub)
        note.setPadding(dp(20), 0, dp(20), dp(20))
        col.addView(note)
        rg.setOnCheckedChangeListener { _, id ->
            asMp3 = id == 102
            qSeek.progress = if (asMp3) mProg else vProg
            note.text = if (asMp3) "MP3 audio only. Slide to choose the bitrate (bigger = better sound, bigger file)." else "Slide left to make the file smaller (lower quality). At the far right the original quality is kept (lossless cut)."
            refreshUi()
        }
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val saveBtn = LinearLayout(this)
        saveBtn.gravity = Gravity.CENTER
        saveBtn.background = ripple(pal.accent, dpf(28), 0x33FFFFFF)
        val ck = ImageView(this)
        ck.setImageDrawable(PathIcon(Ic.CHECK, Color.WHITE))
        saveBtn.addView(ck, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(10) })
        saveBtn.addView(label("Save", 18f, Color.WHITE, true))
        saveBtn.setOnClickListener { save() }
        root.addView(saveBtn, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(dp(48), dp(8), dp(48), dp(20)) })
        setContentView(root)
    }

    private fun clock(ms: Long): String {
        val t = maxOf(ms, 0L) / 1000
        return if (t >= 3600) String.format(java.util.Locale.US, "%02d:%02d:%02d", t / 3600, t / 60 % 60, t % 60)
        else String.format(java.util.Locale.US, "%02d:%02d", t / 60, t % 60)
    }

    private fun videoRectNow(): RectF {
        val v = pvRef ?: return RectF()
        val vs = p.videoSize
        var vw = (vs.width * (if (vs.pixelWidthHeightRatio > 0f) vs.pixelWidthHeightRatio else 1f)).toInt()
        var vh = vs.height
        if (vs.unappliedRotationDegrees % 180 != 0) { val t = vw; vw = vh; vh = t }
        return fitRect(vw, vh, v.width, v.height)
    }

    private fun setCropMode(on: Boolean) {
        val o = ov ?: return
        if (on && VideoEditSpec.crop == null) VideoEditSpec.crop = floatArrayOf(0f, 0f, 1f, 1f)
        if (!on) {
            val c4 = VideoEditSpec.crop
            if (c4 != null && c4[0] <= 0.001f && c4[1] <= 0.001f && c4[2] >= 0.999f && c4[3] >= 0.999f) VideoEditSpec.crop = null
        }
        o.cropMode = on
        cropBar?.visibility = if (on) View.VISIBLE else View.GONE
        o.invalidate()
    }

    /** Add / edit a text or a picture: colour palette (text), size, how much of it is visible (opacity). */
    private fun overlayDialog(o: VOverlay, isNew: Boolean) {
        val oText = o.text; val oColor = o.color; val oSize = o.size; val oAlpha = o.alpha
        if (isNew) { VideoEditSpec.overlays.add(o) }
        ov?.current = o
        ov?.invalidate()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(8), dp(22), dp(4))
        val et: android.widget.EditText? = if (o.isText) android.widget.EditText(this) else null
        if (et != null) {
            et.setText(o.text)
            et.setSelection(o.text.length)
            et.hint = "Type your text"
            et.setTextColor(pal.text)
            et.setHintTextColor(pal.sub)
            et.maxLines = 4
            box.addView(et, LinearLayout.LayoutParams(-1, -2))
            val cr = LinearLayout(this)
            cr.gravity = Gravity.CENTER_VERTICAL
            cr.setPadding(0, dp(12), 0, dp(4))
            cr.addView(label("Text colour", 16f, pal.text, true), LinearLayout.LayoutParams(0, -2, 1f))
            val sw = View(this)
            sw.background = rr(o.color, dpf(18), dp(1), 0x66FFFFFF)
            sw.setOnClickListener {
                colorPalette(o.color) { c -> o.color = c; sw.background = rr(c, dpf(18), dp(1), 0x66FFFFFF); ov?.invalidate() }
            }
            cr.addView(sw, LinearLayout.LayoutParams(dp(72), dp(36)))
            box.addView(cr)
        }
        fun slider(title: String, lo: Int, hi: Int, cur: Int, on: (Int) -> Unit) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(8), 0, 0)
            r.addView(label(title, 16f, pal.text, true), LinearLayout.LayoutParams(dp(110), -2))
            val sb = SeekBar(this)
            sb.max = hi - lo
            sb.progress = (cur - lo).coerceIn(0, hi - lo)
            sb.progressTintList = ColorStateList.valueOf(pal.accent)
            sb.thumbTintList = ColorStateList.valueOf(pal.accent)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(x: SeekBar?, v: Int, fromUser: Boolean) { on(v + lo); ov?.invalidate() }
                override fun onStartTrackingTouch(x: SeekBar?) {}
                override fun onStopTrackingTouch(x: SeekBar?) {}
            })
            r.addView(sb, LinearLayout.LayoutParams(0, dp(44), 1f))
            box.addView(r)
        }
        if (o.isText) slider("Size", 3, 30, (o.size * 100).toInt()) { o.size = it / 100f }
        else slider("Size", 5, 100, (o.size * 100).toInt()) { o.size = it / 100f }
        slider("Opacity", 10, 100, (o.alpha * 100).toInt()) { o.alpha = it / 100f }
        val sv = ScrollView(this)
        sv.addView(box)
        val b = MaterialAlertDialogBuilder(this)
            .setTitle(if (o.isText) "Text" else "Picture")
            .setView(sv)
            .setPositiveButton("OK") { _, _ ->
                if (o.isText) {
                    val t = et?.text?.toString()?.trim() ?: ""
                    if (t.isEmpty()) VideoEditSpec.overlays.remove(o) else o.text = t
                }
                ov?.current = null
                ov?.invalidate()
            }
            .setNegativeButton("Cancel") { _, _ ->
                if (isNew) VideoEditSpec.overlays.remove(o)
                else { o.text = oText; o.color = oColor; o.size = oSize; o.alpha = oAlpha }
                ov?.current = null
                ov?.invalidate()
            }
        if (!isNew) b.setNeutralButton("Delete") { _, _ -> VideoEditSpec.overlays.remove(o); ov?.current = null; ov?.invalidate() }
        b.setOnCancelListener {
            if (isNew) VideoEditSpec.overlays.remove(o)
            ov?.current = null
            ov?.invalidate()
        }
        b.show()
    }

    private fun stepper(isStart: Boolean): Pair<LinearLayout, TextView> {
        val l = LinearLayout(this)
        l.gravity = Gravity.CENTER_VERTICAL
        l.background = rr(pal.tile, dpf(10))
        l.addView(iconBtn(Ic.REMOVE, pal.text, 30, 16) { nudge(isStart, -100L) })
        val t = label("", 12f, pal.text, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        l.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        l.addView(iconBtn(Ic.ADD, pal.text, 30, 16) { nudge(isStart, 100L) })
        return Pair(l, t)
    }

    /** Left / right arrow button: that cut edge jumps to the white line; the white line itself stays. */
    private fun edgeToLine(isStart: Boolean) {
        if (dur <= 0) return
        val c = p.currentPosition.coerceIn(0L, dur)
        if (isStart) { if (c < end - 500L) start = maxOf(0L, c) else { toast("Move the white line before the end mark"); return } }
        else { if (c > start + 500L) end = minOf(dur, c) else { toast("Move the white line after the start mark"); return } }
        trim.start = start
        trim.end = end
        trim.invalidate()
        refreshUi()
    }

    private fun nudge(isStart: Boolean, d: Long) {
        if (dur <= 0) return
        if (isStart) start = minOf(maxOf(start + d, 0L), maxOf(end - 500L, 0L))
        else end = minOf(maxOf(end + d, minOf(start + 500L, dur)), dur)
        trim.start = start
        trim.end = end
        trim.invalidate()
        p.seekTo(if (isStart) start else maxOf(start, end - 1500L))
        refreshUi()
    }

    private fun togglePlay() {
        if (dur <= 0) return
        if (p.isPlaying) p.pause()
        else {
            if (!audio && VideoEditSpec.exclude) { if (p.currentPosition >= dur - 100) p.seekTo(0L) }
            else if (p.currentPosition < start || p.currentPosition >= end - 100) p.seekTo(start)
            p.play()
        }
    }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "video"
            }
        } catch (e: Exception) {
        }
        return "video"
    }

    private fun setSource(u: Uri, nm: String, d: Long, s: Long) {
        uri = u
        name = nm
        VideoEditSpec.clearEdits()
        setCropMode(false)
        headerTxt.text = nm.ifBlank { if (audio) "Audio Editor" else "Video Edit" }
        var dd = d
        if (dd <= 0) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, u)
                dd = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                r.release()
            } catch (e: Exception) {
            }
        }
        var ss = s
        if (ss <= 0) {
            try {
                contentResolver.query(u, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                    if (it.moveToFirst()) ss = it.getLong(0)
                }
            } catch (e: Exception) {
            }
        }
        dur = dd
        size = ss
        start = 0
        end = dur
        p.setMediaItem(MediaItem.fromUri(u))
        p.prepare()
        p.playWhenReady = false
        trim.dur = maxOf(dur, 1L)
        trim.audioMode = audio
        trim.vs = 0L
        trim.vd = 0L
        trim.start = 0
        trim.end = maxOf(dur, 1L)
        trim.pos = 0
        for (i in trim.thumbs.indices) trim.thumbs[i] = null
        if (audio) trim.loadAudioWaveform(this, u) else trim.loadThumbs(this, u)
        trim.invalidate()
        Thread {
            var br = 128000L
            var sr = 0
            val ex = MediaExtractor()
            try {
                ex.setDataSource(this, u, null)
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                        if (f.containsKey(MediaFormat.KEY_BIT_RATE)) br = f.getInteger(MediaFormat.KEY_BIT_RATE).toLong()
                        if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        break
                    }
                }
            } catch (e: Exception) {
            } finally {
                try { ex.release() } catch (e: Exception) {}
            }
            runOnUiThread { abr = br; srate = sr; refreshUi() }
        }.start()
        refreshUi()
    }

    private fun fmtDur(ms: Long): String {
        val t = maxOf(ms, 0L) / 100
        return if (t >= 36000) String.format(java.util.Locale.US, "%d:%02d:%02d.%d", t / 36000, t / 600 % 60, t / 10 % 60, t % 10)
        else String.format(java.util.Locale.US, "%d:%02d.%d", t / 600, t / 10 % 60, t % 10)
    }

    /** estimated video bitrate of the original file (bits/s) */
    private fun origVideoBps(): Long {
        if (dur <= 0 || size <= 0) return 2_000_000L
        val total = size * 8000L / dur
        return maxOf(total - abr, 200_000L)
    }

    private fun mp3Kbps(): Int = 32 + (mProg * 3.2f).toInt()

    private fun targetVideoBps(): Int = (origVideoBps() * qPct / 100).coerceAtLeast(150_000L).toInt()

    private fun refreshUi() {
        val sel0 = maxOf(end - start, 0L)
        val sel = if (!audio && VideoEditSpec.exclude) maxOf(dur - sel0, 0L) else sel0
        startTxt.text = if (audio) fmtDur(start).padStart(7, '0') else Media.stamp(start)
        endTxt.text = if (audio) fmtDur(end).padStart(7, '0') else Media.stamp(end)
        midTxt.text = if (audio) fmtDur(if (pf.b("audio_exclude", false)) maxOf(0L, dur - sel0) else sel0) else fmtDur(sel)
        totTxt.text = if (audio) clock(dur) else Media.time(dur)
        if (audio) {
            val bitrate = pf.i("ae_kbps", 192).coerceIn(32, 320)
            trim.info = (if (srate > 0) "$srate Hz, " else "") + "${abr / 1000} kbps, ${fmtDur(dur)} Seconds"
            trim.invalidate()
            val exportDuration = if (pf.b("audio_exclude", false)) maxOf(0L, dur - sel0) else sel0
            qualTxt.text = "Quality : MP3 $bitrate kbps"
            sizeTxt.text = "Size  " + Media.size2((bitrate * 1000L / 8) * exportDuration / 1000)
        } else if (asMp3) {
            val kb = mp3Kbps()
            qualTxt.text = "Quality  " + String.format(java.util.Locale.US, "%.1f kbps", kb.toFloat())
            sizeTxt.text = "Size  " + Media.size2(kb * 1000L / 8 * sel / 1000)
        } else {
            if (qPct >= 100) {
                qualTxt.text = "Quality  Original"
                sizeTxt.text = "Size  " + Media.size2(if (dur > 0) size * sel / dur else 0L)
            } else {
                val v = targetVideoBps()
                qualTxt.text = "Quality  " + String.format(java.util.Locale.US, "%.1f kbps", v / 1000f)
                sizeTxt.text = "Size  " + Media.size2((v + abr) * sel / 8000L)
            }
        }
    }

    private fun advancedAudioOptions() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        fun optionRow(labelText: String, key: String, values: List<String>, defaultIndex: Int): Spinner {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
            val label = label(labelText, 16f, pal.text, true)
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
            sp.setSelection(pf.i(key, defaultIndex).coerceIn(0, values.lastIndex))
            row.addView(sp, LinearLayout.LayoutParams(dp(150), dp(48)))
            box.addView(row)
            val divider = View(this).apply { setBackgroundColor(pal.line) }
            box.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
            return sp
        }
        val fadeIn = optionRow("Fade start", "ae_fade_in", listOf("Off", "0.5 sec", "1 sec", "2 sec", "3 sec", "5 sec"), 0)
        val fadeOut = optionRow("Fade end", "ae_fade_out", listOf("Off", "0.5 sec", "1 sec", "2 sec", "3 sec", "5 sec"), 0)
        val silenceIn = optionRow("Silence start", "ae_silence_in", listOf("Off", "0.5 sec", "1 sec", "2 sec", "3 sec", "5 sec"), 0)
        val silenceOut = optionRow("Silence end", "ae_silence_out", listOf("Off", "0.5 sec", "1 sec", "2 sec", "3 sec", "5 sec"), 0)
        val format = optionRow("Format", "ae_format", listOf("MP3 (Default)"), 0)
        val volRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(14), 0, dp(10)) }
        val vr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        vr.addView(label("Volume", 17f, pal.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        val value = label(pf.i("ae_volume", 100).toString(), 16f, pal.text, true)
        vr.addView(value)
        val reset = TextView(this).apply {
            text = "↻"; textSize = 25f; setTextColor(pal.sub)
            gravity = Gravity.CENTER; setPadding(dp(14), 0, dp(4), 0)
        }
        vr.addView(reset)
        volRow.addView(vr)
        val volume = SeekBar(this).apply {
            max = 100; progress = pf.i("ae_volume", 100).coerceIn(0, 100)
            progressTintList = ColorStateList.valueOf(pal.accent)
            thumbTintList = ColorStateList.valueOf(pal.accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) { value.text = v.toString() }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        volRow.addView(volume)
        reset.setOnClickListener { volume.progress = 100 }
        box.addView(volRow)
        MaterialAlertDialogBuilder(this).setTitle("Advanced options").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("OK") { _, _ ->
                pf.put("ae_fade_in", fadeIn.selectedItemPosition)
                pf.put("ae_fade_out", fadeOut.selectedItemPosition)
                pf.put("ae_silence_in", silenceIn.selectedItemPosition)
                pf.put("ae_silence_out", silenceOut.selectedItemPosition)
                pf.put("ae_format", format.selectedItemPosition)
                pf.put("ae_volume", volume.progress)
                toast("Audio options saved")
            }.show()
    }

    private var progDlg: androidx.appcompat.app.AlertDialog? = null
    private var progMsg: TextView? = null
    private var progBar: ProgressBar? = null
    private val progCb: () -> Unit = { runOnUiThread { updateProgress() } }

    private fun save() {
        if (dur <= 0) { toast(if (audio) "Pick an audio file first" else "Pick a video first"); return }
        p.pause()
        // a save that never reported progress for 90 s is stuck (service died): reset it
        if (ExportJob.active && System.currentTimeMillis() - maxOf(ExportJob.startedAt, ExportJob.lastPing) > 90_000L) ExportJob.active = false
        if (ExportJob.active) { toast("Another save is already running"); showProgress(); return }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)
        ExportJob.active = true
        ExportJob.startedAt = System.currentTimeMillis()
        ExportJob.lastPing = ExportJob.startedAt
        ExportJob.cancel = false
        ExportJob.pct = 0
        ExportJob.resultMsg = ""
        val i = Intent(this, ExportService::class.java)
            .putExtra("uri", uri.toString()).putExtra("name", name).putExtra("start", start)
            .putExtra("end", if (end >= dur) 0L else end).putExtra("audio", audio || asMp3).putExtra("total", dur)
            .putExtra("exclude", if (audio) pf.b("audio_exclude", false) else (asMp3 && VideoEditSpec.exclude))
            .putExtra("bitrate", if (asMp3 && !audio) mp3Kbps() else pf.i("ae_kbps", 192).coerceIn(32, 320))
            .putExtra("vbps", if (!audio && !asMp3 && (qPct < 100 || VideoEditSpec.active())) targetVideoBps() else 0)
            .putExtra("abps", abr.toInt().coerceIn(32000, 320000))
            .putExtra("volume", if (audio) pf.i("ae_volume", 100) else 100)
            .putExtra("fadeIn", if (!audio) 0 else listOf(0, 500, 1000, 2000, 3000, 5000)[pf.i("ae_fade_in", 0).coerceIn(0, 5)])
            .putExtra("fadeOut", if (!audio) 0 else listOf(0, 500, 1000, 2000, 3000, 5000)[pf.i("ae_fade_out", 0).coerceIn(0, 5)])
            .putExtra("silenceIn", if (!audio) 0 else listOf(0, 500, 1000, 2000, 3000, 5000)[pf.i("ae_silence_in", 0).coerceIn(0, 5)])
            .putExtra("silenceOut", if (!audio) 0 else listOf(0, 500, 1000, 2000, 3000, 5000)[pf.i("ae_silence_out", 0).coerceIn(0, 5)])
        try {
            androidx.core.content.ContextCompat.startForegroundService(this, i)
        } catch (e: Exception) {
            ExportJob.active = false
            message("Cannot start saving", e.message ?: e.toString())
            return
        }
        showProgress()
    }

    /** Progress window with a Hide button: the save keeps running in the background. */
    private fun showProgress() {
        progDlg?.dismiss()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(16), dp(24), dp(4))
        val msg = label("Saving… 0%", 16f, pal.text, true)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progressTintList = ColorStateList.valueOf(pal.accent)
        val hint = label("Tap Hide to keep using the app. Saving continues in the background and you get a notification when it is done.", 13f, pal.sub)
        hint.setPadding(0, dp(12), 0, 0)
        box.addView(msg)
        box.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        box.addView(hint)
        progMsg = msg
        progBar = bar
        progDlg = MaterialAlertDialogBuilder(this).setTitle(if (audio || asMp3) "Exporting audio" else "Saving video").setView(box)
            .setCancelable(false)
            .setPositiveButton("Hide") { _, _ ->
                toast("Running in the background")
                ExportJob.listeners.remove(progCb)
                progDlg = null
            }
            .setNegativeButton("Cancel") { _, _ ->
                ExportJob.cancel = true
                ExportJob.listeners.remove(progCb)
                progDlg = null
            }.show()
        ExportJob.listeners.add(progCb)
        updateProgress()
    }

    private fun updateProgress() {
        val d = progDlg ?: return
        if (!ExportJob.active) {
            d.dismiss()
            progDlg = null
            ExportJob.listeners.remove(progCb)
            if (ExportJob.resultMsg.startsWith("Failed")) message("Save failed", ExportJob.resultMsg) else toast(ExportJob.resultMsg)
            return
        }
        progBar?.progress = ExportJob.pct
        progMsg?.text = "Saving… ${ExportJob.pct}%"
    }

    override fun onStop() {
        super.onStop()
        p.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        ExportJob.listeners.remove(progCb)
        h.removeCallbacksAndMessages(null)
        p.release()
    }
}
