package com.sajid.splayer

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import java.io.BufferedOutputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.ByteOrder

/** Decodes the audio of any video/audio file and writes a real MP3 (192 kbps) into Music/SPlayer. */
object Mp3 {
    fun run(
        c: Context, uri: Uri, name: String, startMs: Long, endMs: Long, totalMs: Long = 0L,
        progress: ((Int) -> Unit)? = null, done: (Boolean, String) -> Unit,
        exclude: Boolean = false, bitrate: Int = 192, volume: Int = 100,
        fadeInMs: Int = 0, fadeOutMs: Int = 0, silenceInMs: Int = 0, silenceOutMs: Int = 0
    ) {
        Thread {
            var ok = false
            var msg = ""
            var ex: MediaExtractor? = null
            var codec: MediaCodec? = null
            var pfd: ParcelFileDescriptor? = null
            var os: OutputStream? = null
            var out: Uri? = null
            var lame: AndroidLame? = null
            try {
                ex = MediaExtractor()
                ex.setDataSource(c, uri, null)
                var tr = -1
                var fmt: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { tr = i; fmt = f; break }
                }
                if (tr < 0 || fmt == null) throw Exception("No audio track found")
                ex.selectTrack(tr)
                val mime = fmt.getString(MediaFormat.KEY_MIME)!!
                codec = MediaCodec.createDecoderByType(mime)
                codec.configure(fmt, null, null, 0)
                codec.start()

                val cv = ContentValues()
                cv.put("_display_name", name.substringBeforeLast('.') + ".mp3")
                cv.put("mime_type", "audio/mpeg")
                cv.put("relative_path", "Music/SPlayer")
                cv.put("is_pending", 1)
                out = c.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv)
                if (out == null) throw Exception("Cannot create output file")
                pfd = c.contentResolver.openFileDescriptor(out, "w")
                if (pfd == null) throw Exception("Cannot open output file")
                os = BufferedOutputStream(FileOutputStream(pfd.fileDescriptor), 256 * 1024)

                val startUs = if (exclude) 0L else startMs * 1000
                if (startMs > 0 && !exclude) ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val info = MediaCodec.BufferInfo()
                var inDone = false
                var outDone = false
                var sr = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
                var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
                var mp3 = ByteArray(0)
                val spanUs = if (exclude) totalMs * 1000 else (if (endMs > 0) endMs else totalMs) * 1000 - startUs
                var lastPct = -1

                fun makeLame() {
                    val stereo = ch >= 2
                    lame = LameBuilder()
                        .setInSampleRate(sr)
                        .setOutChannels(if (stereo) 2 else 1)
                        .setOutBitrate(bitrate.coerceIn(32, 320))
                        .setOutSampleRate(sr)
                        .setQuality(5)
                        .setMode(if (stereo) LameBuilder.Mode.STEREO else LameBuilder.Mode.MONO)
                        .build()
                }

                while (!outDone) {
                    if (ExportJob.cancel) throw Exception("Cancelled")
                    if (!inDone) {
                        val ii = codec.dequeueInputBuffer(10000)
                        if (ii >= 0) {
                            val ib = codec.getInputBuffer(ii)!!
                            val n = ex.readSampleData(ib, 0)
                            val t = ex.sampleTime
                            if (progress != null && spanUs > 0 && t >= startUs) {
                                val pc = ((t - startUs) * 100 / spanUs).toInt().coerceIn(0, 99)
                                if (pc != lastPct) { lastPct = pc; progress(pc) }
                            }
                            if (n < 0 || (!exclude && endMs > 0 && t > endMs * 1000)) {
                                codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inDone = true
                            } else {
                                codec.queueInputBuffer(ii, 0, n, t, 0)
                                ex.advance()
                            }
                        }
                    }
                    val oi = codec.dequeueOutputBuffer(info, 10000)
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val of = codec.outputFormat
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    } else if (oi >= 0) {
                        if (info.size > 0 && info.presentationTimeUs >= startUs) {
                            if (lame == null) makeLame()
                            val ob = codec.getOutputBuffer(oi)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val total = sb.remaining()
                            val shorts = ShortArray(total)
                            sb.get(shorts)
                            val chn = if (ch < 1) 1 else ch
                            val frames = total / chn
                            if (frames > 0) {
                                val left = ShortArray(frames)
                                val right = ShortArray(frames)
                                var kept = 0
                                val endBound = if (endMs > 0) endMs else totalMs
                                val outputEnd = if (exclude) totalMs else endBound
                                for (k in 0 until frames) {
                                    val tm = info.presentationTimeUs / 1000L + (k * 1000L / maxOf(sr, 1))
                                    if (exclude && tm in startMs until endBound) continue
                                    if (!exclude && tm < startMs) continue
                                    if (!exclude && endMs > 0 && tm > endMs) continue
                                    var gain = volume.coerceIn(0, 100) / 100f
                                    val relative = if (exclude && tm >= endBound) tm - (endBound - startMs) else tm - startMs
                                    if (silenceInMs > 0 && relative < silenceInMs) gain = 0f
                                    if (silenceOutMs > 0 && outputEnd > 0 && (if (exclude && tm >= endBound) tm - (endBound - startMs) else tm) >= outputEnd - silenceOutMs) gain = 0f
                                    if (fadeInMs > 0 && relative >= 0L && relative < fadeInMs.toLong()) gain *= relative.toFloat() / fadeInMs
                                    val outputTime = if (exclude && tm >= endBound) tm - (endBound - startMs) else tm
                                    if (fadeOutMs > 0 && outputEnd > 0 && outputTime > outputEnd - fadeOutMs) gain *= ((outputEnd - outputTime).toFloat() / fadeOutMs).coerceIn(0f, 1f)
                                    val l = shorts.get(k * chn).toInt()
                                    val r = shorts.get(k * chn + if (chn >= 2) 1 else 0).toInt()
                                    left[kept] = (l * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                                    right[kept] = (r * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                                    kept++
                                }
                                if (kept > 0) {
                                    val need = (7200 + kept * 1.25).toInt()
                                    if (mp3.size < need) mp3 = ByteArray(need)
                                    val n = lame!!.encode(left, right, kept, mp3)
                                    if (n > 0) os.write(mp3, 0, n)
                                }
                            }
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                }
                if (lame == null) throw Exception("Nothing to convert")
                if (mp3.size < 7200) mp3 = ByteArray(7200)
                val fl = lame!!.flush(mp3)
                if (fl > 0) os.write(mp3, 0, fl)
                os.flush()
                ok = true
                msg = "Music/SPlayer (MP3)"
            } catch (e: Throwable) {
                msg = e.message ?: e.javaClass.simpleName
                try { out?.let { c.contentResolver.delete(it, null, null) } } catch (e2: Exception) {}
                out = null
            } finally {
                try { lame?.close() } catch (e: Exception) {}
                try { os?.close() } catch (e: Exception) {}
                try { pfd?.close() } catch (e: Exception) {}
                try { codec?.stop() } catch (e: Exception) {}
                try { codec?.release() } catch (e: Exception) {}
                try { ex?.release() } catch (e: Exception) {}
                if (ok && out != null) {
                    try {
                        val v = ContentValues()
                        v.put("is_pending", 0)
                        c.contentResolver.update(out, v, null, null)
                    } catch (e: Exception) {}
                }
            }
            Handler(Looper.getMainLooper()).post { done(ok, msg) }
        }.start()
    }
}
