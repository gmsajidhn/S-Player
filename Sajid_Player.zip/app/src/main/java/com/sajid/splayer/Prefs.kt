package com.sajid.splayer

import android.content.Context
import android.content.SharedPreferences

class Prefs(c: Context) {
    val sp: SharedPreferences = c.applicationContext.getSharedPreferences("s", 0)

    fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun i(k: String, d: Int) = sp.getInt(k, d)
    fun put(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun put(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }

    var dark: Boolean
        get() = b("dark", false)
        set(v) = put("dark", v)
    var accent: Int
        get() = i("accent", 0xFF3F51B5.toInt())
        set(v) = put("accent", v)
    var resume: Boolean
        get() = b("resume", true)
        set(v) = put("resume", v)
    var auto: Boolean
        get() = b("auto", true)
        set(v) = put("auto", v)
    /** keep playing the sound (background play) when leaving the video player */
    var autoBg: Boolean
        get() = b("auto_bg", true)
        set(v) = put("auto_bg", v)
    /** tapping a video in the list starts it playing at once (off: the player opens paused) */
    var tapPlay: Boolean
        get() = b("tap_play", true)
        set(v) = put("tap_play", v)
    var showLast: Boolean
        get() = b("showlast", true)
        set(v) = put("showlast", v)
    var orient: Int
        get() = i("orient", 0)
        set(v) = put("orient", v)
    var musicFirst: Boolean
        get() = b("musicfirst", false)
        set(v) = put("musicfirst", v)
    var sysEq: Boolean
        get() = b("syseq", false)
        set(v) = put("syseq", v)
    var smartVol: Boolean
        get() = b("smartvol", false)
        set(v) = put("smartvol", v)
    var minSec: Int
        get() = i("minsec", 0)
        set(v) = put("minsec", v)
    var broadcast: Boolean
        get() = b("broadcast", true)
        set(v) = put("broadcast", v)
    var scrobble: Boolean
        get() = b("scrobble", false)
        set(v) = put("scrobble", v)
    var shake: Boolean
        get() = b("shake", false)
        set(v) = put("shake", v)
    var shakeAction: Int
        get() = i("shakeact", 0)
        set(v) = put("shakeact", v)
    /** last playback speed chosen in the video player (kept for pop-up / background play) */
    /** kept only in memory: it survives pop-up / background play, but resets to 1x when the app is killed completely */
    var curSpeed: Float
        get() = speedNow
        set(v) { speedNow = v }
    /** audio (music) speed is kept separately from the video speed; also in memory only */
    var curSpeedA: Float
        get() = speedNowA
        set(v) { speedNowA = v }
    /** last used playback mode (0 order, 1 repeat one, 2 repeat all, 3 stop after current, 4 shuffle) */
    var modeV: Int
        get() = i("pm_v", 0)
        set(v) = put("pm_v", v)
    var modeA: Int
        get() = i("pm_a", 0)
        set(v) = put("pm_a", v)
    var shakeForce: Int
        get() = i("shakeforce", 70)
        set(v) = put("shakeforce", v)
    var sortKey: Int
        get() = i("sortkey", 0)
        set(v) = put("sortkey", v)
    var sortAsc: Boolean
        get() = b("sortasc", true)
        set(v) = put("sortasc", v)
    var grid: Boolean
        get() = b("grid", false)
        set(v) = put("grid", v)
    var pin: String
        get() = sp.getString("pin", "") ?: ""
        set(v) = put("pin", v)
    var lastUri: String
        get() = sp.getString("last_u", "") ?: ""
        set(v) = put("last_u", v)
    var lastName: String
        get() = sp.getString("last_n", "") ?: ""
        set(v) = put("last_n", v)
    var lastVideo: Boolean
        get() = b("last_v", true)
        set(v) = put("last_v", v)

    var bgPlay: Boolean
        get() = b("bgplay", false)
        set(v) = put("bgplay", v)
    var decoder: Int
        get() = i("decoder", 0)
        set(v) = put("decoder", v)
    /** speed used while the finger rests on the video (long press) */
    var holdSpeed: Float
        get() = sp.getFloat("hold_speed", 3f)
        set(v) { sp.edit().putFloat("hold_speed", v).apply() }
    var viz: Boolean
        get() = b("viz", false)
        set(v) = put("viz", v)

    companion object {
        @Volatile var speedNow = 1f
        @Volatile var speedNowA = 1f
        /** which playlist set is shown: false = audio (music) playlists, true = video playlists */
        @Volatile var plVideo = false
        val V_KEYS = listOf("all", "folder", "playlist")
        val A_KEYS = listOf("album", "songs", "artist", "folder", "playlist", "recent", "genres", "mini")
        val A_DEFAULT_ON = listOf("album", "songs", "artist", "folder", "playlist")
    }

    /** Full ordered list of tab keys for a mode (always contains every key once). */
    fun order(video: Boolean): List<String> {
        val all = if (video) V_KEYS else A_KEYS
        val saved = (sp.getString(if (video) "v_order" else "a_order", null) ?: "").split(",").filter { it in all }
        return (saved + all.filter { it !in saved }).distinct()
    }
    fun on(video: Boolean): MutableSet<String> {
        val k = if (video) "v_on" else "a_on"
        val raw = sp.getString(k, null)
        val all = if (video) V_KEYS else A_KEYS
        return if (raw == null) (if (video) V_KEYS else A_DEFAULT_ON).toMutableSet()
        else raw.split(",").filter { it in all }.toMutableSet()
    }
    fun saveTabs(video: Boolean, order: List<String>, on: Set<String>) {
        put(if (video) "v_order" else "a_order", order.joinToString(","))
        put(if (video) "v_on" else "a_on", on.joinToString(","))
    }
    /** Enabled tabs in the saved order (never empty). */
    fun tabs(video: Boolean): List<String> {
        val on = on(video)
        val l = order(video).filter { it in on }
        return if (l.isEmpty()) listOf(order(video).first()) else l
    }

    /** seek bar look per place: "main" (bar with the icons), "edge" (thin line when the icons are hidden), "pop" (pop-up player) */
    fun skColor(k: String, def: Int): Int { val v = i("sk_${k}_c", 0); return if (v == 0) def else v }
    fun skKnobColor(k: String): Int { val v = i("sk_${k}_kc", 0); return if (v == 0) android.graphics.Color.WHITE else v }
    fun skThick(k: String, def: Int) = i("sk_${k}_t", def)
    fun skKnob(k: String, def: Int) = i("sk_${k}_k", def)
    fun skGap(k: String, def: Int) = i("sk_${k}_g", def)
    fun skReset(k: String) { sp.edit().remove("sk_${k}_g").remove("sk_${k}_c").remove("sk_${k}_kc").remove("sk_${k}_t").remove("sk_${k}_k").apply() }

    /** the "NEW" tag of a file disappears once it has been played */
    fun seen(u: String) = sp.getBoolean("seen_$u", false)
    fun markSeen(u: String) { if (!seen(u)) sp.edit().putBoolean("seen_$u", true).apply() }

    fun tag(id: Long, f: String): String = sp.getString("tg_${id}_$f", "") ?: ""
    fun setTag(id: Long, f: String, v: String) = put("tg_${id}_$f", v)

    fun strs(k: String): MutableSet<String> = HashSet(sp.getStringSet(k, emptySet()) ?: emptySet())
    fun putStrs(k: String, s: Set<String>) { sp.edit().putStringSet(k, HashSet(s)).apply() }

    // ---- named playlists: names in "pl_names" (own order), items of each in "plo_<name>" (own order)
    private fun split(s: String?) = if (s.isNullOrEmpty()) emptyList<String>() else s.split("\n")

    private fun oKey(v: Boolean, n: String) = if (v) "plo_v_$n" else "plo_$n"

    fun plNames(v: Boolean = plVideo): List<String> {
        if (v) return split(sp.getString("pl_names_v", null)).distinct()
        if (sp.contains("pl")) {   // very old single playlist
            val old = strs("pl")
            sp.edit().remove("pl").apply()
            if (old.isNotEmpty()) plCreate("My playlist", old.toList(), false)
        }
        val saved = split(sp.getString("pl_names", null))
        val legacy = strs("pls").filter { it !in saved }.sortedWith(String.CASE_INSENSITIVE_ORDER)   // v3.1 data
        val all = (saved + legacy).distinct()
        if (legacy.isNotEmpty()) { plSetNameOrder(all, false); sp.edit().remove("pls").apply() }
        return all
    }
    fun plSetNameOrder(l: List<String>, v: Boolean = plVideo) { put(if (v) "pl_names_v" else "pl_names", l.joinToString("\n")) }

    fun plList(n: String, v: Boolean = plVideo): List<String> {
        val s = sp.getString(oKey(v, n), null)
        if (s != null) return split(s)
        if (v) return emptyList()
        val old = strs("pl_$n").toList()   // v3.1 data
        if (old.isNotEmpty()) plSetOrder(n, old, false)
        return old
    }
    fun plItems(n: String, v: Boolean = plVideo): Set<String> = plList(n, v).toSet()
    fun plSetOrder(n: String, l: List<String>, v: Boolean = plVideo) { put(oKey(v, n), l.joinToString("\n")) }
    fun plCreate(n: String, keys: Collection<String> = emptyList(), v: Boolean = plVideo) {
        val names = plNames(v)
        if (n !in names) plSetNameOrder(names + n, v)
        plSetOrder(n, (plList(n, v) + keys).distinct(), v)
    }
    fun plAdd(n: String, keys: Collection<String>, v: Boolean = plVideo) = plCreate(n, keys, v)
    fun plRemoveItem(n: String, key: String, v: Boolean = plVideo) { plSetOrder(n, plList(n, v) - key, v) }
    fun plDelete(n: String, v: Boolean = plVideo) {
        plSetNameOrder(plNames(v) - n, v)
        sp.edit().remove(oKey(v, n)).remove("pl_$n").apply()
    }
    fun plRename(old: String, new: String, v: Boolean = plVideo) {
        val items = plList(old, v)
        val names = plNames(v).map { if (it == old) new else it }
        sp.edit().remove(oKey(v, old)).remove("pl_$old").apply()
        plSetNameOrder(names, v)
        plSetOrder(new, items, v)
    }

    // last video queue (for the video mini bar)
    var lastQ: List<String>
        get() = split(sp.getString("lq_u", null))
        set(v) = put("lq_u", v.joinToString("\n"))
    var lastQN: List<String>
        get() = split(sp.getString("lq_n", null))
        set(v) = put("lq_n", v.joinToString("\n"))

    fun folderColor(f: String) = i("fc_$f", 0)
    fun setFolderColor(f: String, c: Int) = put("fc_$f", c)
    fun alias(f: String) = sp.getString("al_$f", null) ?: f
    fun setAlias(f: String, n: String) = put("al_$f", n)
}
