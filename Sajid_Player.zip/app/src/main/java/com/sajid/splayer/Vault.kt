package com.sajid.splayer

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.abs

/**
 * Private storage for Lock / Hide.
 * A locked or hidden file is MOVED into the app's private folder (filesDir/vault) and removed from MediaStore,
 * so it disappears from the gallery, file managers and every other player. Unlock / Unhide moves it back.
 */
object Vault {
    class Entry(
        val file: String, var name: String, val folder: String, val rel: String, val mime: String, val video: Boolean,
        val dur: Long, val size: Long, val w: Int, val h: Int, val added: Long, val mode: String,
        val folderLock: Boolean, val artist: String, val album: String, val genre: String, var pending: Boolean
    )

    /** An original (MediaStore uri) that was copied into the vault and still has to be deleted. */
    class Moved(val uri: Uri, val entry: Entry, val key: String)

    @Volatile var busy = false
    /** set to true by the Cancel button of the progress window: the running copy stops and is rolled back */
    @Volatile var cancel = false
    var inFlight: List<Moved> = emptyList()
    val deleteQueue = ArrayList<Uri>()
    private val lock = Any()

    fun dir(c: Context): File = File(c.filesDir, "vault").also { it.mkdirs() }
    fun fileOf(c: Context, e: Entry) = File(dir(c), e.file)

    private fun toJson(e: Entry) = JSONObject().apply {
        put("file", e.file); put("name", e.name); put("folder", e.folder); put("rel", e.rel); put("mime", e.mime)
        put("video", e.video); put("dur", e.dur); put("size", e.size); put("w", e.w); put("h", e.h)
        put("added", e.added); put("mode", e.mode); put("fl", e.folderLock); put("artist", e.artist)
        put("album", e.album); put("genre", e.genre); put("pending", e.pending)
    }

    private fun fromJson(o: JSONObject) = Entry(
        o.getString("file"), o.optString("name"), o.optString("folder"), o.optString("rel"), o.optString("mime"),
        o.optBoolean("video", true), o.optLong("dur"), o.optLong("size"), o.optInt("w"), o.optInt("h"),
        o.optLong("added"), o.optString("mode", "lock"), o.optBoolean("fl"), o.optString("artist"),
        o.optString("album"), o.optString("genre"), o.optBoolean("pending")
    )

    fun load(c: Context): MutableList<Entry> {
        return synchronized(lock) {
            val out = ArrayList<Entry>()
            try {
                val f = File(c.filesDir, "vault_index.json")
                if (f.exists()) {
                    val a = JSONArray(f.readText())
                    for (i in 0 until a.length()) out.add(fromJson(a.getJSONObject(i)))
                }
            } catch (e: Exception) {
            }
            out
        }
    }

    fun save(c: Context, l: List<Entry>) {
        synchronized(lock) {
            val a = JSONArray()
            for (e in l) a.put(toJson(e))
            val f = File(c.filesDir, "vault_index.json")
            val tmp = File(c.filesDir, "vault_index.tmp")
            tmp.writeText(a.toString())
            if (!tmp.renameTo(f)) {
                f.writeText(a.toString())
                tmp.delete()
            }
        }
    }

    fun toItem(c: Context, e: Entry): Item {
        val f = fileOf(c, e)
        val id = -(abs(e.file.hashCode().toLong()) + 1L)
        return Item(
            id, Uri.fromFile(f), e.name, e.folder, e.size, e.dur, f.path, e.added, e.w, e.h, e.artist, e.video,
            e.album, e.genre, "", e.rel, e.mime, e.folderLock
        )
    }

    /** files moved into app storage by older versions (lock and old "hide" entries) so they can still be unlocked */
    fun items(c: Context, video: Boolean, mode: String): List<Item> =
        load(c).filter { !it.pending && it.video == video && fileOf(c, it).exists() }.map { toItem(c, it) }

    fun entriesOf(c: Context, items: List<Item>): List<Entry> {
        val paths = items.filter { it.vault }.map { it.path }.toSet()
        return load(c).filter { fileOf(c, it).path in paths }
    }

    fun guessMime(name: String, video: Boolean): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: (if (video) "video/mp4" else "audio/mpeg")
    }

    private fun onMain(f: () -> Unit) { Handler(Looper.getMainLooper()).post { f() } }

    // ------------------------------------------------------------------ move in
    /** Step 1 of hiding: copy every file into the vault (entries stay "pending" until the originals are gone). */
    fun copyIn(
        c: Context, items: List<Item>, modeOf: (Item) -> String, folderLockOf: (Item) -> Boolean,
        progress: ((Int, String) -> Unit)? = null, done: (List<Moved>?, String) -> Unit
    ) {
        busy = true
        cancel = false
        Thread {
            val moved = ArrayList<Moved>()
            var err = ""
            var partial: File? = null
            try {
                val need = items.sumOf { it.size }
                if (dir(c).usableSpace < need + 50L * 1024 * 1024) throw Exception("Not enough free storage")
                val all = load(c)
                val total = maxOf(1L, need)
                var doneBytes = 0L
                var lastPct = -1
                for (x in items) {
                    val ext = x.name.substringAfterLast('.', "")
                    val fn = UUID.randomUUID().toString().replace("-", "") + (if (ext.isNotEmpty()) ".$ext" else "")
                    val dest = File(dir(c), fn)
                    partial = dest
                    val ins = c.contentResolver.openInputStream(x.uri) ?: throw Exception("Cannot read ${x.name}")
                    ins.use { s ->
                        FileOutputStream(dest).use { o ->
                            val buf = ByteArray(256 * 1024)
                            while (true) {
                                if (cancel) throw Exception("Cancelled")
                                val n = s.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                doneBytes += n
                                val pc = (doneBytes * 100 / total).toInt().coerceIn(0, 100)
                                if (pc != lastPct) { lastPct = pc; val nm = x.name; onMain { progress?.invoke(pc, nm) } }
                            }
                        }
                    }
                    if (x.size > 0 && dest.length() != x.size) throw Exception("Copy failed: ${x.name}")
                    partial = null
                    val e = Entry(
                        fn, x.name, x.folder, x.rel, x.mime.ifEmpty { guessMime(x.name, x.video) }, x.video, x.dur,
                        dest.length(), x.w, x.h, x.added, modeOf(x), folderLockOf(x), x.artist, x.album, x.genre, true
                    )
                    all.add(e)
                    moved.add(Moved(x.uri, e, x.key))
                    save(c, all)
                }
            } catch (ex: Exception) {
                err = ex.message ?: "error"
                try { partial?.delete() } catch (e2: Exception) {}
                rollback(c, moved)
                moved.clear()
            }
            onMain { if (err.isEmpty()) done(moved, "") else done(null, err) }
        }.start()
    }

    fun rollback(c: Context, moved: List<Moved>) {
        if (moved.isEmpty()) return
        val all = load(c)
        for (m in moved) {
            try { fileOf(c, m.entry).delete() } catch (e: Exception) {}
            all.removeAll { it.file == m.entry.file }
        }
        save(c, all)
    }

    fun commit(c: Context, moved: List<Moved>) {
        if (moved.isEmpty()) return
        val all = load(c)
        for (m in moved) all.firstOrNull { it.file == m.entry.file }?.pending = false
        save(c, all)
    }

    /** After a crash / killed process: copies whose original still exists are dropped, the rest are kept as hidden. */
    fun recover(c: Context) {
        if (busy || inFlight.isNotEmpty()) return
        val all = load(c)
        var changed = false
        val iter = all.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            if (!e.pending) continue
            if (originalExists(c, e)) {
                try { fileOf(c, e).delete() } catch (ex: Exception) {}
                iter.remove()
            } else e.pending = false
            changed = true
        }
        if (changed) save(c, all)
    }

    private fun originalExists(c: Context, e: Entry): Boolean {
        return try {
            val base = if (e.video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            c.contentResolver.query(base, arrayOf("_id"), "_display_name=? AND relative_path=?", arrayOf(e.name, e.rel), null)
                ?.use { it.count > 0 } ?: false
        } catch (ex: Exception) {
            false
        }
    }

    // ------------------------------------------------------------------ move out
    fun restore(c: Context, list: List<Entry>, progress: ((Int, String) -> Unit)? = null, done: (Int, String) -> Unit) {
        busy = true
        cancel = false
        Thread {
            var ok = 0
            var err = ""
            val all = load(c)
            val total = maxOf(1L, list.sumOf { fileOf(c, it).length() })
            var doneBytes = 0L
            var lastPct = -1
            for (e in list) {
                if (cancel) { err = "Cancelled"; break }
                try {
                    val src = fileOf(c, e)
                    if (!src.exists()) { all.removeAll { it.file == e.file }; continue }
                    val base = if (e.video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    val mime = e.mime.ifEmpty { guessMime(e.name, e.video) }
                    val rels = ArrayList<String>()
                    if (e.rel.isNotEmpty()) rels.add(e.rel)
                    rels.add((if (e.video) "Movies/" else "Music/") + e.folder.ifEmpty { "SPlayer" } + "/")
                    var made: Uri? = null
                    for (r in rels) {
                        try {
                            val cv = ContentValues()
                            cv.put("_display_name", e.name)
                            cv.put("mime_type", mime)
                            cv.put("relative_path", r)
                            cv.put("is_pending", 1)
                            made = c.contentResolver.insert(base, cv)
                            if (made != null) break
                        } catch (ex: Exception) {
                            made = null
                        }
                    }
                    val target: Uri = made ?: throw Exception("Cannot restore ${e.name}")
                    try {
                        val os = c.contentResolver.openOutputStream(target) ?: throw Exception("Cannot write ${e.name}")
                        os.use { o ->
                            FileInputStream(src).use { s ->
                                val buf = ByteArray(256 * 1024)
                                while (true) {
                                    if (cancel) throw Exception("Cancelled")
                                    val n = s.read(buf)
                                    if (n < 0) break
                                    o.write(buf, 0, n)
                                    doneBytes += n
                                    val pc = (doneBytes * 100 / total).toInt().coerceIn(0, 100)
                                    if (pc != lastPct) { lastPct = pc; val nm = e.name; onMain { progress?.invoke(pc, nm) } }
                                }
                            }
                        }
                    } catch (ex: Exception) {
                        try { c.contentResolver.delete(target, null, null) } catch (e2: Exception) {}
                        throw ex
                    }
                    val cv2 = ContentValues()
                    cv2.put("is_pending", 0)
                    c.contentResolver.update(target, cv2, null, null)
                    src.delete()
                    all.removeAll { it.file == e.file }
                    save(c, all)
                    ok++
                } catch (ex: Exception) {
                    err = ex.message ?: "error"
                }
            }
            save(c, all)
            busy = false
            onMain { done(ok, err) }
        }.start()
    }

    fun delete(c: Context, list: List<Entry>) {
        val all = load(c)
        for (e in list) {
            try { fileOf(c, e).delete() } catch (ex: Exception) {}
            all.removeAll { it.file == e.file }
        }
        save(c, all)
    }

    fun rename(c: Context, x: Item, newName: String) {
        if (x.dotLock) { DotLock.rename(c, x, newName); return }
        val all = load(c)
        all.firstOrNull { fileOf(c, it).path == x.path }?.name = newName
        save(c, all)
    }
}


/**
 * Lock = put a "." in front of the file name. The file never leaves its place on the phone (nothing is copied into
 * the app), Android and every other app hide dot-files, so uninstalling the app keeps the locked files safe.
 * The Locked screen lists the dot-files; Unlock simply removes the "." again.
 */
object DotLock {
    val VIDEO = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "flv", "wmv", "m4v", "mpg", "mpeg", "ts")
    val AUDIO = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr", "wma", "mid", "m4b")

    fun hasAccess(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 30) android.os.Environment.isExternalStorageManager() else true

    fun isDot(path: String) = File(path).name.startsWith(".")

    private fun scan(c: Context, paths: List<String>, done: (() -> Unit)? = null) {
        if (paths.isEmpty()) { done?.invoke(); return }
        try {
            var left = paths.size
            android.media.MediaScannerConnection.scanFile(c, paths.toTypedArray(), null) { _, _ ->
                left--
                if (left <= 0) done?.invoke()
            }
        } catch (e: Exception) {
            done?.invoke()
        }
    }

    private fun free(f: File): File {
        if (!f.exists()) return f
        val ext = f.extension
        val stem = f.name.removeSuffix(if (ext.isNotEmpty()) ".$ext" else "")
        var n = 1
        while (true) {
            val g = File(f.parentFile, stem + " (" + n + ")" + (if (ext.isNotEmpty()) ".$ext" else ""))
            if (!g.exists()) return g
            n++
        }
    }

    /** Lock: name -> .name. Returns (done, error). */
    fun lock(c: Context, items: List<Item>, finished: (Int, String) -> Unit) {
        Thread {
            var ok = 0
            var err = ""
            val touched = ArrayList<String>()
            for (x in items) {
                try {
                    val src = File(x.path)
                    if (x.path.isEmpty() || !src.exists()) { err = "File not found: ${x.name}"; continue }
                    if (src.name.startsWith(".")) continue
                    val dest = free(File(src.parentFile, "." + src.name))
                    if (src.renameTo(dest)) { ok++; touched.add(src.path); touched.add(dest.path) }
                    else err = "Cannot lock ${x.name}"
                } catch (e: Exception) {
                    err = e.message ?: "error"
                }
            }
            scan(c, touched) { Handler(Looper.getMainLooper()).post { finished(ok, err) } }
        }.start()
    }

    /** Unlock: .name -> name (only the first dot is removed). */
    fun unlock(c: Context, items: List<Item>, finished: (Int, String) -> Unit) {
        Thread {
            var ok = 0
            var err = ""
            val touched = ArrayList<String>()
            for (x in items) {
                try {
                    val src = File(x.path)
                    if (!src.exists()) { err = "File not found: ${x.name}"; continue }
                    if (!src.name.startsWith(".")) continue
                    val dest = free(File(src.parentFile, src.name.substring(1)))
                    if (src.renameTo(dest)) { ok++; touched.add(src.path); touched.add(dest.path) }
                    else err = "Cannot unlock ${x.name}"
                } catch (e: Exception) {
                    err = e.message ?: "error"
                }
            }
            scan(c, touched) { Handler(Looper.getMainLooper()).post { finished(ok, err) } }
        }.start()
    }

    fun rename(c: Context, x: Item, newName: String) {
        try {
            val src = File(x.path)
            val dest = File(src.parentFile, (if (src.name.startsWith(".")) "." else "") + newName.removePrefix("."))
            if (!dest.exists()) src.renameTo(dest)
        } catch (e: Exception) {
        }
    }

    fun delete(c: Context, items: List<Item>) {
        for (x in items) try { File(x.path).delete() } catch (e: Exception) {}
    }

    const val MARK = ".splayer_lock"

    /** a folder that Sajid Player locked: its name starts with "." and it holds the marker file */
    fun isLockedDir(d: File?) = d != null && d.isDirectory && d.name.startsWith(".") && File(d, MARK).exists()

    /** the top locked folder above a file (null when the file is not inside one) */
    fun lockedRoot(f: File): File? {
        var d = f.parentFile
        var found: File? = null
        var n = 0
        while (d != null && n < 12) {
            if (isLockedDir(d)) found = d
            d = d.parentFile
            n++
        }
        return found
    }

    private val PROTECTED = setOf("dcim", "movies", "music", "download", "downloads", "pictures", "documents", "android", "alarms", "notifications", "podcasts", "ringtones", "audiobooks", "recordings")

    private fun mediaIn(dir: File, out: MutableList<File>, depth: Int = 0) {
        if (depth > 8) return
        val l = try { dir.listFiles() } catch (e: Exception) { null } ?: return
        for (f in l) {
            if (f.isDirectory) mediaIn(f, out, depth + 1)
            else {
                val ext = f.extension.lowercase()
                if (ext in VIDEO || ext in AUDIO) out.add(f)
            }
        }
    }

    /**
     * Lock a whole folder: "Movies/Trip" becomes "Movies/.Trip" (videos and music inside stay together, nothing is copied).
     * Protected system folders (Movies, Music, DCIM, Download ...) cannot be renamed, so their files get the dot one by one.
     */
    fun lockFolders(c: Context, items: List<Item>, finished: (Int, String) -> Unit) {
        Thread {
            var ok = 0
            var err = ""
            val touched = ArrayList<String>()
            val single = ArrayList<Item>()
            val dirs = items.mapNotNull { x -> try { File(x.path).parentFile } catch (e: Exception) { null } }.distinct()
            val root = android.os.Environment.getExternalStorageDirectory()
            for (d in dirs) {
                try {
                    val top = d.parentFile?.path == root.path && d.name.lowercase() in PROTECTED
                    if (d.path == root.path || top || d.name.startsWith(".")) {
                        single.addAll(items.filter { File(it.path).parentFile?.path == d.path })
                        continue
                    }
                    val before = ArrayList<File>(); mediaIn(d, before)
                    var dest = File(d.parentFile, "." + d.name)
                    var n = 1
                    while (dest.exists()) { dest = File(d.parentFile, "." + d.name + " (" + n + ")"); n++ }
                    if (d.renameTo(dest)) {
                        try { File(dest, MARK).createNewFile() } catch (e: Exception) {}
                        for (f in before) { touched.add(f.path); touched.add(File(dest, f.path.removePrefix(d.path + "/")).path) }
                        ok += items.count { File(it.path).parentFile?.path == d.path }.coerceAtLeast(1)
                    } else err = "Cannot lock folder ${d.name}"
                } catch (e: Exception) {
                    err = e.message ?: "error"
                }
            }
            if (single.isNotEmpty()) {
                for (x in single) {
                    try {
                        val src = File(x.path)
                        if (!src.exists() || src.name.startsWith(".")) continue
                        val dest = free(File(src.parentFile, "." + src.name))
                        if (src.renameTo(dest)) { ok++; touched.add(src.path); touched.add(dest.path) } else err = "Cannot lock ${x.name}"
                    } catch (e: Exception) { err = e.message ?: "error" }
                }
            }
            scan(c, touched) { Handler(Looper.getMainLooper()).post { finished(ok, err) } }
        }.start()
    }

    /** Unlock a locked folder: ".Trip" -> "Trip" (the whole folder, videos and music together). */
    fun unlockFolders(c: Context, dirs: List<File>, finished: (Int, String) -> Unit) {
        Thread {
            var ok = 0
            var err = ""
            val touched = ArrayList<String>()
            for (d in dirs.distinct()) {
                try {
                    if (!d.name.startsWith(".")) continue
                    val before = ArrayList<File>(); mediaIn(d, before)
                    try { File(d, MARK).delete() } catch (e: Exception) {}
                    var dest = File(d.parentFile, d.name.substring(1))
                    var n = 1
                    while (dest.exists()) { dest = File(d.parentFile, d.name.substring(1) + " (" + n + ")"); n++ }
                    if (d.renameTo(dest)) {
                        ok += before.size.coerceAtLeast(1)
                        for (f in before) { touched.add(f.path); touched.add(File(dest, f.path.removePrefix(d.path + "/")).path) }
                    } else { err = "Cannot unlock folder ${d.name}"; try { File(d, MARK).createNewFile() } catch (e: Exception) {} }
                } catch (e: Exception) {
                    err = e.message ?: "error"
                }
            }
            scan(c, touched) { Handler(Looper.getMainLooper()).post { finished(ok, err) } }
        }.start()
    }

    private fun walk(dir: File, depth: Int, out: MutableList<Pair<File, Boolean>>, top: Boolean, inLocked: Boolean) {
        if (depth > 8) return
        val l = try { dir.listFiles() } catch (e: Exception) { null } ?: return
        for (f in l) {
            val n = f.name
            if (f.isDirectory) {
                if (n.startsWith(".")) {
                    if (isLockedDir(f)) walk(f, depth + 1, out, false, true)
                    else if (inLocked) walk(f, depth + 1, out, false, true)
                    continue
                }
                if (top && n.equals("Android", true)) continue
                walk(f, depth + 1, out, false, inLocked)
            } else {
                if (n.startsWith(".trashed-") || n.startsWith(".pending-") || n == MARK) continue
                val ext = n.substringAfterLast('.', "").lowercase()
                if (ext !in VIDEO && ext !in AUDIO) continue
                if (inLocked) out.add(Pair(f, true))
                else if (n.length > 1 && n.startsWith(".") && !n.startsWith("..")) out.add(Pair(f, false))
            }
        }
    }

    /** every dot-named video / audio file on the phone's shared storage */
    fun items(c: Context, video: Boolean): List<Item> {
        if (!hasAccess()) return emptyList()
        val root = android.os.Environment.getExternalStorageDirectory()
        val found = ArrayList<Pair<File, Boolean>>()
        walk(root, 0, found, true, false)
        val out = ArrayList<Item>()
        for ((f, inDir) in found) {
            val ext = f.extension.lowercase()
            // 3gp / mp4 style containers can hold audio only: trust the extension list
            val vid = if (ext in VIDEO && ext in AUDIO) false else ext in VIDEO
            if (vid != video) continue
            var dur = 0L; var w = 0; var h = 0; var artist = ""; var album = ""; var genre = ""
            try {
                val r = android.media.MediaMetadataRetriever()
                r.setDataSource(f.path)
                dur = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                if (video) {
                    w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                } else {
                    artist = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
                    album = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: ""
                    genre = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_GENRE) ?: ""
                }
                r.release()
            } catch (e: Exception) {
            }
            val parent = f.parentFile
            val rel = try { parent?.relativeTo(root)?.path?.let { if (it.isEmpty()) "" else "$it/" } ?: "" } catch (e: Exception) { "" }
            val id = -(abs(f.path.hashCode().toLong()) + 1L) - 5_000_000_000L
            out.add(
                Item(
                    id, Uri.fromFile(f), if (f.name.startsWith(".")) f.name.substring(1) else f.name,
                    (if (inDir) (lockedRoot(f)?.name ?: parent?.name ?: "Other") else (parent?.name ?: "Other")).removePrefix("."),
                    f.length(), dur, f.path,
                    f.lastModified() / 1000, w, h, artist, video, album, genre, "", rel, Vault.guessMime(f.name, video), inDir, true
                )
            )
        }
        return out
    }
}
