package com.sajid.splayer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.res.ColorStateList
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Progress window for Move / Copy (Lock, Hide, Unlock, Unhide): percentage bar, file name,
 * "Cancel" (stops and rolls back) and "Hide" (window closes, progress continues in a notification).
 */
class MoveProgress(private val ctx: Context, private val title: String, private val onCancel: () -> Unit) {
    private var dlg: AlertDialog? = null
    private var bar: ProgressBar? = null
    private var msg: TextView? = null
    private var hidden = false
    private var last = 0
    private var lastName = ""
    private val nid = 77

    fun show() {
        val pal = Pal(Prefs(ctx).dark, Prefs(ctx).accent)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.dp(24), ctx.dp(16), ctx.dp(24), ctx.dp(4))
        val m = ctx.label("0%", 16f, pal.text, true)
        val b = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
        b.max = 100
        b.progressTintList = ColorStateList.valueOf(pal.accent)
        val name = ctx.label("", 13f, pal.sub)
        name.maxLines = 1
        name.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        name.gravity = Gravity.START
        name.setPadding(0, ctx.dp(10), 0, 0)
        box.addView(m)
        box.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(12) })
        box.addView(name)
        msg = m; bar = b
        nameTxt = name
        dlg = MaterialAlertDialogBuilder(ctx).setTitle(title).setView(box).setCancelable(false)
            .setPositiveButton("Hide") { _, _ -> hidden = true; dlg = null; post(last) }
            .setNegativeButton("Cancel") { _, _ -> onCancel() }
            .show()
    }

    private var nameTxt: TextView? = null

    fun update(pct: Int, name: String) {
        last = pct
        lastName = name
        msg?.text = "$pct%"
        bar?.progress = pct
        nameTxt?.text = name
        if (hidden) post(pct)
    }

    private fun post(pct: Int) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("move", "Move / Copy", NotificationManager.IMPORTANCE_LOW))
            val n = NotificationCompat.Builder(ctx, "move")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title)
                .setContentText("$pct%  $lastName")
                .setProgress(100, pct, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build()
            nm.notify(nid, n)
        } catch (e: Exception) {}
    }

    /** Close the window and the notification. */
    fun finish() {
        try { dlg?.dismiss() } catch (e: Exception) {}
        dlg = null
        try { ctx.getSystemService(NotificationManager::class.java).cancel(nid) } catch (e: Exception) {}
    }
}
