package com.sajid.splayer

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player

/**
 * Tells Android what is playing, so the title / cover / play-pause-next buttons show up in the phone's
 * media card (Control Center / quick settings), on the lock screen and on Bluetooth / headset controls.
 * Used for the music player and the video player.
 */
class SysMedia(ctx: Context, tag: String, private val p: Player) {
    val session = MediaSessionCompat(ctx.applicationContext, tag)
    private var title = ""
    private var artist = ""
    private var art: Bitmap? = null

    private val lis = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { pushState() }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { pushState() }
        override fun onPlaybackStateChanged(playbackState: Int) {
            pushState()
            if (playbackState == Player.STATE_READY) pushMeta()
        }
        override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) { pushState() }
        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) { pushState() }
    }

    init {
        session.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() { p.play() }
            override fun onPause() { p.pause() }
            override fun onStop() { p.pause() }
            override fun onSkipToNext() { p.seekToNext() }
            override fun onSkipToPrevious() { p.seekToPrevious() }
            override fun onSeekTo(pos: Long) { p.seekTo(pos) }
            override fun onFastForward() { p.seekTo(p.currentPosition + 10000L) }
            override fun onRewind() { p.seekTo((p.currentPosition - 10000L).coerceAtLeast(0L)) }
        })
        p.addListener(lis)
        session.isActive = true
        pushState()
    }

    fun setActive(on: Boolean) { try { session.isActive = on } catch (e: Exception) {} }

    fun setInfo(t: String, a: String, bm: Bitmap?) {
        title = t
        artist = a
        art = bm
        pushMeta()
    }

    fun pushMeta() {
        try {
            val b = MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, if (p.duration > 0L) p.duration else -1L)
            art?.let {
                b.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, it)
                b.putBitmap(MediaMetadataCompat.METADATA_KEY_ART, it)
            }
            session.setMetadata(b.build())
        } catch (e: Exception) {
        }
    }

    fun pushState() {
        try {
            val ps = p.playbackState
            val st = when {
                ps == Player.STATE_BUFFERING && p.playWhenReady -> PlaybackStateCompat.STATE_BUFFERING
                p.isPlaying -> PlaybackStateCompat.STATE_PLAYING
                ps == Player.STATE_IDLE -> PlaybackStateCompat.STATE_PAUSED
                else -> PlaybackStateCompat.STATE_PAUSED
            }
            val actions = PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_PLAY_PAUSE or
                PlaybackStateCompat.ACTION_SKIP_TO_NEXT or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO or
                PlaybackStateCompat.ACTION_FAST_FORWARD or PlaybackStateCompat.ACTION_REWIND or PlaybackStateCompat.ACTION_STOP
            val speed = if (st == PlaybackStateCompat.STATE_PLAYING) p.playbackParameters.speed else 0f
            session.setPlaybackState(
                PlaybackStateCompat.Builder()
                    .setActions(actions)
                    .setState(st, p.currentPosition.coerceAtLeast(0L), speed, SystemClock.elapsedRealtime())
                    .build()
            )
        } catch (e: Exception) {
        }
    }

    fun release() {
        try { p.removeListener(lis) } catch (e: Exception) {}
        try { session.isActive = false } catch (e: Exception) {}
        try { session.release() } catch (e: Exception) {}
    }

    companion object {
        const val A_PREV = "com.sajid.splayer.V_PREV"
        const val A_TOGGLE = "com.sajid.splayer.V_TOGGLE"
        const val A_NEXT = "com.sajid.splayer.V_NEXT"

        /** cover pictures sent to the system are kept small (binder size limit) */
        fun small(b: Bitmap?, max: Int = 400): Bitmap? {
            if (b == null) return null
            val m = maxOf(b.width, b.height)
            if (m <= max) return b
            val f = max.toFloat() / m
            return try { Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true) } catch (e: Exception) { b }
        }
    }
}
