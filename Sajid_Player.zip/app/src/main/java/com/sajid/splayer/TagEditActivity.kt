package com.sajid.splayer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.FileOutputStream

class TagEditActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var art: ImageView
    var id = -1L
    var uriStr = ""
    var origTitle = ""
    var newCover: Bitmap? = null
    var coverBytes: ByteArray? = null
    var pendingTmp: java.io.File? = null
    var pendingFields: Map<String, String> = emptyMap()
    val fields = LinkedHashMap<String, TextInputEditText>()

    // ---- batch mode: edit a whole album / artist / folder at once
    var batch = false
    var bIds = LongArray(0)
    var bUris: List<String> = emptyList()
    var bTitles: List<String> = emptyList()
    var bArtists: List<String> = emptyList()
    var bAlbums: List<String> = emptyList()
    var bGenres: List<String> = emptyList()
    var bMaps: List<Map<String, String>> = emptyList()
    fun clean(x: String) = if (x == "<unknown>") "" else x
    fun common(l: List<String>): String { val f = l.map { clean(it) }.distinct(); return if (f.size == 1) f[0] else "" }

    val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                contentResolver.openInputStream(u)?.use { s ->
                    BitmapFactory.decodeStream(s, null, o)?.let { newCover = it; art.setImageBitmap(it) }
                }
            } catch (e: Exception) {
                toast("Cannot open this image")
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(b)
        pal = Pal(pf.dark, pf.accent)
        id = intent.getLongExtra("id", -1L)
        uriStr = intent.getStringExtra("uri") ?: ""
        origTitle = intent.getStringExtra("title") ?: ""
        batch = intent.hasExtra("ids")
        if (batch) {
            bIds = intent.getLongArrayExtra("ids") ?: LongArray(0)
            bUris = intent.getStringArrayListExtra("uris") ?: arrayListOf()
            bTitles = intent.getStringArrayListExtra("titles") ?: arrayListOf()
            bArtists = intent.getStringArrayListExtra("artists") ?: arrayListOf()
            bAlbums = intent.getStringArrayListExtra("albums") ?: arrayListOf()
            bGenres = intent.getStringArrayListExtra("genres") ?: arrayListOf()
            if (bIds.isEmpty() || bUris.size != bIds.size) { finish(); return }
            id = bIds[0]
            uriStr = bUris[0]
        }
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !pal.dark
            isAppearanceLightNavigationBars = !pal.dark
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.bg)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(10), dp(12), dp(6))
        bar.addView(iconBtn(Ic.BACK, pal.text) { finish() })
        val tt = label(if (batch) "Edit tags (${bIds.size} tracks)" else "Edit tag", 22f, pal.text, true)
        tt.setPadding(dp(12), 0, 0, 0)
        bar.addView(tt, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(iconBtn(Ic.CHECK, pal.text) { save() })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(8), dp(24), dp(32))

        val artBox = FrameLayout(this)
        art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rr(pal.tile, dpf(12))
        art.roundClip(dpf(12))
        art.setImageDrawable(null)
        artBox.addView(art, FrameLayout.LayoutParams(-1, -1))
        val pick = FrameLayout(this)
        pick.background = rr(ColorUtils.blendARGB(pal.accent, Color.WHITE, 0.82f), dpf(18))
        val pi = ImageView(this)
        pi.setImageDrawable(PathIcon(Ic.IMAGE, pal.accent))
        pick.addView(pi, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        pick.setOnClickListener { picker.launch("image/*") }
        artBox.addView(pick, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(12), dp(12)) })
        col.addView(artBox, LinearLayout.LayoutParams(dp(200), dp(200)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(16) })

        fun field(key: String, hint: String, value: String, multi: Boolean = false, number: Boolean = false): TextInputLayout {
            val til = TextInputLayout(this)
            til.hint = hint
            val et = TextInputEditText(til.context)
            et.setText(value)
            if (number) et.inputType = InputType.TYPE_CLASS_NUMBER
            if (multi) { et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; et.minLines = 2 }
            til.addView(et)
            fields[key] = et
            return til
        }
        fun gap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        if (batch) {
            val note = label("Changes apply to all ${bIds.size} tracks. Leave a field empty to keep each track's own value.", 14f, pal.sub)
            col.addView(note, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
            col.addView(field("artist", "Artist", common(bArtists)), gap())
            col.addView(field("album", "Album", common(bAlbums)), gap())
            col.addView(field("genre", "Genre", common(bGenres)), gap())
            col.addView(field("year", "Year", common(bIds.map { pf.tag(it, "year") }), number = true), gap())
            col.addView(field("comment", "Comment", common(bIds.map { pf.tag(it, "comment") }), multi = true), gap())
        } else {
        col.addView(field("title", "Title", intent.getStringExtra("title") ?: ""), gap())
        col.addView(field("artist", "Artist", intent.getStringExtra("artist") ?: ""), gap())
        col.addView(field("album", "Album", intent.getStringExtra("album") ?: ""), gap())
        col.addView(field("genre", "Genre", intent.getStringExtra("genre") ?: ""), gap())
        val yt = LinearLayout(this)
        yt.addView(field("year", "Year", pf.tag(id, "year"), number = true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        yt.addView(field("track", "Track", pf.tag(id, "track"), number = true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        col.addView(yt, gap())
        col.addView(field("comment", "Comment", pf.tag(id, "comment"), multi = true), gap())
        }
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        Thread {
            val bm = Art.load(this, uriStr, id, 600)
            runOnUiThread { if (newCover == null && bm != null) art.setImageBitmap(bm) }
        }.start()
    }

    fun isMp3(): Boolean = isMp3Of(Uri.parse(uriStr))

    fun isMp3Of(u: Uri): Boolean {
        val t = try { contentResolver.getType(u) } catch (e: Exception) { null }
        if (t == "audio/mpeg") return true
        try {
            contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return (it.getString(0) ?: "").endsWith(".mp3", true)
            }
        } catch (e: Exception) {
        }
        return false
    }

    // ---------------------------------------------------------------- batch save
    fun saveBatch() {
        val keys = setOf("artist", "album", "genre", "year", "comment")
        val edit = fields.filterKeys { it in keys }.mapValues { it.value.text.toString().trim() }.filter { it.value.isNotEmpty() }
        newCover?.let { bm ->
            try {
                val sc = 1024f / maxOf(bm.width, bm.height)
                val out = if (sc < 1f) Bitmap.createScaledBitmap(bm, (bm.width * sc).toInt(), (bm.height * sc).toInt(), true) else bm
                val bo = java.io.ByteArrayOutputStream()
                out.compress(Bitmap.CompressFormat.JPEG, 90, bo)
                coverBytes = bo.toByteArray()
                for (i in bIds) FileOutputStream(Art.file(this, i)).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            } catch (e: Exception) {
                toast("Cannot save the cover")
            }
        }
        val maps = ArrayList<Map<String, String>>()
        for ((n, i) in bIds.withIndex()) {
            for ((k, v) in edit) pf.setTag(i, k, v)
            val m = LinkedHashMap<String, String>()
            m["title"] = pf.tag(i, "title").ifEmpty { bTitles.getOrElse(n) { "" } }
            m["artist"] = edit["artist"] ?: clean(pf.tag(i, "artist").ifEmpty { bArtists.getOrElse(n) { "" } })
            m["album"] = edit["album"] ?: clean(pf.tag(i, "album").ifEmpty { bAlbums.getOrElse(n) { "" } })
            m["genre"] = edit["genre"] ?: clean(pf.tag(i, "genre").ifEmpty { bGenres.getOrElse(n) { "" } })
            m["year"] = edit["year"] ?: pf.tag(i, "year")
            m["track"] = pf.tag(i, "track")
            m["comment"] = edit["comment"] ?: pf.tag(i, "comment")
            maps.add(m)
            AudioEngine.updateTrack(i, Track(bUris[n], m["title"] ?: "", m["artist"] ?: "", m["album"] ?: "", i))
        }
        bMaps = maps
        // write into the real files too (Android asks once for permission to change all of them)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val us = bUris.map { Uri.parse(it) }
                startIntentSenderForResult(MediaStore.createWriteRequest(contentResolver, us).intentSender, 12, null, 0, 0, 0)
            } else writeBatch()
        } catch (e: Exception) {
            finishSave("Saved in the app only (no permission to change the files)")
        }
    }

    fun writeBatch() {
        val d = busy("Writing tags into ${bIds.size} files…")
        Thread {
            var ok = 0
            var fail = 0
            for ((n, u) in bUris.withIndex()) {
                val uri = Uri.parse(u)
                try {
                    val mp3 = isMp3Of(uri)
                    val tmp = if (mp3) Id3.build(this, uri, bMaps[n], coverBytes) else null
                    val err = Id3.apply(this, uri, tmp, bMaps[n])
                    if (err == null) ok++ else fail++
                } catch (e: Exception) { fail++ }
            }
            runOnUiThread {
                d.dismiss()
                finishSave(if (fail == 0) "Updated $ok tracks — other players will show it too" else "Updated $ok tracks, $fail could not be written to the file")
            }
        }.start()
    }

    fun save() {
        if (batch) { saveBatch(); return }
        if (id <= 0) { finish(); return }
        for ((k, e) in fields) pf.setTag(id, k, e.text.toString().trim())
        newCover?.let { bm ->
            try {
                val s = 1024f / maxOf(bm.width, bm.height)
                val out = if (s < 1f) Bitmap.createScaledBitmap(bm, (bm.width * s).toInt(), (bm.height * s).toInt(), true) else bm
                FileOutputStream(Art.file(this, id)).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                val bo = java.io.ByteArrayOutputStream()
                out.compress(Bitmap.CompressFormat.JPEG, 90, bo)
                coverBytes = bo.toByteArray()
            } catch (e: Exception) {
                toast("Cannot save the cover")
            }
        }
        val t = pf.tag(id, "title").ifEmpty { origTitle }
        AudioEngine.updateTrack(id, Track(uriStr, t, pf.tag(id, "artist"), pf.tag(id, "album"), id))
        pendingFields = fields.mapValues { it.value.text.toString().trim() }
        // now write the same information into the real audio file so other players show it too
        val d = busy("Saving…")
        val mp3 = isMp3()
        Thread {
            var tmp: java.io.File? = null
            var err = ""
            try {
                if (mp3) tmp = Id3.build(this, Uri.parse(uriStr), pendingFields, coverBytes)
            } catch (e: Exception) {
                err = e.message ?: "error"
            }
            runOnUiThread {
                d.dismiss()
                pendingTmp = tmp
                if (err.isNotEmpty()) finishSave("Saved in the app only ($err)") else askWrite()
            }
        }.start()
    }

    /** Android needs the user's OK once before an app may change a file it did not create. */
    fun askWrite() {
        val u = Uri.parse(uriStr)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startIntentSenderForResult(MediaStore.createWriteRequest(contentResolver, listOf(u)).intentSender, 11, null, 0, 0, 0)
            } else {
                writeNow(true)
            }
        } catch (e: Exception) {
            finishSave("Saved in the app only (no permission to change the file)")
        }
    }

    fun writeNow(mayAsk: Boolean) {
        val d = busy("Writing tags into the file…")
        Thread {
            var err: String? = null
            var recover: android.app.RecoverableSecurityException? = null
            try {
                err = Id3.apply(this, Uri.parse(uriStr), pendingTmp, pendingFields)
            } catch (e: android.app.RecoverableSecurityException) {
                recover = e
            }
            runOnUiThread {
                d.dismiss()
                val r = recover
                if (r != null && mayAsk) {
                    try { startIntentSenderForResult(r.userAction.actionIntent.intentSender, 11, null, 0, 0, 0) }
                    catch (e: Exception) { finishSave("Saved in the app only (no permission to change the file)") }
                } else if (r != null) finishSave("Saved in the app only (no permission to change the file)")
                else if (err != null) finishSave("Saved in the app only ($err)")
                else finishSave(if (pendingTmp != null || isMp3()) "Saved in the file — other players will show it" else "Saved (this format keeps tags only in the app and library)")
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: android.content.Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 12) {
            if (res == RESULT_OK) writeBatch() else finishSave("Saved in the app only (permission denied)")
            return
        }
        if (rc == 11) {
            if (res == RESULT_OK) writeNow(false)
            else finishSave("Saved in the app only (permission denied)")
        }
    }

    fun finishSave(msg: String) {
        toast(msg)
        setResult(RESULT_OK)
        finish()
    }
}
