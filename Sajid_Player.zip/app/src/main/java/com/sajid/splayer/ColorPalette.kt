package com.sajid.splayer

import android.app.Dialog
import android.content.Context
import android.graphics.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

/** Saturation / value square for the current hue (white -> hue left to right, transparent -> black top to bottom). */
private class SvView(c: Context) : View(c) {
    var hue = 0f
        set(v) { field = v; invalidate() }
    var sat = 1f
    var value = 1f
    var onChange: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = c.dpf(3) }
    private val rect = RectF()

    override fun onDraw(cv: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        val r = context.dpf(14)
        p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, Color.WHITE, Color.HSVToColor(floatArrayOf(hue, 1f, 1f)), Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, r, r, p)
        p.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), 0, Color.BLACK, Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, r, r, p)
        p.shader = null
        val x = sat * width
        val y = (1f - value) * height
        p.color = Color.HSVToColor(floatArrayOf(hue, sat, value))
        cv.drawCircle(x, y, context.dpf(14), p)
        cv.drawCircle(x, y, context.dpf(14), ring)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent.requestDisallowInterceptTouchEvent(true)
        sat = (e.x / width).coerceIn(0f, 1f)
        value = 1f - (e.y / height).coerceIn(0f, 1f)
        invalidate(); onChange?.invoke()
        return true
    }
}

/** Rainbow hue slider. */
private class HueView(c: Context) : View(c) {
    var hue = 0f
        set(v) { field = v; invalidate() }
    var onChange: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = c.dpf(3) }

    override fun onDraw(cv: Canvas) {
        val r = context.dpf(12)
        val top = height / 2f - r
        val cols = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, cols, null, Shader.TileMode.CLAMP)
        cv.drawRoundRect(0f, top, width.toFloat(), top + 2 * r, r, r, p)
        p.shader = null
        val x = (hue / 360f * width).coerceIn(r, width - r)
        p.color = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        cv.drawCircle(x, height / 2f, context.dpf(15), p)
        cv.drawCircle(x, height / 2f, context.dpf(15), ring)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent.requestDisallowInterceptTouchEvent(true)
        hue = (e.x / width).coerceIn(0f, 1f) * 360f
        if (hue >= 360f) hue = 359.99f
        invalidate(); onChange?.invoke()
        return true
    }
}

/** Full colour palette (any colour): pick shade in the square, hue on the slider, tick to apply. */
fun Context.colorPalette(cur: Int, cb: (Int) -> Unit) {
    val hsv = FloatArray(3)
    Color.colorToHSV(cur, hsv)
    val dlg = Dialog(this)
    dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val root = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(0xFF121212.toInt())
        setPadding(dp(16), dp(16), dp(16), dp(24))
    }
    val top = FrameLayout(this)
    val x = ImageView(this).apply {
        setPadding(dp(10), dp(10), dp(10), dp(10)); setImageDrawable(PathIcon(Ic.CLOSE, Color.WHITE))
        background = ripple(null, dpf(24)); setOnClickListener { dlg.dismiss() }
    }
    val ok = ImageView(this).apply {
        setPadding(dp(10), dp(10), dp(10), dp(10)); setImageDrawable(PathIcon(Ic.CHECK, Color.WHITE))
        background = ripple(null, dpf(24))
    }
    top.addView(x, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START))
    top.addView(ok, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END))
    root.addView(top)
    val sv = SvView(this).also { it.hue = hsv[0]; it.sat = hsv[1]; it.value = hsv[2] }
    root.addView(sv, LinearLayout.LayoutParams(-1, dp(230)).apply { topMargin = dp(16) })
    val hue = HueView(this).also { it.hue = hsv[0] }
    root.addView(hue, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(24) })
    val preview = View(this)
    fun now() = Color.HSVToColor(floatArrayOf(hue.hue, sv.sat, sv.value))
    fun refresh() { preview.background = rr(now(), dpf(14), dp(1), 0x44FFFFFF) }
    sv.onChange = { refresh() }
    hue.onChange = { sv.hue = hue.hue; refresh() }
    refresh()
    root.addView(preview, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(20) })
    ok.setOnClickListener { cb(now() or 0xFF000000.toInt()); dlg.dismiss() }
    dlg.setContentView(root)
    dlg.window?.apply {
        setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setGravity(Gravity.CENTER)
    }
    dlg.show()
}
