package com.sajid.splayer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews

/** 4 x 1 home-screen music widget: cover, name, previous / play-pause / next. */
class MusicWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { refresh(c, true) }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) {
        super.onAppWidgetOptionsChanged(c, m, id, o)
        refresh(c, true)
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val a = i.action ?: return
        if (a != PREV && a != PLAY && a != NEXT) return
        val p = AudioEngine.player
        if (p == null || AudioEngine.current == null) {
            // nothing is loaded in this process yet: open the app
            c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        try {
            when (a) {
                PREV -> p.seekToPrevious()
                NEXT -> p.seekToNext()
                else -> AudioEngine.toggle()
            }
        } catch (e: Exception) {
        }
        refresh(c, true)
    }

    companion object {
        const val PREV = "com.sajid.splayer.W_PREV"
        const val PLAY = "com.sajid.splayer.W_PLAY"
        const val NEXT = "com.sajid.splayer.W_NEXT"
        private var lastKey = ""
        private var artUri = ""
        private var artBmp: Bitmap? = null

        private fun pi(c: Context, a: String): PendingIntent =
            PendingIntent.getBroadcast(c, a.hashCode(), Intent(c, MusicWidget::class.java).setAction(a), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        /** called by the audio engine on every change (cheap when nothing visible changed) */
        fun refresh(ctx: Context, force: Boolean = false) {
            try {
                val c = ctx.applicationContext
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, MusicWidget::class.java))
                if (ids.isEmpty()) return
                val t = AudioEngine.current
                val playing = AudioEngine.player?.isPlaying == true
                val key = (t?.uri ?: "") + "|" + (t?.title ?: "") + "|" + playing + "|" + (artUri == (t?.uri ?: ""))
                if (!force && key == lastKey) return
                lastKey = key
                val bmp = if (t != null && artUri == t.uri) artBmp else null
                val open = if (t != null) Intent(c, AudioPlayerActivity::class.java) else Intent(c, MainActivity::class.java)
                val openPi = PendingIntent.getActivity(c, 7, open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                for (id in ids) {
                    val o = m.getAppWidgetOptions(id)
                    val wd = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
                    val ht = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 56)
                    val v = RemoteViews(c.packageName, R.layout.widget_music)
                    v.setTextViewText(R.id.w_title, t?.title?.ifEmpty { "Unknown" } ?: "Sajid Player")
                    v.setTextViewText(R.id.w_sub, if (t != null) t.shownArtist else "Tap to open")
                    // text follows the widget height; small widgets drop the artist line and the previous / next buttons
                    v.setTextViewTextSize(R.id.w_title, android.util.TypedValue.COMPLEX_UNIT_SP, (ht / 4f).coerceIn(11f, 24f))
                    v.setTextViewTextSize(R.id.w_sub, android.util.TypedValue.COMPLEX_UNIT_SP, (ht / 5.5f).coerceIn(9f, 16f))
                    v.setViewVisibility(R.id.w_sub, if (ht < 52) android.view.View.GONE else android.view.View.VISIBLE)
                    v.setViewVisibility(R.id.w_prev, if (wd < 150) android.view.View.GONE else android.view.View.VISIBLE)
                    v.setViewVisibility(R.id.w_next, if (wd < 150) android.view.View.GONE else android.view.View.VISIBLE)
                    v.setViewVisibility(R.id.w_art, if (wd < 110) android.view.View.GONE else android.view.View.VISIBLE)
                    v.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
                    if (bmp != null) v.setImageViewBitmap(R.id.w_art, bmp) else v.setImageViewResource(R.id.w_art, R.mipmap.ic_launcher)
                    v.setOnClickPendingIntent(R.id.w_prev, pi(c, PREV))
                    v.setOnClickPendingIntent(R.id.w_play, pi(c, PLAY))
                    v.setOnClickPendingIntent(R.id.w_next, pi(c, NEXT))
                    v.setOnClickPendingIntent(R.id.w_open, openPi)
                    m.updateAppWidget(id, v)
                }
                if (t != null && artUri != t.uri) {
                    val u = t.uri; val id = t.id
                    Thread {
                        val b = try { Art.load(c, u, id, 128) } catch (e: Exception) { null }
                        artUri = u
                        artBmp = b
                        android.os.Handler(android.os.Looper.getMainLooper()).post { refresh(c, true) }
                    }.start()
                }
            } catch (e: Exception) {
            }
        }
    }
}
