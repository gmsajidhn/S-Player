package com.sajid.splayer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.RemoteViews

/**
 * 4 x 1 home-screen music widget: name and artist on the left, previous / play-pause / next with thin dividers,
 * a progress line along the bottom, the cover picture (dimmed) as the background under the text. Freely resizable.
 */
class MusicWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { refresh(c, true) }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) {
        super.onAppWidgetOptionsChanged(c, m, id, o)
        refresh(c, true)
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val a = i.action ?: return
        if (a != PREV && a != PLAY && a != NEXT) return
        val p = AudioEngine.player
        if (p == null || AudioEngine.current == null) {
            c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        try {
            when (a) {
                PREV -> p.seekToPrevious()
                NEXT -> p.seekToNext()
                else -> AudioEngine.toggle()
            }
        } catch (e: Exception) {
        }
        refresh(c, true)
    }

    companion object {
        const val PREV = "com.sajid.splayer.W_PREV"
        const val PLAY = "com.sajid.splayer.W_PLAY"
        const val NEXT = "com.sajid.splayer.W_NEXT"
        private var lastKey = ""
        private var artUri = ""
        private var bgBmp: Bitmap? = null
        private var plainBg: Bitmap? = null
        private val main = Handler(Looper.getMainLooper())
        private var looping = false

        private fun pi(c: Context, a: String): PendingIntent =
            PendingIntent.getBroadcast(c, a.hashCode(), Intent(c, MusicWidget::class.java).setAction(a), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        /** dark rounded card; with a cover: the picture cropped to the card and dimmed so the text stays readable */
        private fun background(cover: Bitmap?): Bitmap {
            val w = 800; val h = 200; val r = 56f
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(out)
            cv.clipPath(Path().apply { addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW) })
            cv.drawColor(0xFF15171A.toInt())
            if (cover != null) {
                val s = maxOf(w.toFloat() / cover.width, h.toFloat() / cover.height)
                val dw = cover.width * s; val dh = cover.height * s
                cv.drawBitmap(cover, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
                cv.drawColor(0x55000000)
                val gp = Paint()
                gp.shader = android.graphics.LinearGradient(0f, 0f, w.toFloat(), 0f, intArrayOf(0xE6000000.toInt(), 0x99000000.toInt(), 0x33000000), floatArrayOf(0f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP)
                cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), gp)
            } else cv.drawColor(0x33283038)
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.style = Paint.Style.STROKE; bp.strokeWidth = 3f; bp.color = 0x44FFFFFF
            cv.drawRoundRect(RectF(1.5f, 1.5f, w - 1.5f, h - 1.5f), r, r, bp)
            return out
        }

        private fun progressOf(): Pair<Int, Int> {
            val p = AudioEngine.player ?: return Pair(1, 0)
            val d = (p.duration / 1000).toInt().coerceAtLeast(1)
            return Pair(d, (p.currentPosition / 1000).toInt().coerceIn(0, d))
        }

        /** only the progress line (cheap; runs every few seconds while music plays) */
        private fun progressOnly(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, MusicWidget::class.java))
                if (ids.isEmpty()) { looping = false; return }
                val v = RemoteViews(c.packageName, R.layout.widget_music)
                val (mx, ps) = progressOf()
                v.setProgressBar(R.id.w_prog, mx, ps, false)
                m.partiallyUpdateAppWidget(ids, v)
                if (AudioEngine.player?.isPlaying == true) main.postDelayed({ progressOnly(c) }, 2000) else looping = false
            } catch (e: Exception) {
                looping = false
            }
        }

        /** called by the audio engine on every change (cheap when nothing visible changed) */
        fun refresh(ctx: Context, force: Boolean = false) {
            try {
                val c = ctx.applicationContext
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, MusicWidget::class.java))
                if (ids.isEmpty()) return
                val t = AudioEngine.current
                val playing = AudioEngine.player?.isPlaying == true
                val key = (t?.uri ?: "") + "|" + (t?.title ?: "") + "|" + playing + "|" + (artUri == (t?.uri ?: ""))
                if (!force && key == lastKey) return
                lastKey = key
                val bg = if (t != null && artUri == t.uri && bgBmp != null) bgBmp!! else (plainBg ?: background(null).also { plainBg = it })
                val open = if (t != null) Intent(c, AudioPlayerActivity::class.java) else Intent(c, MainActivity::class.java)
                val openPi = PendingIntent.getActivity(c, 7, open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val (mx, ps) = progressOf()
                for (id in ids) {
                    val o = m.getAppWidgetOptions(id)
                    val wd = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
                    val ht = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 56)
                    val v = RemoteViews(c.packageName, R.layout.widget_music)
                    v.setImageViewBitmap(R.id.w_bg, bg)
                    v.setTextViewText(R.id.w_title, t?.title?.ifEmpty { "Unknown" } ?: "Sajid Player")
                    v.setTextViewText(R.id.w_sub, if (t != null) t.shownArtist else "Tap to open")
                    // text follows the widget height; small widgets drop the artist line and the previous / next buttons
                    v.setTextViewTextSize(R.id.w_title, android.util.TypedValue.COMPLEX_UNIT_SP, (ht / 3.6f).coerceIn(11f, 26f))
                    v.setTextViewTextSize(R.id.w_sub, android.util.TypedValue.COMPLEX_UNIT_SP, (ht / 4.2f).coerceIn(9f, 20f))
                    v.setViewVisibility(R.id.w_sub, if (ht < 52) View.GONE else View.VISIBLE)
                    val small = wd < 170
                    for (i in intArrayOf(R.id.w_prev, R.id.w_next, R.id.w_d1, R.id.w_d3)) v.setViewVisibility(i, if (small) View.GONE else View.VISIBLE)
                    v.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
                    v.setProgressBar(R.id.w_prog, mx, ps, false)
                    v.setOnClickPendingIntent(R.id.w_prev, pi(c, PREV))
                    v.setOnClickPendingIntent(R.id.w_play, pi(c, PLAY))
                    v.setOnClickPendingIntent(R.id.w_next, pi(c, NEXT))
                    v.setOnClickPendingIntent(R.id.w_open, openPi)
                    m.updateAppWidget(id, v)
                }
                if (t != null && artUri != t.uri) {
                    val u = t.uri; val id = t.id
                    Thread {
                        val b = try { Art.load(c, u, id, 400) } catch (e: Exception) { null }
                        bgBmp = background(b)
                        artUri = u
                        main.post { refresh(c, true) }
                    }.start()
                }
                if (playing && !looping) { looping = true; main.postDelayed({ progressOnly(c) }, 2000) }
            } catch (e: Exception) {
            }
        }
    }
}
