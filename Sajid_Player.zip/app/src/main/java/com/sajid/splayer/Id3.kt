package com.sajid.splayer

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Writes title / artist / album / genre / year / track / comment / cover INTO the MP3 file (ID3v2.3),
 * so every other player shows the edited information. Frames we do not edit (lyrics, replay-gain …) are kept.
 */
object Id3 {
    // frames we rewrite + v2.4-only frames that do not exist in v2.3
    private val DROP = setOf(
        "TIT2", "TPE1", "TALB", "TCON", "TYER", "TDRC", "TRCK", "COMM",
        "TDEN", "TDOR", "TDRL", "TDTG", "TIPL", "TMCL", "TMOO", "TPRO", "TSOA", "TSOP", "TSOT", "TSST",
        "ASPI", "EQU2", "RVA2", "SEEK", "SIGN"
    )

    private fun be32(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
    private fun rd32(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)
    private fun synch(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0x7F) shl 21) or ((b[o + 1].toInt() and 0x7F) shl 14) or ((b[o + 2].toInt() and 0x7F) shl 7) or (b[o + 3].toInt() and 0x7F)
    private fun unsynch(v: Int) = byteArrayOf(((v shr 21) and 0x7F).toByte(), ((v shr 14) and 0x7F).toByte(), ((v shr 7) and 0x7F).toByte(), (v and 0x7F).toByte())

    private fun readFully(s: InputStream, buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) {
            val r = s.read(buf, n, buf.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun latin1(v: String) = v.all { it.code <= 0xFF }

    private fun frame(id: String, data: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(id.toByteArray(Charsets.ISO_8859_1))
        o.write(be32(data.size))
        o.write(0); o.write(0)
        o.write(data)
        return o.toByteArray()
    }

    private fun textFrame(id: String, v: String, out: ByteArrayOutputStream) {
        if (v.isEmpty()) return
        val d = ByteArrayOutputStream()
        if (latin1(v)) { d.write(0); d.write(v.toByteArray(Charsets.ISO_8859_1)) }
        else { d.write(1); d.write(0xFF); d.write(0xFE); d.write(v.toByteArray(Charsets.UTF_16LE)) }
        out.write(frame(id, d.toByteArray()))
    }

    private fun commentFrame(v: String, out: ByteArrayOutputStream) {
        if (v.isEmpty()) return
        val d = ByteArrayOutputStream()
        if (latin1(v)) {
            d.write(0); d.write("eng".toByteArray()); d.write(0)
            d.write(v.toByteArray(Charsets.ISO_8859_1))
        } else {
            d.write(1); d.write("eng".toByteArray())
            d.write(0xFF); d.write(0xFE); d.write(0); d.write(0)
            d.write(0xFF); d.write(0xFE); d.write(v.toByteArray(Charsets.UTF_16LE))
        }
        out.write(frame("COMM", d.toByteArray()))
    }

    private fun coverFrame(jpeg: ByteArray, out: ByteArrayOutputStream) {
        val d = ByteArrayOutputStream()
        d.write(0)
        d.write("image/jpeg".toByteArray(Charsets.ISO_8859_1)); d.write(0)
        d.write(3)          // front cover
        d.write(0)          // empty description
        d.write(jpeg)
        out.write(frame("APIC", d.toByteArray()))
    }

    /** Copies the frames of an existing v2.3 / v2.4 tag that we keep, converted to v2.3 layout. */
    private fun keepOld(body: ByteArray, ver: Int, flags: Int, dropCover: Boolean, out: ByteArrayOutputStream) {
        var pos = 0
        if (flags and 0x40 != 0) {
            if (body.size < 4) return
            pos = if (ver == 4) synch(body, 0) else rd32(body, 0) + 4
        }
        while (pos + 10 <= body.size) {
            if (body[pos].toInt() == 0) break
            val id = String(body, pos, 4, Charsets.ISO_8859_1)
            if (!id.all { it in 'A'..'Z' || it in '0'..'9' }) break
            val sz = if (ver == 4) synch(body, pos + 4) else rd32(body, pos + 4)
            val fl2 = body[pos + 9].toInt() and 0xFF
            val start = pos + 10
            val end = start + sz
            if (sz < 0 || end > body.size) break
            pos = end
            if (id in DROP || (dropCover && id == "APIC")) continue
            if (ver == 4 && (fl2 and 0x4F) != 0) continue
            if (ver == 3 && (fl2 and 0xE0) != 0) continue
            out.write(id.toByteArray(Charsets.ISO_8859_1))
            out.write(be32(sz))
            out.write(0); out.write(0)
            out.write(body, start, sz)
        }
    }

    /** Builds "new tag + audio" in a temp file. Throws on any read problem; nothing is modified yet. */
    fun build(c: Context, uri: Uri, f: Map<String, String>, cover: ByteArray?): File {
        val tmp = File(c.cacheDir, "tag_tmp.mp3")
        val raw = c.contentResolver.openInputStream(uri) ?: throw Exception("Cannot read the file")
        BufferedInputStream(raw, 64 * 1024).use { s ->
            val head = ByteArray(10)
            val n = readFully(s, head)
            val kept = ByteArrayOutputStream()
            var lead: ByteArray? = null
            val isId3 = n == 10 && head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() && head[2] == '3'.code.toByte()
            if (isId3) {
                val ver = head[3].toInt() and 0xFF
                val flags = head[5].toInt() and 0xFF
                val size = synch(head, 6)
                val body = ByteArray(size)
                readFully(s, body)
                if (ver == 4 && (flags and 0x10) != 0) readFully(s, ByteArray(10))
                if ((ver == 3 || ver == 4) && (flags and 0x80) == 0) keepOld(body, ver, flags, cover != null, kept)
            } else if (n > 0) {
                lead = head.copyOf(n)
            }

            val nf = ByteArrayOutputStream()
            textFrame("TIT2", f["title"] ?: "", nf)
            textFrame("TPE1", f["artist"] ?: "", nf)
            textFrame("TALB", f["album"] ?: "", nf)
            textFrame("TCON", f["genre"] ?: "", nf)
            val yr = (f["year"] ?: "").trim()
            if (yr.length == 4 && yr.all { it.isDigit() }) textFrame("TYER", yr, nf)
            textFrame("TRCK", (f["track"] ?: "").trim(), nf)
            commentFrame(f["comment"] ?: "", nf)
            if (cover != null) coverFrame(cover, nf)
            nf.write(kept.toByteArray())

            FileOutputStream(tmp).use { o ->
                o.write("ID3".toByteArray(Charsets.ISO_8859_1))
                o.write(3); o.write(0); o.write(0)
                o.write(unsynch(nf.size()))
                nf.writeTo(o)
                lead?.let { o.write(it) }
                s.copyTo(o, 64 * 1024)
            }
        }
        return tmp
    }

    /**
     * Replaces the file's content with the prepared temp file (when tmp != null) and refreshes the MediaStore fields.
     * Returns null on success, otherwise an error text. RecoverableSecurityException (Android 10) is passed up.
     */
    fun apply(c: Context, uri: Uri, tmp: File?, f: Map<String, String>): String? {
        try {
            if (tmp != null) {
                val os = c.contentResolver.openOutputStream(uri, "wt") ?: return "Cannot open the file for writing"
                os.use { o -> FileInputStream(tmp).use { i -> i.copyTo(o, 64 * 1024) } }
            }
            try {
                val cv = ContentValues()
                (f["title"] ?: "").let { if (it.isNotEmpty()) cv.put("title", it) }
                (f["artist"] ?: "").let { if (it.isNotEmpty()) cv.put("artist", it) }
                (f["album"] ?: "").let { if (it.isNotEmpty()) cv.put("album", it) }
                (f["year"] ?: "").trim().toIntOrNull()?.let { cv.put("year", it) }
                (f["track"] ?: "").trim().toIntOrNull()?.let { cv.put("track", it) }
                if (cv.size() > 0) c.contentResolver.update(uri, cv, null, null)
            } catch (e: RecoverableSecurityException) {
                throw e
            } catch (e: Exception) {
            }
            try { tmp?.delete() } catch (e: Exception) {}
            return null
        } catch (e: RecoverableSecurityException) {
            throw e
        } catch (e: Exception) {
            try { tmp?.delete() } catch (e2: Exception) {}
            return e.message ?: "Write failed"
        }
    }
}
