package com.sajid.splayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.os.Build
import java.util.Locale

class Item(
    val id: Long, val uri: Uri, val name: String, val folder: String, val size: Long, val dur: Long,
    val path: String, val added: Long, val w: Int, val h: Int, val artist: String, val video: Boolean,
    val album: String = "", val genre: String = "", val tTitle: String = "",
    val rel: String = "", val mime: String = "", val folderLock: Boolean = false,
    /** locked by a leading "." in the file name (file stays on the phone, hidden everywhere) */
    val dotLock: Boolean = false
) {
    /** true for files that live in the private vault (not in MediaStore any more) */
    val vault: Boolean get() = id < 0
    val key: String get() = (if (video) "v" else "a") + id
    val title: String get() = if (tTitle.isNotEmpty()) tTitle else name.substringBeforeLast('.')
}

object Media {
    fun load(c: Context, video: Boolean): List<Item> {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val pf = Prefs(c)
        val cols: Array<String> = if (video)
            arrayOf("_id", "_display_name", "bucket_display_name", "_size", "duration", "_data", "date_added", "width", "height", "relative_path", "mime_type")
        else if (Build.VERSION.SDK_INT >= 30)
            arrayOf("_id", "_display_name", "bucket_display_name", "_size", "duration", "_data", "date_added", "artist", "album", "genre", "relative_path", "mime_type")
        else
            arrayOf("_id", "_display_name", "bucket_display_name", "_size", "duration", "_data", "date_added", "artist", "album", "relative_path", "mime_type")
        val out = ArrayList<Item>()
        try {
            c.contentResolver.query(base, cols, null, null, "date_added DESC")?.use {
                while (it.moveToNext()) {
                    val id = it.getLong(0)
                    var artist = ""
                    var album = ""
                    var genre = ""
                    var tt = ""
                    if (!video) {
                        val a = it.getString(7) ?: ""
                        artist = if (a == "<unknown>") "" else a
                        val al = it.getString(8) ?: ""
                        album = if (al == "<unknown>") "" else al
                        if (Build.VERSION.SDK_INT >= 30) genre = it.getString(9) ?: ""
                        tt = pf.tag(id, "title")
                        val ta = pf.tag(id, "artist"); if (ta.isNotEmpty()) artist = ta
                        val tb = pf.tag(id, "album"); if (tb.isNotEmpty()) album = tb
                        val tg = pf.tag(id, "genre"); if (tg.isNotEmpty()) genre = tg
                    }
                    val ri = it.getColumnIndex("relative_path")
                    val mi = it.getColumnIndex("mime_type")
                    val rel = if (ri >= 0) (it.getString(ri) ?: "") else ""
                    val mime = if (mi >= 0) (it.getString(mi) ?: "") else ""
                    out.add(
                        Item(
                            id, ContentUris.withAppendedId(base, id), it.getString(1) ?: "?", it.getString(2) ?: "Other",
                            it.getLong(3), it.getLong(4), it.getString(5) ?: "", it.getLong(6),
                            if (video) it.getInt(7) else 0, if (video) it.getInt(8) else 0, artist, video,
                            album, genre, tt, rel, mime
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun size(b: Long): String =
        if (b >= 1_000_000_000L) String.format(Locale.US, "%.1f GB", b / 1e9)
        else if (b >= 1_000_000L) String.format(Locale.US, "%.1f MB", b / 1e6)
        else String.format(Locale.US, "%.1f KB", b / 1e3)

    fun size2(b: Long): String =
        if (b >= 1_000_000_000L) String.format(Locale.US, "%.2f GB", b / 1e9)
        else if (b >= 1_000_000L) String.format(Locale.US, "%.2f MB", b / 1e6)
        else String.format(Locale.US, "%.1f KB", b / 1e3)

    fun time(ms: Long): String {
        val s = maxOf(ms, 0L) / 1000
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
        else String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    /** 01:42:48.9 style stamp used by the cutter */
    fun stamp(ms: Long): String {
        val t = maxOf(ms, 0L) / 100
        return String.format(Locale.US, "%02d:%02d:%02d.%d", t / 36000, t / 600 % 60, t / 10 % 60, t % 10)
    }
}
