package com.sajid.splayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

/**
 * Floating music pill over every app: round cover with the elapsed time, seek line, total time, play / pause, close.
 * Tap the round cover to shrink the pill to just the circle (and tap again to open it); drag anywhere to move it.
 */
class MusicFloatService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private lateinit var pal: Pal
    private lateinit var art: ImageView
    private lateinit var circleBox: FrameLayout
    private lateinit var curTv: TextView
    private lateinit var durTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var play: ImageView
    private lateinit var close: ImageView
    private var collapsed = false
    private var shownUri = ""
    private var user = false
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 500)
        }
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format("%d:%02d", s / 60, s % 60)
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        if (root == null) build()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("popup", "Pop-up", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, "popup")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Music pop-up")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(32, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(32, n)
    }

    private fun build() {
        val pf = Prefs(this)
        pal = Pal(true, pf.accent)
        val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = w
        val dm = resources.displayMetrics

        val pill = LinearLayout(this)
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(5), dp(5), dp(8), dp(5))
        pill.background = rr(0xE6323A40.toInt(), dpf(34), dp(1), 0x33FFFFFF)

        circleBox = FrameLayout(this)
        art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rr(0xFF4A5057.toInt(), dpf(31))
        art.roundClip(dpf(31))
        art.setPadding(dp(16), dp(16), dp(16), dp(16))
        art.setImageDrawable(PathIcon(Ic.MUSIC, 0xFFC9CDD2.toInt()))
        circleBox.addView(art, FrameLayout.LayoutParams(dp(62), dp(62)))
        curTv = label("0:00", 13f, Color.WHITE, true)
        curTv.setShadowLayer(dpf(4), 0f, 0f, Color.BLACK)
        circleBox.addView(curTv, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(5) })
        pill.addView(circleBox, LinearLayout.LayoutParams(dp(62), dp(62)))

        seek = SeekBar(this)
        seek.progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0x66FFFFFF)
        seek.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { if (u) curTv.text = fmt(v.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) { user = true }
            override fun onStopTrackingTouch(s: SeekBar?) { user = false; AudioEngine.player?.seekTo(seek.progress.toLong()) }
        })
        pill.addView(seek, LinearLayout.LayoutParams(dp(140), dp(40)).apply { marginStart = dp(6) })
        durTv = label("0:00", 15f, Color.WHITE, true)
        durTv.setPadding(dp(8), 0, dp(4), 0)
        pill.addView(durTv)
        play = iconBtn(Ic.PLAY, Color.WHITE, 40, 24) { AudioEngine.toggle() }
        pill.addView(play, LinearLayout.LayoutParams(dp(40), dp(40)))
        close = iconBtn(Ic.CLOSE, Color.WHITE, 40, 22) { stopSelf() }
        pill.addView(close, LinearLayout.LayoutParams(dp(40), dp(40)))

        // drag the pill anywhere; a tap on the round cover shrinks it to the circle / opens it again
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false; var onCircle = false
        pill.setOnTouchListener { v, e ->
            val p = params ?: return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false
                    onCircle = e.x >= 0 && e.x <= circleBox.right + dp(4)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - dx) > dp(6) || abs(e.rawY - dy) > dp(6)) moved = true
                    if (moved) {
                        p.x = (sx + (e.rawX - dx)).toInt().coerceIn(-dp(20), dm.widthPixels - v.width + dp(20))
                        p.y = (sy + (e.rawY - dy)).toInt().coerceIn(0, dm.heightPixels - v.height)
                        try { wm?.updateViewLayout(v, p) } catch (x: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved && onCircle) toggleCollapse()
            }
            true
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(16)
        lp.y = (dm.heightPixels * 0.62f).toInt()
        params = lp
        root = pill
        try { w.addView(pill, lp) } catch (e: Exception) { toast("Cannot open pop-up window"); stopSelf(); return }
        h.post(tick)
    }

    private fun toggleCollapse() {
        collapsed = !collapsed
        val vis = if (collapsed) View.GONE else View.VISIBLE
        seek.visibility = vis; durTv.visibility = vis; play.visibility = vis; close.visibility = vis
        root?.let { r ->
            r.setPadding(dp(5), dp(5), if (collapsed) dp(5) else dp(8), dp(5))
            try { wm?.updateViewLayout(r, params) } catch (e: Exception) {}
        }
    }

    private fun refresh() {
        val t = AudioEngine.current
        val p = AudioEngine.player
        if (t == null || p == null) return
        if (t.uri != shownUri) {
            shownUri = t.uri
            val u = t.uri; val id = t.id
            Thread {
                val bmp = Art.load(this, u, id, 256)
                h.post {
                    if (shownUri != u) return@post
                    if (bmp != null) { art.setPadding(0, 0, 0, 0); art.setImageBitmap(bmp) }
                    else { art.setPadding(dp(16), dp(16), dp(16), dp(16)); art.setImageDrawable(PathIcon(Ic.MUSIC, 0xFFC9CDD2.toInt())) }
                }
            }.start()
        }
        val d = p.duration.coerceAtLeast(0L)
        if (!user) {
            seek.max = d.toInt().coerceAtLeast(1)
            seek.progress = p.currentPosition.toInt()
            curTv.text = fmt(p.currentPosition)
        }
        durTv.text = fmt(d)
        play.setImageDrawable(PathIcon(if (p.isPlaying) Ic.PAUSE else Ic.PLAY, Color.WHITE))
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
        try { root?.let { wm?.removeView(it) } } catch (e: Exception) {}
        root = null
    }
}
