package com.sajid.splayer

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat

/** Takes every touch itself, so an icon that was dragged away from its row can still be grabbed again. */
class EditStage(c: Context) : FrameLayout(c) {
    var onTouch: ((MotionEvent) -> Boolean)? = null
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = true
    override fun onTouchEvent(e: MotionEvent): Boolean = onTouch?.invoke(e) ?: true
}

/**
 * Settings > Video player layout.
 * A copy of the video player controls: drag any icon where you want it, pick an icon and change its size.
 * Portrait and landscape are saved separately (rotate the phone to edit the other one).
 */
class LayoutEditorActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    private val lay = LinkedHashMap<String, View>()
    private val names = mapOf(
        "back" to "Back", "queue" to "Queue", "more" to "More menu", "fit" to "Fit / crop", "rotate" to "Rotate",
        "mode" to "Play mode", "ab" to "A-B repeat", "bg" to "Background play", "prev" to "Previous", "next" to "Next",
        "play" to "Play / pause", "pip" to "Pop-up player", "lock" to "Lock", "speed" to "Speed"
    )
    private var sel: String? = null
    private var key = "p"
    private lateinit var info: TextView
    private lateinit var sizeBar: SeekBar
    private var sizeTxt: TextView? = null
    private var fromUser = true

    private fun <T : View> reg(id: String, v: T): T { lay[id] = v; return v }
    private fun ox(id: String) = pf.i("lx_${key}_$id", 0)
    private fun oy(id: String) = pf.i("ly_${key}_$id", 0)
    private fun os(id: String) = pf.i("ls_${key}_$id", 100)

    override fun onCreate(b: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(b)
        pal = Pal(pf.dark, pf.accent)
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !pal.dark
            isAppearanceLightNavigationBars = !pal.dark
        }
        key = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "l" else "p"
        build()
    }

    private fun build() {
        lay.clear()
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(pal.bg)
        page.fitsSystemWindows = true

        val stage = EditStage(this)
        stage.setBackgroundColor(Color.BLACK)
        stage.clipChildren = false
        val hint = label("Video", 22f, 0x22FFFFFF, true)
        stage.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // ---- same structure as the real player
        val top = LinearLayout(this)
        top.orientation = LinearLayout.VERTICAL
        top.clipChildren = false
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.clipChildren = false
        bar.addView(reg("back", iconBtn(Ic.BACK, Color.WHITE, 48, 26) {}))
        val title = label("Video title", 17f, Color.WHITE, true)
        title.setPadding(dp(8), 0, dp(8), 0)
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(reg("queue", iconBtn(Ic.QUEUE, Color.WHITE, 48, 24) {}))
        bar.addView(reg("more", iconBtn(Ic.MORE, Color.WHITE, 48, 24) {}))
        top.addView(bar)
        top.setPadding(dp(8), dp(4), dp(8), dp(8))
        stage.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bot = LinearLayout(this)
        bot.orientation = LinearLayout.VERTICAL
        bot.clipChildren = false
        val prow = LinearLayout(this)
        prow.gravity = Gravity.CENTER_VERTICAL
        prow.clipChildren = false
        prow.addView(reg("fit", iconBtn(Ic.FIT, Color.WHITE, 40, 22) {}))
        prow.addView(label("0:12", 16f, Color.WHITE, true))
        val fake = View(this)
        fake.background = rr(0x88FFFFFF.toInt(), dpf(2))
        prow.addView(fake, LinearLayout.LayoutParams(0, dp(3), 1f).apply { setMargins(dp(12), 0, dp(12), 0) })
        prow.addView(label("3:20", 16f, 0xCCFFFFFF.toInt(), true))
        prow.addView(reg("rotate", iconBtn(Ic.ROTATE, Color.WHITE, 40, 22) {}))
        bot.addView(prow, LinearLayout.LayoutParams(-1, dp(40)))
        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER_VERTICAL
        ctl.clipChildren = false
        ctl.addView(reg("mode", iconBtn(Ic.ORDER, Color.WHITE, 40, 22) {}))
        ctl.addView(reg("ab", iconBtn(Ic.SWAP, Color.WHITE, 40, 22) {}))
        ctl.addView(reg("bg", iconBtn(Ic.HEADPHONES, Color.WHITE, 40, 22) {}))
        ctl.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        ctl.addView(reg("prev", iconBtn(Ic.PREV, Color.WHITE, 48, 28) {}))
        ctl.addView(reg("next", iconBtn(Ic.NEXT, Color.WHITE, 48, 28) {}))
        val playBtn = ImageView(this)
        playBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        playBtn.setImageDrawable(PathIcon(Ic.PLAY, Color.WHITE))
        ctl.addView(reg("play", playBtn), LinearLayout.LayoutParams(dp(56), dp(56)))
        bot.addView(ctl, LinearLayout.LayoutParams(-1, -2))
        bot.setPadding(dp(8), dp(8), dp(8), dp(6))
        stage.addView(bot, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.clipChildren = false
        side.addView(reg("pip", iconBtn(Ic.PIP, Color.WHITE, 44, 24) {}))
        side.addView(reg("lock", iconBtn(Ic.LOCK, Color.WHITE, 44, 24) {}))
        side.addView(reg("speed", iconBtn(Ic.SPEED, Color.WHITE, 44, 24) {}))
        stage.addView(side, FrameLayout.LayoutParams(dp(44), -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(4); bottomMargin = dp(44) })

        for ((id, v) in lay) {
            v.isClickable = false
            v.background = null
            apply(id)
        }
        stage.onTouch = { e -> touch(e) }
        page.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- controls under the preview
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(12), dp(16), dp(12))
        info = label("Drag an icon to move it. Tap it to change its size.", 15f, pal.text, true)
        card.addView(info)
        val sub = label(if (key == "l") "Editing the LANDSCAPE layout (rotate the phone for portrait)" else "Editing the PORTRAIT layout (rotate the phone for landscape)", 12.5f, pal.sub)
        sub.setPadding(0, dp(2), 0, dp(6))
        card.addView(sub)
        val srow = LinearLayout(this)
        srow.gravity = Gravity.CENTER_VERTICAL
        sizeTxt = label("100%", 15f, pal.sub)
        sizeBar = SeekBar(this)
        sizeBar.max = 210            // 40% .. 250%
        sizeBar.progress = 60
        sizeBar.isEnabled = false
        sizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                val id = sel ?: return
                val pct = p + 40
                sizeTxt?.text = "$pct%"
                if (u) { pf.put("ls_${key}_$id", pct); apply(id) }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        srow.addView(label("Size", 15f, pal.text, true))
        srow.addView(sizeBar, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(10), 0, dp(10), 0) })
        srow.addView(sizeTxt)
        card.addView(srow)
        val brow = LinearLayout(this)
        brow.setPadding(0, dp(8), 0, 0)
        fun btn(t: String, strong: Boolean, click: () -> Unit): TextView {
            val tv = label(t, 15f, if (strong) pal.onSel else pal.text, true)
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(14), dp(10), dp(14), dp(10))
            tv.background = rr(if (strong) pal.selTab else pal.tile, dpf(20))
            tv.setOnClickListener { click() }
            return tv
        }
        brow.addView(btn("Reset icon", false) { sel?.let { resetOne(it) } }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        brow.addView(btn("Reset all", false) { for (id in lay.keys) resetOne(id) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        brow.addView(btn("Done", true) { finish() }, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(brow)
        page.addView(card, LinearLayout.LayoutParams(-1, -2))
        setContentView(page)
    }

    private fun apply(id: String) {
        val v = lay[id] ?: return
        v.translationX = dp(ox(id)).toFloat()
        v.translationY = dp(oy(id)).toFloat()
        val sc = os(id) / 100f
        v.scaleX = sc
        v.scaleY = sc
    }

    private fun resetOne(id: String) {
        pf.sp.edit().remove("lx_${key}_$id").remove("ly_${key}_$id").remove("ls_${key}_$id").apply()
        apply(id)
        if (sel == id) select(id)
    }

    private fun select(id: String?) {
        sel = id
        for ((k, v) in lay) v.background = if (k == id) rr(0x33FFFFFF, dpf(30), dp(2), pal.bright) else null
        if (id == null) {
            info.text = "Drag an icon to move it. Tap it to change its size."
            sizeBar.isEnabled = false
        } else {
            info.text = names[id] ?: id
            sizeBar.isEnabled = true
            sizeBar.progress = (os(id) - 40).coerceIn(0, 210)
            sizeTxt?.text = os(id).toString() + "%"
        }
    }

    private fun hit(x: Float, y: Float): String? {
        for ((id, v) in lay.entries.reversed()) {
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            val w = maxOf(v.width * v.scaleX, dpf(36))
            val h = maxOf(v.height * v.scaleY, dpf(36))
            val cx = loc[0] + v.width * v.scaleX / 2f
            val cy = loc[1] + v.height * v.scaleY / 2f
            if (x >= cx - w / 2 && x <= cx + w / 2 && y >= cy - h / 2 && y <= cy + h / 2) return id
        }
        return null
    }

    private var dragId: String? = null
    private var downX = 0f
    private var downY = 0f
    private var startOx = 0
    private var startOy = 0
    private var moved = false

    private fun touch(e: MotionEvent): Boolean {
        val d = resources.displayMetrics.density
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                moved = false
                dragId = hit(e.rawX, e.rawY)
                val id = dragId
                if (id != null) {
                    downX = e.rawX; downY = e.rawY
                    startOx = ox(id); startOy = oy(id)
                    select(id)
                } else select(null)
            }
            MotionEvent.ACTION_MOVE -> {
                val id = dragId ?: return true
                val dx = ((e.rawX - downX) / d).toInt()
                val dy = ((e.rawY - downY) / d).toInt()
                if (!moved && Math.abs(dx) < 3 && Math.abs(dy) < 3) return true
                moved = true
                val v = lay[id] ?: return true
                v.translationX = dp(startOx + dx).toFloat()
                v.translationY = dp(startOy + dy).toFloat()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val id = dragId
                if (id != null && moved) {
                    val dx = ((e.rawX - downX) / d).toInt()
                    val dy = ((e.rawY - downY) / d).toInt()
                    pf.put("lx_${key}_$id", startOx + dx)
                    pf.put("ly_${key}_$id", startOy + dy)
                }
                dragId = null
            }
        }
        return true
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
    }
}
