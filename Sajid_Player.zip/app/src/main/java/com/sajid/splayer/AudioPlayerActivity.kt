package com.sajid.splayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.LayerDrawable
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.media3.common.Player
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class AudioPlayerActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var am: AudioManager
    lateinit var vinyl: CoverView
    lateinit var vizView: VisualizerView
    lateinit var idxTxt: TextView
    lateinit var titleTxt: TextView
    lateinit var artistTxt: TextView
    lateinit var curTxt: TextView
    lateinit var durTxt: TextView
    lateinit var seek: SeekBar
    lateinit var playIc: PathIcon
    lateinit var heartIc: PathIcon
    lateinit var shufIc: PathIcon
    lateinit var modeCell: FrameLayout
    lateinit var sleepBtn: ImageView
    lateinit var sleepTxt: TextView
    lateinit var repIc: PathIcon
    var userSeeking = false
    var lastPlaying: Boolean? = null
    var shownUri = ""
    var viz: Visualizer? = null
    var ok = false
    val h = Handler(Looper.getMainLooper())
    /** icon / text colours follow the app theme (black on the light background, white on the dark one) */
    val fg: Int get() = pal.text
    val fg2: Int get() = ColorUtils.setAlphaComponent(pal.text, 0xCC)
    val fgBg: Int get() = ColorUtils.setAlphaComponent(pal.text, 0x1F)
    var volDrag = false
    var volStart = 0f
    lateinit var volPill: LinearLayout
    lateinit var volIcon: PathIcon
    lateinit var volBar: ProgressLine
    lateinit var volTxt: TextView
    val hideVol = Runnable { if (::volPill.isInitialized) volPill.visibility = View.GONE }

    fun showVol(f: Float) {
        val pct = Math.round(f * 100f)
        volTxt.text = "$pct%"
        volBar.frac = f
        volIcon.set(if (pct == 0) Ic.MUTE else Ic.VOL)
        volPill.visibility = View.VISIBLE
        h.removeCallbacks(hideVol)
        h.postDelayed(hideVol, 900)
    }
    val cb: () -> Unit = { runOnUiThread { refresh() } }

    val tick = object : Runnable {
        override fun run() {
            val p = AudioEngine.player
            if (p != null && !userSeeking) {
                val d = maxOf(p.duration, 0L)
                seek.max = d.toInt()
                seek.progress = p.currentPosition.toInt()
                curTxt.text = Media.time(p.currentPosition)
                durTxt.text = Media.time(d)
            }
            updateSleepUi()
            h.postDelayed(this, 300)
        }
    }

    fun lp(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)

    override fun onCreate(b: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(b)
        pal = Pal(pf.dark, pf.accent)
        if (AudioEngine.player == null || AudioEngine.queue.isEmpty()) { finish(); return }
        // a video playing in the background belongs to the video player, never to the music player
        if (AudioEngine.videoBg) { openVideoFromBg(); finish(); return }
        ok = true
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !pal.dark
            isAppearanceLightNavigationBars = !pal.dark
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.clipChildren = false
        root.clipToPadding = false
        root.setBackgroundColor(pal.bg)

        // ---- compact header: back, track title/artist, queue
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(10), dp(8), dp(10), dp(6))
        top.addView(iconBtn(Ic.BACK, fg) { finish() })
        top.addView(View(this), lp(0, 1, 1f))
        root.addView(top, lp(-1, -2))

        // ---- circular cover with radial spectrum
        val mid = FrameLayout(this)
        vinyl = CoverView(this)
        vinyl.accent = pal.accent
        vinyl.bar = fg
        mid.addView(vinyl, FrameLayout.LayoutParams(-1, -1))
        vizView = VisualizerView(this)
        vizView.visibility = View.GONE

        // Gestures on the artwork: vertical drag = music volume (smooth, follows the finger, 0-100%), horizontal swipe = track change.
        val artworkGestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean { volDrag = false; return true }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null) return false
                val ddx = e2.x - e1.x
                val ddy = e2.y - e1.y
                if (!volDrag) {
                    if (kotlin.math.abs(ddy) > dp(12) && kotlin.math.abs(ddy) > kotlin.math.abs(ddx) * 1.3f) {
                        volDrag = true
                        volStart = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxOf(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
                    } else return false
                }
                val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val f = (volStart - ddy / maxOf(1, mid.height) * 1.3f).coerceIn(0f, 1f)
                val target = Math.round(f * mx).coerceIn(0, mx)
                if (target != am.getStreamVolume(AudioManager.STREAM_MUSIC)) am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                showVol(f)
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null || volDrag) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                val ax = kotlin.math.abs(dx)
                val ay = kotlin.math.abs(dy)
                if (ax > dp(80) && ax > ay * 1.2f && kotlin.math.abs(velocityX) > dp(350)) {
                    val player = AudioEngine.player ?: return true
                    if (dx < 0) {
                        player.seekToNext()
                        toast("Next track")
                    } else {
                        player.seekToPrevious()
                        toast("Previous track")
                    }
                    return true
                }
                return false
            }
        })
        mid.setOnTouchListener { _, event ->
            val r = artworkGestures.onTouchEvent(event)
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) volDrag = false
            r
        }

        // volume pill: icon + thin bar + percentage
        volPill = LinearLayout(this)
        volPill.gravity = Gravity.CENTER_VERTICAL
        volPill.setPadding(dp(14), dp(9), dp(16), dp(9))
        volPill.background = rr(0xDD000000.toInt(), dpf(24))
        volPill.visibility = View.GONE
        volIcon = PathIcon(Ic.VOL, Color.WHITE)
        val volIv = ImageView(this)
        volIv.setImageDrawable(volIcon)
        volPill.addView(volIv, lp(dp(22), dp(22)).apply { marginEnd = dp(10) })
        volBar = ProgressLine(this, Color.WHITE, 0x44FFFFFF)
        volBar.roundClip(dpf(2))
        volPill.addView(volBar, lp(dp(110), dp(4)))
        volTxt = label("0%", 15f, Color.WHITE, true)
        volTxt.minWidth = dp(46)
        volTxt.gravity = Gravity.END
        volPill.addView(volTxt, lp(-2, -2).apply { marginStart = dp(10) })
        mid.addView(volPill, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(12) })

        root.addView(mid, lp(-1, 0, 1f))

        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        heading.setPadding(dp(24), dp(8), dp(24), dp(4))
        titleTxt = label("", 19f, fg, true)
        titleTxt.maxLines = 1
        titleTxt.ellipsize = TextUtils.TruncateAt.MARQUEE
        titleTxt.isSelected = true
        titleTxt.gravity = Gravity.CENTER
        artistTxt = label("", 13f, fg2)
        artistTxt.maxLines = 1
        artistTxt.gravity = Gravity.CENTER
        heading.addView(titleTxt, lp(-1, -2))
        heading.addView(artistTxt, lp(-1, -2))
        root.addView(heading, lp(-1, -2))

        // ---- utility row: favourite, sleep timer, more
        val tools = LinearLayout(this)
        tools.gravity = Gravity.CENTER
        tools.setPadding(dp(24), dp(2), dp(24), dp(2))
        fun toolCell(btn: ImageView): FrameLayout {
            val cell = FrameLayout(this)
            btn.background = LayerDrawable(arrayOf(rr(fgBg, dpf(26)), ripple(null, dpf(26))))
            cell.addView(btn, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
            return cell
        }
        val heart = iconBtn(Ic.HEART_O, fg, 52, 26) {}
        heartIc = heart.drawable as PathIcon
        heart.contentDescription = "Add to favourites"
        heart.setOnClickListener { toggleFav() }
        tools.addView(toolCell(heart), lp(0, dp(60), 1f))
        val sleepButton = iconBtn(Ic.TIMER, fg, 52, 26) { sleepTimerDialog() }
        sleepButton.contentDescription = "Sleep timer"
        sleepBtn = sleepButton
        val sleepCell = toolCell(sleepButton)
        // remaining time is written inside the timer button while a sleep timer runs
        sleepTxt = label("", 12f, fg, true)
        sleepTxt.gravity = Gravity.CENTER
        sleepTxt.maxLines = 1
        sleepTxt.visibility = View.GONE
        sleepTxt.isClickable = false
        sleepCell.addView(sleepTxt, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        tools.addView(sleepCell, lp(0, dp(60), 1f))
        val moreButton = iconBtn(Ic.MORE_H, fg, 52, 26) { moreSheet() }
        moreButton.contentDescription = "More options"
        tools.addView(toolCell(moreButton), lp(0, dp(60), 1f))
        root.addView(tools, lp(-1, -2))

        // ---- progress row
        val seekRow = LinearLayout(this)
        seekRow.gravity = Gravity.CENTER_VERTICAL
        seekRow.setPadding(dp(16), dp(2), dp(16), dp(2))
        curTxt = label("0:00", 13f, fg)
        seekRow.addView(curTxt, lp(-2, -2))
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(fg)
        seek.thumbTintList = ColorStateList.valueOf(fg)
        seek.progressBackgroundTintList = ColorStateList.valueOf(ColorUtils.setAlphaComponent(fg, 0x55))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) { if (u) { AudioEngine.player?.seekTo(v.toLong()); curTxt.text = Media.time(v.toLong()) } }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) { userSeeking = false }
        })
        seekRow.addView(seek, lp(0, dp(34), 1f))
        durTxt = label("0:00", 13f, fg)
        seekRow.addView(durTxt, lp(-2, -2))
        root.addView(seekRow, lp(-1, -2))

        // ---- fixed-height transport controls; fixed cells prevent icons collapsing on narrow screens.
        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER_VERTICAL
        ctl.weightSum = 5f
        ctl.setPadding(dp(8), dp(4), dp(8), dp(10))
        ctl.minimumHeight = dp(88)
        ctl.setBackgroundColor(Color.TRANSPARENT)
        ctl.clipChildren = false
        ctl.clipToPadding = false

        fun transportCell(path: String, description: String, action: () -> Unit): FrameLayout {
            val cell = FrameLayout(this)
            cell.isClickable = true
            cell.isFocusable = true
            cell.contentDescription = description
            cell.background = ripple(null, dpf(36))
            val iv = ImageView(this)
            iv.setImageDrawable(PathIcon(path, fg))
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            cell.addView(iv, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            cell.setOnClickListener { action() }
            return cell
        }

        modeCell = FrameLayout(this).apply {
            isClickable = true; isFocusable = true
            contentDescription = "Playback mode: Play in order"
            background = ripple(null, dpf(36))
        }
        shufIc = PathIcon(Ic.ORDER, fg2)
        val repeatIv = ImageView(this).apply {
            setImageDrawable(shufIc); scaleType = ImageView.ScaleType.FIT_CENTER
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        modeCell.addView(repeatIv, FrameLayout.LayoutParams(dp(27), dp(27), Gravity.CENTER))
        modeCell.setOnClickListener { cyclePlaybackMode() }
        ctl.addView(modeCell, lp(0, dp(72), 1f))

        ctl.addView(transportCell(Ic.PREV, "Previous track") {
            AudioEngine.player?.seekToPrevious()
        }, lp(0, dp(72), 1f))

        val playCell = FrameLayout(this)
        playCell.isClickable = true
        playCell.isFocusable = true
        playCell.contentDescription = "Play or pause"
        playCell.background = ripple(null, dpf(40))
        val ring = FrameLayout(this)
        playIc = PathIcon(Ic.PAUSE, fg)
        val piv = ImageView(this)
        piv.setImageDrawable(playIc)
        piv.scaleType = ImageView.ScaleType.FIT_CENTER
        ring.addView(piv, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        playCell.addView(ring, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        playCell.setOnClickListener { AudioEngine.toggle() }
        ctl.addView(playCell, lp(0, dp(80), 1f))

        ctl.addView(transportCell(Ic.NEXT, "Next track") {
            AudioEngine.player?.seekToNext()
        }, lp(0, dp(72), 1f))
        ctl.addView(transportCell(Ic.QUEUE, "Playing queue") { queueSheet() }, lp(0, dp(72), 1f))
        root.addView(ctl, lp(-1, dp(88)))
        setContentView(root)

        AudioEngine.stopAfterCurrent = AudioEngine.player?.pauseAtEndOfMediaItems == true
        AudioEngine.listeners.add(cb)
        refresh()
        h.post(tick)
        setViz(true)
    }

    fun updateSleepUi() {
        if (!::sleepTxt.isInitialized) return
        val left = AudioEngine.sleepLeft
        if (AudioEngine.sleepEnd != 0L && left > 0L) {
            sleepTxt.text = fmtRemain(left)
            sleepTxt.visibility = View.VISIBLE
            (sleepBtn.drawable as? PathIcon)?.tint(0x00FFFFFF)
            sleepBtn.background = LayerDrawable(arrayOf(rr(pal.accent and 0x00FFFFFF or 0x88000000.toInt(), dpf(26)), ripple(null, dpf(26))))
        } else if (sleepTxt.visibility == View.VISIBLE) {
            sleepTxt.visibility = View.GONE
            (sleepBtn.drawable as? PathIcon)?.tint(fg)
            sleepBtn.background = LayerDrawable(arrayOf(rr(fgBg, dpf(26)), ripple(null, dpf(26))))
        }
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); refresh() }

    fun refresh() {
        val p = AudioEngine.player ?: return
        val t = AudioEngine.current
        if (t == null) { finish(); return }
        titleTxt.text = t.title
        artistTxt.text = t.shownArtist
        playIc.set(if (p.isPlaying) Ic.PAUSE else Ic.PLAY)
        vinyl.playing = p.isPlaying
                heartIc.set(if (isFav(t)) Ic.HEART else Ic.HEART_O)
        heartIc.tint(if (isFav(t)) 0xFFFF5252.toInt() else fg)
        updatePlaybackModeIcon()
        val key = t.uri + "|" + t.id
        if (key != shownUri) {
            shownUri = key
            Thread {
                val bm = Art.load(this, t.uri, t.id, 600)
                runOnUiThread { if (shownUri == key) vinyl.art = bm }
            }.start()
        }
    }

    private fun cyclePlaybackMode() {
        AudioEngine.cycleMode()
        updatePlaybackModeIcon()
        toast(AudioEngine.modeLabels[AudioEngine.modeIndex()])
    }

    private fun updatePlaybackModeIcon() {
        val mode = AudioEngine.modeIndex()
        shufIc.set(AudioEngine.modePath(mode))
        shufIc.tint(if (mode == 0) fg2 else pal.bright)
        if (::modeCell.isInitialized) modeCell.contentDescription = "Playback mode: " + AudioEngine.modeLabels[mode]
    }

    // ---------------------------------------------------------------- favourites
    fun favKey(t: Track) = "a" + t.id
    fun isFav(t: Track) = t.id > 0 && favKey(t) in pf.strs("fav")
    fun toggleFav() {
        val t = AudioEngine.current ?: return
        if (t.id <= 0) { toast("Cannot add this file"); return }
        val s = pf.strs("fav")
        val key = favKey(t)
        if (!s.add(key)) {
            s.remove(key)
            pf.putStrs("fav", s)
            if ("Favourites" in pf.plNames(false)) pf.plRemoveItem("Favourites", key, false)
        } else {
            pf.putStrs("fav", s)
            pf.plCreate("Favourites", listOf(key), false)
        }
        refresh()
    }

    // ---------------------------------------------------------------- visualizer
    fun setViz(on: Boolean) {
        if (!on) { stopViz(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5)
            return
        }
        startViz()
    }

    fun startViz() {
        stopViz()
        val p = AudioEngine.player ?: return
        val sid = p.audioSessionId
        if (sid == 0) return
        try {
            val v = Visualizer(sid)
            v.captureSize = Visualizer.getCaptureSizeRange()[1]
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, rate: Int) { if (fft != null) vinyl.feed(fft) }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.enabled = true
            viz = v
        } catch (e: Exception) {
            // no live spectrum on this device: the cover ring falls back to its built-in animation
        }
    }

    fun stopViz() {
        try { viz?.enabled = false } catch (e: Exception) {}
        try { viz?.release() } catch (e: Exception) {}
        viz = null
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 5) {
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) startViz()
            else toast("Allow microphone/audio permission for the live music animation")
        }
    }

    // ---------------------------------------------------------------- sheets / dialogs
    fun queueSheet() {
        val q = AudioEngine.queue
        if (q.isEmpty()) return
        val entries = q.mapIndexed { i, t -> QueueEntry("$i|${t.uri}", t.title) }
        QueueSheet.show(this, "Playing Queue", entries, pal.accent, showMode = true,
            currentKey = "${AudioEngine.player?.currentMediaItemIndex ?: -1}|${AudioEngine.current?.uri ?: ""}",
            onSelect = { e ->
                val uri = e.key.substringAfter("|")
                val i = AudioEngine.queue.indexOfFirst { it.uri == uri }
                if (i >= 0) { AudioEngine.player?.seekTo(i, 0L); AudioEngine.player?.play() }
            },
            onChange = { changed ->
                val tracks = changed.mapNotNull { e ->
                    val i = e.key.substringBefore("|").toIntOrNull()
                    i?.let { q.getOrNull(it) }
                }
                AudioEngine.reorderQueue(this, tracks)
            })
    }

    fun moreSheet() {
        val t = AudioEngine.current ?: return
        val d = BottomSheetDialog(this)
        val r = dpf(28)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(pal.surface)
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        col.setPadding(0, 0, 0, dp(24))
        val bar = View(this)
        bar.background = rr(pal.line, dpf(2))
        col.addView(bar, lp(dp(40), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(10); bottomMargin = dp(14) })
        val hr = LinearLayout(this)
        hr.gravity = Gravity.CENTER_VERTICAL
        hr.setPadding(dp(20), 0, dp(20), dp(14))
        val art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rr(pal.tile, dpf(10))
        art.roundClip(dpf(10))
        Thread { val bm = Art.load(this, t.uri, t.id, 200); runOnUiThread { if (bm != null) art.setImageBitmap(bm) } }.start()
        hr.addView(art, lp(dp(48), dp(48)).apply { marginEnd = dp(16) })
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        val t1 = label(t.title, 19f, pal.text, true)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        tc.addView(t1)
        tc.addView(label(t.shownArtist, 14f, pal.sub))
        hr.addView(tc, lp(0, -2, 1f))
        col.addView(hr)
        val dv = View(this)
        dv.setBackgroundColor(pal.line)
        col.addView(dv, lp(-1, dp(1)).apply { marginStart = dp(20); marginEnd = dp(20) })

        fun row(icon: String, text: String, trail: View?, click: () -> Unit) {
            val rw = LinearLayout(this)
            rw.gravity = Gravity.CENTER_VERTICAL
            rw.minimumHeight = dp(56)
            rw.setPadding(dp(20), dp(6), dp(20), dp(6))
            rw.background = ripple(null, 0f)
            val circ = FrameLayout(this)
            circ.background = rr(pal.tile, dpf(22))
            val iv = ImageView(this)
            iv.setImageDrawable(PathIcon(icon, pal.text))
            circ.addView(iv, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            rw.addView(circ, lp(dp(44), dp(44)).apply { marginEnd = dp(20) })
            rw.addView(label(text, 17f, pal.text), lp(0, -2, 1f))
            if (trail != null) rw.addView(trail)
            rw.setOnClickListener { click() }
            col.addView(rw, lp(-1, -2))
        }
        row(Ic.SPEED, "Speed", null) { d.dismiss(); speedDlg() }
        row(Ic.EQ, "Equalizer", null) { d.dismiss(); eqDialog() }
        row(Ic.CUT, "Cut", null) { d.dismiss(); cutCur(t) }
        row(Ic.SHARE, "Send", null) { d.dismiss(); sendCur(t) }
        row(Ic.TIMER, "Timer", null) { d.dismiss(); timerDialog() }
        row(Ic.EDIT, "Edit tag", null) { d.dismiss(); editTag(t) }
        row(Ic.MUSIC, "Set as ringtone", null) { d.dismiss(); ringtone(t) }
        row(Ic.DETAILS, "Details", null) { d.dismiss(); details(t) }

        val sv = android.widget.ScrollView(this)
        sv.addView(col)
        d.setContentView(sv)
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
            d.behavior.skipCollapsed = true
            d.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        }
        d.show()
    }

    fun cutCur(t: Track) {
        val p = AudioEngine.player
        startActivity(
            Intent(this, CutterActivity::class.java).putExtra("uri", t.uri).putExtra("name", t.title + ".mp3")
                .putExtra("dur", maxOf(p?.duration ?: 0L, 0L)).putExtra("size", 0L).putExtra("audio", true)
        )
    }

    fun sendCur(t: Track) {
        val u = Uri.parse(t.uri)
        val i = Intent(Intent.ACTION_SEND).setType("audio/*").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Send"))
    }

    fun timerDialog() {
        sleepTimerDialog()
    }

    fun editTag(t: Track) {
        if (t.id <= 0) { toast("Cannot edit this file"); return }
        startActivity(
            Intent(this, TagEditActivity::class.java).putExtra("id", t.id).putExtra("uri", t.uri)
                .putExtra("title", t.title).putExtra("artist", t.artist).putExtra("album", t.album)
                .putExtra("genre", pf.tag(t.id, "genre"))
        )
    }

    fun ringtone(t: Track) {
        if (!Settings.System.canWrite(this)) {
            toast("Allow \"Modify system settings\" for Sajid Player")
            try { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).setData(Uri.parse("package:$packageName"))) } catch (e: Exception) {}
            return
        }
        try {
            RingtoneManager.setActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE, Uri.parse(t.uri))
            toast("Ringtone set")
        } catch (e: Exception) {
            toast("Cannot set ringtone")
        }
    }

    fun details(t: Track) {
        val p = AudioEngine.player
        message(t.title, "Artist: ${t.shownArtist}\nAlbum: ${if (t.album.isEmpty()) "<unknown>" else t.album}\nDuration: ${Media.time(maxOf(p?.duration ?: 0L, 0L))}\n${t.uri}")
    }

    fun speedDlg() {
        val p = AudioEngine.player ?: return
        speedPanel(p.playbackParameters.speed) { v -> p.setPlaybackSpeed(v); pf.curSpeedA = v }
    }

    fun eqDialog() {
        val p = AudioEngine.player ?: return
        eqPanel(AudioEngine.eq, AudioEngine.extras, p.audioSessionId, pf)
    }

    // ---------------------------------------------------------------- delete
    fun deleteCur() {
        val t = AudioEngine.current ?: return
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this).setTitle("Delete this song?")
            .setMessage(t.title + "\n\nIt will be deleted permanently.")
            .setPositiveButton("Delete") { _, _ -> deleteCurNow() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun deleteCurNow() {
        val t = AudioEngine.current ?: return
        val u = Uri.parse(t.uri)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startIntentSenderForResult(MediaStore.createDeleteRequest(contentResolver, listOf(u)).intentSender, 7, null, 0, 0, 0)
            } else {
                contentResolver.delete(u, null, null)
                afterDelete()
            }
        } catch (e: Exception) {
            toast("Cannot delete: ${e.message}")
        }
    }

    fun afterDelete() {
        AudioEngine.removeCurrent(this)
        if (AudioEngine.queue.isEmpty()) finish()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 7 && res == RESULT_OK) afterDelete()
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
        AudioEngine.listeners.remove(cb)
        stopViz()
    }
}
