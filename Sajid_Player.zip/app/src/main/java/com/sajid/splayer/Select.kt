package com.sajid.splayer

import android.content.ContentValues
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object Ic2 {
    const val COPY = "M16,1H4C2.9,1 2,1.9 2,3v14h2V3h12V1zM19,5H8C6.9,5 6,5.9 6,7v14c0,1.1 0.9,2 2,2h11c1.1,0 2,-0.9 2,-2V7C21,5.9 20.1,5 19,5zM19,21H8V7h11V21z"
    const val MOVE = "M20,6h-8l-2,-2H4c-1.1,0 -1.99,0.9 -1.99,2L2,18c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V8c0,-1.1 -0.9,-2 -2,-2zM12,17v-3H8v-2h4V9l4,4 -4,4z"
}

// ================================================================== selection mode (folders + files together)

fun MainActivity.selFiles(): List<Item> = sel.values.flatten().distinctBy { it.key }

fun MainActivity.refreshSelUi() {
    buildBar()
    buildSelBar()
    (lvRef?.adapter as? BaseAdapter)?.notifyDataSetChanged()
}

fun MainActivity.toggleSel(key: String, items: List<Item>) {
    if (key in sel) sel.remove(key) else sel[key] = items
    selMode = sel.isNotEmpty()
    refreshSelUi()
}

fun MainActivity.exitSel() {
    selMode = false
    sel.clear()
    refreshSelUi()
}

fun MainActivity.selectAllRows() {
    for (r in curRows) { val k = r.selKey; if (k != null) sel[k] = r.selItems }
    selMode = sel.isNotEmpty()
    refreshSelUi()
}

fun MainActivity.selTopBar(): View {
    val bar = LinearLayout(this)
    bar.gravity = Gravity.CENTER_VERTICAL
    bar.setPadding(dp(8), dp(10), dp(8), dp(6))
    bar.addView(iconBtn(Ic.CLOSE, pal.text) { exitSel() })
    val n = selFiles().size
    val t = label("${sel.size} selected", 19f, pal.text, true)
    t.setPadding(dp(8), 0, 0, 0)
    bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
    if (n > 0) bar.addView(label("$n ${wordOf(n)}", 13f, pal.sub).also { it.setPadding(0, 0, dp(8), 0) })
    val all = iconBtn(Ic.CHECK, pal.accent) { selectAllRows() }
    all.contentDescription = "Select all"
    bar.addView(all)
    return bar
}

private fun MainActivity.selAct(icon: String, text: String, tint: Int, click: () -> Unit): View {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.gravity = Gravity.CENTER
    c.background = ripple(null, dpf(14))
    val ic = ImageView(this)
    ic.setImageDrawable(PathIcon(icon, tint))
    c.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
    val tv = label(text, 10.5f, tint)
    tv.maxLines = 1
    tv.gravity = Gravity.CENTER
    c.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(3) })
    c.setOnClickListener { click() }
    return c
}

fun MainActivity.buildSelBar() {
    selHost.removeAllViews()
    if (!selMode) return
    val bar = LinearLayout(this)
    bar.setPadding(dp(6), dp(8), dp(6), dp(8))
    bar.background = rr(pal.surface, dpf(22), dp(1), pal.line)
    bar.elevation = dpf(10)
    val danger = 0xFFEF5350.toInt()
    fun add(icon: String, text: String, tint: Int, f: () -> Unit) =
        bar.addView(selAct(icon, text, tint, f), LinearLayout.LayoutParams(0, dp(52), 1f))
    add(Ic.DELETE, "Delete", danger) { selDelete() }
    add(Ic2.MOVE, "Move", pal.text) { selDest(true) }
    add(Ic.QUEUE, "Queue", pal.text) { selQueue() }
    if (showLocked) add(Ic.UNLOCK, "Unhide", pal.text) { selUnhide() }
    else add(Ic.LOCK, "Hide", pal.text) { selHide() }
    if (!video) add(Ic.EDIT, "Tags", pal.text) { selTags() }
    val more = selAct(Ic.MORE, "More", pal.text) {}
    more.setOnClickListener {
        val pm = android.widget.PopupMenu(this, more)
        pm.menu.add(0, 1, 0, "Copy")
        pm.menu.add(0, 2, 1, "Send")
        pm.menu.add(0, 3, 2, "Add to playlist")
        pm.setOnMenuItemClickListener {
            when (it.itemId) { 1 -> selDest(false); 2 -> selSend(); 3 -> selPlaylist() }
            true
        }
        pm.show()
    }
    bar.addView(more, LinearLayout.LayoutParams(0, dp(52), 1f))
    selHost.addView(bar, FrameLayout.LayoutParams(-1, -2).apply { setMargins(dp(8), dp(4), dp(8), dp(6)) })
}

private fun MainActivity.realFiles(): List<Item> {
    val l = selFiles().filter { !it.vault }
    if (l.isEmpty()) toast("Not available for hidden files")
    return l
}

fun MainActivity.selDelete() {
    val l = selFiles()
    if (l.isEmpty()) { toast("No files in the selection"); return }
    MaterialAlertDialogBuilder(this).setTitle("Delete ${l.size} ${wordOf(l.size)}?")
        .setMessage("The selected folders' files and the selected files will be deleted.")
        .setPositiveButton("Delete") { _, _ -> exitSel(); deleteItems(l, true) }
        .setNegativeButton("Cancel", null).show()
}

fun MainActivity.selSend() {
    val l = realFiles()
    if (l.isNotEmpty()) sendItems(l)
}

fun MainActivity.selPlaylist() {
    val l = realFiles()
    if (l.isNotEmpty()) { addPl(l); exitSel() }
}

fun MainActivity.selQueue() {
    val l = realFiles()
    if (l.isEmpty()) return
    if (video) {
        val q = pf.lastQ.toMutableList()
        val qn = pf.lastQN.toMutableList()
        if (qn.size != q.size) { q.clear(); qn.clear() }
        var added = 0
        for (x in l) { val u = x.uri.toString(); if (u !in q) { q.add(u); qn.add(x.name); added++ } }
        pf.lastQ = q
        pf.lastQN = qn
        if (pf.lastUri.isEmpty() && q.isNotEmpty()) { pf.lastUri = q[0]; pf.lastName = qn[0] }
        toast("$added added to the video queue")
        refreshMini()
    } else {
        AudioEngine.addToQueue(this, l.map { it.toTrack() })
        toast("${l.size} added to the playing queue")
    }
    exitSel()
}

fun MainActivity.selTags() {
    val l = selFiles().filter { !it.video && it.id > 0 }
    when {
        l.isEmpty() -> toast("Select music files to edit tags")
        l.size == 1 -> { tagEdit(l[0]); }
        else -> tagEditAll("${l.size} tracks", l)
    }
}

// ------------------------------------------------------------------ copy / move

fun MainActivity.selDest(move: Boolean) {
    val l = realFiles()
    if (l.isEmpty()) return
    // every folder that the player shows in its folder list (not only Movies / Music)
    val rels = all.filter { !it.vault && it.rel.isNotEmpty() }.map { it.rel }.distinct().sortedBy { it.lowercase() }
    val labels = listOf("+  New folder", "📁  Any other folder on the phone…") + rels.map { it.trimEnd('/') }
    val base = if (video) "Movies/" else "Music/"
    choose(if (move) "Move ${l.size} ${wordOf(l.size)} to" else "Copy ${l.size} ${wordOf(l.size)} to", labels, -1) { i ->
        if (i == 0) {
            ask("New folder", "Folder name", "") { nm ->
                val n = nm.trim().trim('/').replace("\\", "/")
                if (n.isEmpty()) { toast("Enter a folder name"); return@ask }
                copyItems(l, base + n + "/", move)
            }
        } else if (i == 1) {
            // the system folder picker: every folder of the phone (WhatsApp, Download/xyz, SD card, ...)
            treeItems = l
            treeMove = move
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), MainActivity.RC_TREE)
            } catch (e: Exception) { toast("Folder picker not available") }
        } else copyItems(l, rels[i - 2], move)
    }
}

/** Progress window for Copy / Move: percentage bar, Hide (keeps running in the background) and Cancel. */
class CopyProgress(private val a: MainActivity, title: String, private val total: Int) {
    @Volatile var cancelled = false
    private var dlg: androidx.appcompat.app.AlertDialog? = null
    private var msg: TextView? = null
    private var bar: android.widget.ProgressBar? = null
    private var lastUi = 0L

    init {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(a.dp(24), a.dp(16), a.dp(24), a.dp(4))
        val m = a.label("0 / $total  •  0%", 16f, a.pal.text, true)
        val pb = android.widget.ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        pb.progressTintList = android.content.res.ColorStateList.valueOf(a.pal.accent)
        val hint = a.label("Tap Hide to keep using the app. It continues in the background.", 13f, a.pal.sub)
        hint.setPadding(0, a.dp(12), 0, 0)
        box.addView(m)
        box.addView(pb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.dp(12) })
        box.addView(hint)
        msg = m; bar = pb
        dlg = MaterialAlertDialogBuilder(a).setTitle(title).setView(box).setCancelable(false)
            .setPositiveButton("Hide") { _, _ -> dlg = null; msg = null; bar = null }
            .setNegativeButton("Cancel") { _, _ -> cancelled = true; dlg = null; msg = null; bar = null; a.toast("Cancelling…") }
            .show()
    }

    /** any thread; the window is refreshed at most ~6 times a second */
    fun update(n: Int, pct: Int, force: Boolean = false) {
        val now = android.os.SystemClock.uptimeMillis()
        if (!force && now - lastUi < 150L) return
        lastUi = now
        a.runOnUiThread {
            msg?.text = "$n / $total  •  $pct%"
            bar?.progress = pct
        }
    }

    fun close() { a.runOnUiThread { try { dlg?.dismiss() } catch (e: Exception) {}; dlg = null; msg = null; bar = null } }
}

private class CancelCopy : Exception()

fun MainActivity.copyItems(items: List<Item>, rel: String, move: Boolean) {
    val todo = items.filter { it.rel != rel }
    if (todo.isEmpty()) { toast("Already in that folder"); return }
    val cp = CopyProgress(this, if (move) "Moving…" else "Copying…", todo.size)
    val vid = video
    Thread {
        val okPre = if (vid) listOf("DCIM/", "Movies/", "Pictures/")
        else listOf("Music/", "Podcasts/", "Ringtones/", "Alarms/", "Notifications/", "Audiobooks/", "Recordings/")
        // MediaStore only accepts some top folders per type; Download/... goes through the Downloads collection
        val coll = if (okPre.none { rel.startsWith(it) } && rel.startsWith("Download"))
            MediaStore.Downloads.EXTERNAL_CONTENT_URI
        else if (vid) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val totalBytes = maxOf(1L, todo.fold(0L) { acc, it -> acc + maxOf(it.size, 1L) })
        var doneBytes = 0L
        val done = ArrayList<Item>()
        var failed = 0
        var stopped = false
        for ((n, x) in todo.withIndex()) {
            if (cp.cancelled) { stopped = true; break }
            var dst: android.net.Uri? = null
            try {
                val ext = x.name.substringAfterLast('.', "").lowercase()
                val mime = x.mime.ifEmpty { android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: (if (vid) "video/mp4" else "audio/mpeg") }
                val cv = ContentValues()
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, x.name)
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
                val d = contentResolver.insert(coll, cv)
                dst = d
                if (d == null) { failed++; doneBytes += maxOf(x.size, 1L); continue }
                contentResolver.openInputStream(x.uri)!!.use { i ->
                    contentResolver.openOutputStream(d)!!.use { o ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            if (cp.cancelled) throw CancelCopy()
                            val r = i.read(buf)
                            if (r < 0) break
                            o.write(buf, 0, r)
                            doneBytes += r
                            cp.update(n, (doneBytes * 100 / totalBytes).toInt().coerceIn(0, 100))
                        }
                    }
                }
                val cv2 = ContentValues()
                cv2.put(MediaStore.MediaColumns.IS_PENDING, 0)
                contentResolver.update(d, cv2, null, null)
                if (!vid) {
                    val nid = ContentUris.parseId(d)
                    for (k in listOf("title", "artist", "album", "genre", "year", "track", "comment")) {
                        val v = pf.tag(x.id, k)
                        if (v.isNotEmpty()) pf.setTag(nid, k, v)
                    }
                }
                done.add(x)
            } catch (e: CancelCopy) {
                try { dst?.let { contentResolver.delete(it, null, null) } } catch (e2: Exception) {}
                stopped = true
                break
            } catch (e: Exception) {
                failed++
                try { dst?.let { contentResolver.delete(it, null, null) } } catch (e2: Exception) {}
            }
            cp.update(n + 1, (doneBytes * 100 / totalBytes).toInt().coerceIn(0, 100), true)
        }
        cp.close()
        runOnUiThread {
            val verb = if (move) "Moved" else "Copied (originals kept)"
            toast(
                if (stopped) "Cancelled • $verb ${done.size} ${wordOf(done.size)}"
                else if (failed == 0) "$verb ${done.size} ${wordOf(done.size)}" else "$verb ${done.size}, $failed failed"
            )
            exitSel()
            if (move && done.isNotEmpty()) deleteMoved(done) else load()
        }
    }.start()
}

/** Copy / move into any folder picked with the system folder picker (works for every folder of the phone). */
fun MainActivity.copyToTree(items: List<Item>, tree: android.net.Uri, move: Boolean) {
    if (items.isEmpty()) return
    val cp = CopyProgress(this, if (move) "Moving…" else "Copying…", items.size)
    val vid = video
    Thread {
        val resolver = contentResolver
        val totalBytes = maxOf(1L, items.fold(0L) { acc, it -> acc + maxOf(it.size, 1L) })
        var doneBytes = 0L
        val done = ArrayList<Item>()
        var failed = 0
        var stopped = false
        val parent = try {
            android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, android.provider.DocumentsContract.getTreeDocumentId(tree))
        } catch (e: Exception) { null }
        for ((n, x) in items.withIndex()) {
            if (cp.cancelled) { stopped = true; break }
            var dst: android.net.Uri? = null
            try {
                if (parent == null) { failed++; continue }
                val ext = x.name.substringAfterLast('.', "").lowercase()
                val mime = x.mime.ifEmpty { android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: (if (vid) "video/mp4" else "audio/mpeg") }
                val d = android.provider.DocumentsContract.createDocument(resolver, parent, mime, x.name)
                dst = d
                if (d == null) { failed++; continue }
                resolver.openInputStream(x.uri)!!.use { i ->
                    resolver.openOutputStream(d)!!.use { o ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            if (cp.cancelled) throw CancelCopy()
                            val r = i.read(buf)
                            if (r < 0) break
                            o.write(buf, 0, r)
                            doneBytes += r
                            cp.update(n, (doneBytes * 100 / totalBytes).toInt().coerceIn(0, 100))
                        }
                    }
                }
                done.add(x)
            } catch (e: CancelCopy) {
                try { dst?.let { android.provider.DocumentsContract.deleteDocument(resolver, it) } } catch (e2: Exception) {}
                stopped = true
                break
            } catch (e: Exception) {
                failed++
                try { dst?.let { android.provider.DocumentsContract.deleteDocument(resolver, it) } } catch (e2: Exception) {}
            }
            cp.update(n + 1, (doneBytes * 100 / totalBytes).toInt().coerceIn(0, 100), true)
        }
        cp.close()
        runOnUiThread {
            val verb = if (move) "Moved" else "Copied (originals kept)"
            toast(
                if (stopped) "Cancelled • $verb ${done.size} ${wordOf(done.size)}"
                else if (failed == 0) "$verb ${done.size} ${wordOf(done.size)}" else "$verb ${done.size}, $failed failed"
            )
            exitSel()
            if (move && done.isNotEmpty()) deleteMoved(done) else load()
        }
    }.start()
}

// ================================================================== premium mini player (music + video, every folder)

fun MainActivity.openLastVideo() {
    val u = pf.lastUri
    if (u.isEmpty()) return
    val q = pf.lastQ
    val qn = pf.lastQN
    val ix = q.indexOf(u)
    val us = if (ix >= 0) q else listOf(u)
    val ns = if (ix >= 0 && qn.size == q.size) qn else listOf(pf.lastName)
    startActivity(
        Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra("u", ArrayList(us))
            .putStringArrayListExtra("n", ArrayList(ns))
            .putExtra("i", maxOf(ix, 0)).putExtra("v", true)
    )
}

/** Compact mini player (music + video): plain black (dark) / white (light) card, cover - name - queue - play/pause (icon only) - close, thin progress line. */
fun MainActivity.premiumBar(
    title: String, sub: String, playing: Boolean, withProgress: Boolean,
    loadArt: (ImageView) -> Unit, onOpen: () -> Unit, onQueue: () -> Unit, onToggle: () -> Unit, onClose: () -> Unit,
    isMusic: Boolean = withProgress, staticFrac: Float = -1f, subOut: ((TextView) -> Unit)? = null
): View {
    val bgc = if (pal.dark) Color.BLACK else Color.WHITE
    val fg = if (pal.dark) Color.WHITE else Color.BLACK
    val fg2 = if (pal.dark) 0xFFB5B5B5.toInt() else 0xFF666666.toInt()
    val outer = FrameLayout(this)
    outer.setPadding(dp(8), dp(3), dp(8), dp(6))
    val card = FrameLayout(this)
    card.background = rr(bgc, dpf(16), dp(1), if (pal.dark) 0xFF2E2E2E.toInt() else 0xFFD6D6D6.toInt())
    card.roundClip(dpf(16))
    card.elevation = dpf(6)

    val row = LinearLayout(this)
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(8), dp(6), dp(2), dp(8))
    val art = ImageView(this)
    art.scaleType = ImageView.ScaleType.CENTER_CROP
    art.background = rr(if (pal.dark) 0xFF222222.toInt() else 0xFFEEEEEE.toInt(), dpf(10))
    art.roundClip(dpf(10))
    art.setImageDrawable(PathIcon(if (isMusic) Ic.MUSIC else Ic.MOVIE, fg2).also { art.setPadding(dp(9), dp(9), dp(9), dp(9)) })
    row.addView(art, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) })
    loadArt(art)
    val tc = LinearLayout(this)
    tc.orientation = LinearLayout.VERTICAL
    val t1 = label(title, 14f, fg, true)
    t1.maxLines = 1
    t1.ellipsize = android.text.TextUtils.TruncateAt.END
    val t2 = label(sub, 11.5f, fg2)
    t2.maxLines = 1
    t2.ellipsize = android.text.TextUtils.TruncateAt.END
    subOut?.invoke(t2)
    tc.addView(t1)
    tc.addView(t2)
    row.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
    row.addView(iconBtn(Ic.QUEUE, fg, 36, 20) { onQueue() })
    // play / pause: icon only, no background circle
    row.addView(iconBtn(if (playing) Ic.PAUSE else Ic.PLAY, fg, 40, 26) { onToggle() })
    row.addView(iconBtn(Ic.CLOSE, fg2, 34, 18) { onClose() })
    tc.setOnClickListener { onOpen() }
    art.setOnClickListener { onOpen() }
    card.addView(row, FrameLayout.LayoutParams(-1, -2))
    if (withProgress || staticFrac >= 0f) {
        val ln = ProgressLine(this, fg)
        if (withProgress) miniLine = ln else ln.frac = staticFrac
        card.addView(ln, FrameLayout.LayoutParams(-1, dp(2), Gravity.BOTTOM))
    }
    outer.addView(card, FrameLayout.LayoutParams(-1, -2))
    return outer
}

fun MainActivity.refreshMini() {
    if (!miniReady()) return
    miniHost.removeCallbacks(miniTickR)
    miniHost.removeAllViews()
    miniLine = null
    if (searching || page != 0 || !permOk) return
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    // video (continue watching) mini player goes on TOP, music mini player stays at the BOTTOM
    val t = AudioEngine.current
    val vbg = t != null && t.id < 0L          // a video playing in the background stays in the VIDEO mini player
    miniSubV = null
    if (vbg && t != null && !showLocked) {
        val u = t.uri
        val vbar = premiumBar(
            t.title, "Playing in background", AudioEngine.player?.isPlaying == true, true,
            { art ->
                Thread {
                    try {
                        val bm = Art.load(this, u, -1L, 200)
                        if (bm != null) runOnUiThread { art.setPadding(0, 0, 0, 0); art.setImageBitmap(bm) }
                    } catch (e: Exception) {}
                }.start()
            },
            { openVideoFromBg() }, { videoQueue() }, { AudioEngine.toggle() },
            { AudioEngine.stop(this); refreshMini() },
            isMusic = false, subOut = { miniSubV = it }
        )
        box.addView(vbar, LinearLayout.LayoutParams(-1, -2))
        miniHost.post(miniTickR)
    } else if (video && pf.showLast && pf.lastUri.isNotEmpty() && !showLocked) {
        val u = pf.lastUri
        val saved = pf.sp.getLong("pos_$u", 0L)
        val dur = pf.sp.getLong("dur_$u", 0L)
        val frac = if (saved > 0L && dur > 0L) (saved.toFloat() / dur).coerceIn(0f, 1f) else 0f
        val vbar = premiumBar(
            pf.lastName.substringBeforeLast('.'), if (saved > 0L) "Resume from " + Media.time(saved) else "Continue watching", false, false,
            { art ->
                Thread {
                    try {
                        val bm = Art.load(this, u, -1L, 200)
                        if (bm != null) runOnUiThread { art.setPadding(0, 0, 0, 0); art.setImageBitmap(bm) }
                    } catch (e: Exception) {}
                }.start()
            },
            { openLastVideo() }, { videoQueue() }, { openLastVideo() },
            { pf.lastUri = ""; refreshMini() },
            isMusic = false, staticFrac = frac
        )
        box.addView(vbar, LinearLayout.LayoutParams(-1, -2))
    }
    if (t != null && !vbg) {
        val bar = premiumBar(
            t.title, t.shownArtist, AudioEngine.player?.isPlaying == true, true,
            { art ->
                val cached = cache.get("a" + t.id)
                if (cached != null) art.setImageBitmap(cached)
                else Thread {
                    val bm = Art.load(this, t.uri, t.id, 200)
                    if (bm != null) runOnUiThread { art.setPadding(0, 0, 0, 0); art.setImageBitmap(bm) }
                }.start()
            },
            { startActivity(Intent(this, AudioPlayerActivity::class.java)) },
            { miniQueue() },
            { AudioEngine.toggle() },
            { AudioEngine.stop(this) },
            isMusic = true
        )
        box.addView(bar, LinearLayout.LayoutParams(-1, -2))
        miniHost.post(miniTickR)
    }
    if (box.childCount > 0) miniHost.addView(box, FrameLayout.LayoutParams(-1, -2))
}


/** Hide the selected videos / audio / folders (a "." is put in front of each name; a folder is renamed as a whole). */
fun MainActivity.selHide() {
    val folderFiles = sel.filter { it.key.startsWith("f:") }.values.flatten().distinctBy { it.key }.filter { !it.vault }
    val folderKeys = folderFiles.map { it.key }.toSet()
    val loose = sel.filter { !it.key.startsWith("f:") }.values.flatten().distinctBy { it.key }.filter { !it.vault && it.key !in folderKeys }
    if (folderFiles.isEmpty() && loose.isEmpty()) { toast("Already hidden"); return }
    ensurePin {
        ensureAccess {
            val n = folderFiles.size + loose.size
            val onlyFolders = loose.isEmpty()
            val what = if (onlyFolders) (if (sel.size == 1) "folder" else "folders") else if (video) "video" else "audio"
            MaterialAlertDialogBuilder(this).setTitle(if (n == 1 || (onlyFolders && sel.size == 1)) "Are you sure you want to hide this $what?" else "Are you sure you want to hide these ${if (onlyFolders) sel.size else n} ${if (onlyFolders) what else wordOf(n)}?")
                .setPositiveButton("Hide") { _, _ ->
                    exitSel()
                    var done = 0
                    var errs = ""
                    fun finish() { toast(if (done > 0) "$done ${wordOf(done)} hidden" else "Failed: ${errs.ifEmpty { "nothing was hidden" }}"); load() }
                    fun second() {
                        if (loose.isEmpty()) finish()
                        else DotLock.lock(this, loose) { ok, err -> done += ok; if (err.isNotEmpty()) errs = err; finish() }
                    }
                    if (folderFiles.isNotEmpty()) DotLock.lockFolders(this, folderFiles) { ok, err -> done += ok; if (err.isNotEmpty()) errs = err; second() }
                    else second()
                }
                .setNegativeButton("Cancel", null).show()
        }
    }
}

/** Unhide the selection (inside the Hide List): the "." is removed again, folders get their old name back. */
fun MainActivity.selUnhide() {
    val l = selFiles()
    if (l.isEmpty()) { toast("Nothing selected"); return }
    exitSel()
    unlockItems(l)
}


/** After a Move: remove the originals without any confirmation window (needs "All files access"; otherwise the system asks as before). */
fun MainActivity.deleteMoved(items: List<Item>) {
    if (!DotLock.hasAccess()) { deleteUris(items.map { it.uri }); return }
    Thread {
        val paths = ArrayList<String>()
        for (x in items) {
            try {
                val f = java.io.File(x.path)
                if (x.path.isNotEmpty() && f.exists() && f.delete()) paths.add(f.path)
                else contentResolver.delete(x.uri, null, null)
            } catch (e: Exception) {
            }
        }
        try { android.media.MediaScannerConnection.scanFile(this, paths.toTypedArray(), null, null) } catch (e: Exception) {}
        runOnUiThread { load() }
    }.start()
}
