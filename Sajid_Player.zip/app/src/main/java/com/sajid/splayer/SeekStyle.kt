package com.sajid.splayer

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Settings > Seek bar style: line colour / thickness and knob colour / size, separately for the three places. */
fun MainActivity.seekStyleMenu() {
    val names = listOf("Main player seek bar", "Pop-up player seek line", "Seek line when icons are hidden")
    choose("Seek bar style", names, -1) { i ->
        when (i) {
            0 -> seekStyleDialog(names[0], "main", pal.bright, 3, 8, 1, 14, 8)
            1 -> seekStyleDialog(names[1], "pop", pf.accent, 2, 3, 1, 12, 15)
            else -> seekStyleDialog(names[2], "edge", pal.bright, 2, 3, 1, 12, 25)
        }
    }
}

private fun MainActivity.seekStyleDialog(title: String, key: String, defColor: Int, defThick: Int, defKnob: Int, minV: Int, maxKnob: Int, defGap: Int) {
    var line = pf.skColor(key, defColor)
    var knobC = pf.skKnobColor(key)
    var thick = pf.skThick(key, defThick)
    var knob = pf.skKnob(key, defKnob)
    var gap = pf.skGap(key, defGap)

    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(20), dp(12), dp(20), dp(8))

    // live preview
    val prev = KnobSeek(this, line)
    prev.sidePad = gap.toFloat()
    prev.max = 100
    prev.progress = 40
    prev.enabledSeek = false
    val prevBox = LinearLayout(this)
    prevBox.setBackgroundColor(0xFF000000.toInt())
    prevBox.addView(prev, LinearLayout.LayoutParams(-1, dp(44)))
    col.addView(prevBox, LinearLayout.LayoutParams(-1, -2))
    fun refresh() {
        prev.fillColor = line
        prev.knobColor = knobC
        prev.lineW = thick.toFloat()
        prev.knobR = knob.toFloat()
        prev.sidePad = gap.toFloat()
        prev.invalidate()
    }
    refresh()

    fun colorRow(text: String, get: () -> Int, set: (Int) -> Unit) {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, dp(4))
        r.addView(label(text, 16f, pal.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        val dot = View(this)
        dot.background = rr(get(), dpf(20), dp(1), 0x66888888)
        r.addView(dot, LinearLayout.LayoutParams(dp(34), dp(34)))
        r.setOnClickListener {
            colorPalette(get()) { c -> set(c); dot.background = rr(c, dpf(20), dp(1), 0x66888888); refresh() }
        }
        col.addView(r)
    }

    fun sliderRow(text: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
        val head = LinearLayout(this)
        head.setPadding(0, dp(14), 0, 0)
        head.addView(label(text, 16f, pal.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        val v = label("${get()} dp", 15f, pal.sub)
        head.addView(v)
        col.addView(head)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = get() - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                set(p + min); v.text = "${p + min} dp"; refresh()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb)
    }

    colorRow("Line color", { line }, { line = it })
    sliderRow("Line thickness", minV, 12, { thick }, { thick = it })
    colorRow("Knob color", { knobC }, { knobC = it })
    sliderRow("Knob size", minV, maxKnob, { knob }, { knob = it })
    sliderRow("Gap on both sides of the screen", 0, 80, { gap }, { gap = it })

    val sv = ScrollView(this)
    sv.addView(col)
    MaterialAlertDialogBuilder(this).setTitle(title).setView(sv)
        .setPositiveButton("Save") { _, _ ->
            pf.put("sk_${key}_c", line)
            pf.put("sk_${key}_kc", if (knobC == Color.WHITE) 0 else knobC)
            pf.put("sk_${key}_t", thick)
            pf.put("sk_${key}_k", knob)
            pf.put("sk_${key}_g", gap)
            toast("Saved")
        }
        .setNeutralButton("Reset") { _, _ -> pf.skReset(key); toast("Reset to default") }
        .setNegativeButton("Cancel", null)
        .show()
}
