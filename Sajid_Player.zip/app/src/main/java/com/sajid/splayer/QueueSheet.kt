package com.sajid.splayer

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog

/** uri != "" : the row also shows a thumbnail and the duration (video queue) */
data class QueueEntry(val key: String, val title: String, val uri: String = "", val id: Long = -1L)

object QueueThumbs {
    val cache = object : android.util.LruCache<String, android.graphics.Bitmap>(60) {}
    val durs = java.util.concurrent.ConcurrentHashMap<String, Long>()
}

private class QueueRowHolder(
    val row: LinearLayout,
    val handle: TextView,
    val thumb: ImageView,
    val name: TextView,
    val sub: TextView,
    val remove: TextView
) : RecyclerView.ViewHolder(row)

object QueueSheet {
    /** thumbnail + duration of one row (loaded in the background, cached) */
    private fun bindThumb(context: Context, h: QueueRowHolder, item: QueueEntry) {
        if (item.uri.isEmpty()) { h.thumb.visibility = View.GONE; h.sub.visibility = View.GONE; h.thumb.tag = null; return }
        h.thumb.visibility = View.VISIBLE
        h.thumb.tag = item.uri
        val cached = QueueThumbs.cache.get(item.uri)
        val d0 = QueueThumbs.durs[item.uri] ?: Prefs(context).sp.getLong("dur_" + item.uri, 0L)
        fun setDur(d: Long) {
            if (d > 0L) { h.sub.text = Media.time(d); h.sub.visibility = View.VISIBLE } else h.sub.visibility = View.GONE
        }
        setDur(d0)
        if (cached != null) { h.thumb.setImageBitmap(cached) } else {
            h.thumb.setImageDrawable(PathIcon(Ic.MOVIE, 0xFF888888.toInt()).also { h.thumb.setPadding(context.dp(16), context.dp(10), context.dp(16), context.dp(10)) })
        }
        if (cached != null && d0 > 0L) { h.thumb.setPadding(0, 0, 0, 0); return }
        Thread {
            var bm = cached
            var dur = d0
            try { if (bm == null) bm = Art.load(context, item.uri, item.id, 200) } catch (e: Exception) {}
            if (dur <= 0L) {
                try {
                    val r = android.media.MediaMetadataRetriever()
                    r.setDataSource(context, android.net.Uri.parse(item.uri))
                    dur = r.extractMetadataLong()
                    r.release()
                } catch (e: Exception) {}
            }
            if (bm != null) QueueThumbs.cache.put(item.uri, bm)
            if (dur > 0L) QueueThumbs.durs[item.uri] = dur
            val fb = bm
            val fd = dur
            h.thumb.post {
                if (h.thumb.tag == item.uri) {
                    if (fb != null) { h.thumb.setPadding(0, 0, 0, 0); h.thumb.setImageBitmap(fb) }
                    setDur(fd)
                }
            }
        }.start()
    }

    private fun android.media.MediaMetadataRetriever.extractMetadataLong(): Long =
        extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L

    fun show(
        context: Context,
        title: String,
        entries: List<QueueEntry>,
        accent: Int,
        currentKey: String? = null,
        showMode: Boolean = false,
        modeIndex: () -> Int = { AudioEngine.modeIndex() },
        onCycleMode: () -> Unit = { AudioEngine.cycleMode() },
        onSelect: (QueueEntry) -> Unit,
        onChange: (List<QueueEntry>) -> Unit
    ) {
        val dialog = BottomSheetDialog(context)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(context.dp(18), context.dp(12), 0, context.dp(20))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF292929.toInt())
                cornerRadii = floatArrayOf(context.dp(26).toFloat(), context.dp(26).toFloat(), context.dp(26).toFloat(), context.dp(26).toFloat(), 0f, 0f, 0f, 0f)
            }
        }
        val header = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, context.dp(18), 0) }
        val close = TextView(context).apply {
            text = "×"; textSize = 30f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        header.addView(close, LinearLayout.LayoutParams(context.dp(42), context.dp(48)))
        val heading = TextView(context).apply {
            text = title; textSize = 18f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val count = TextView(context).apply {
            text = entries.size.toString(); textSize = 14f; setTextColor(0xFFAAAAAA.toInt())
            setPadding(context.dp(8), 0, context.dp(14), 0)
        }
        header.addView(count)
        if (showMode) {
            val modeLabel = TextView(context).apply { textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL }
            val modeIcon = PathIcon(Ic.ORDER, Color.WHITE)
            val modeIv = ImageView(context).apply { setImageDrawable(modeIcon); scaleType = ImageView.ScaleType.FIT_CENTER }
            val modeBox = LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true; isFocusable = true
                setPadding(context.dp(8), 0, context.dp(2), 0)
                addView(modeLabel, LinearLayout.LayoutParams(-2, -2))
                addView(modeIv, LinearLayout.LayoutParams(context.dp(26), context.dp(26)).apply { leftMargin = context.dp(6) })
            }
            fun refreshMode() {
                val i = modeIndex()
                modeLabel.text = AudioEngine.modeLabels[i]
                modeIcon.set(AudioEngine.modePath(i))
                modeIcon.tint(if (i == 0) Color.WHITE else accent)
            }
            refreshMode()
            modeBox.setOnClickListener { onCycleMode(); refreshMode() }
            header.addView(modeBox, LinearLayout.LayoutParams(-2, context.dp(48)))
        }
        root.addView(header)
        val rv = RecyclerView(context).apply {
            layoutManager = LinearLayoutManager(context)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val data = entries.toMutableList()
        var dragHelper: ItemTouchHelper? = null
        val adapter = object : RecyclerView.Adapter<QueueRowHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QueueRowHolder {
                val row = LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(context.dp(4), 0, 0, 0)
                    minimumHeight = context.dp(58)
                    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                }
                val handle = TextView(context).apply {
                    text = "≡"; textSize = 25f; setTextColor(0xFFAAAAAA.toInt()); gravity = Gravity.CENTER
                }
                row.addView(handle, LinearLayout.LayoutParams(context.dp(42), context.dp(54)))
                val thumb = ImageView(context).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = rr(0xFF3A3A3A.toInt(), context.dpf(8))
                    roundClip(context.dpf(8))
                    visibility = View.GONE
                }
                row.addView(thumb, LinearLayout.LayoutParams(context.dp(68), context.dp(44)).apply { leftMargin = context.dp(4) })
                val name = TextView(context).apply {
                    textSize = 15f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
                }
                val sub = TextView(context).apply {
                    textSize = 12.5f; setTextColor(0xFFAAAAAA.toInt()); maxLines = 1
                    visibility = View.GONE
                }
                val col = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(context.dp(12), context.dp(6), context.dp(8), context.dp(6))
                    addView(name)
                    addView(sub)
                }
                row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                val remove = TextView(context).apply {
                    text = "×"; textSize = 28f; setTextColor(0xFFBDBDBD.toInt()); gravity = Gravity.CENTER
                }
                row.addView(remove, LinearLayout.LayoutParams(context.dp(46), context.dp(54)))
                return QueueRowHolder(row, handle, thumb, name, sub, remove)
            }
            override fun getItemCount() = data.size
            override fun onBindViewHolder(h: QueueRowHolder, position: Int) {
                val item = data[position]
                h.name.text = item.title
                bindThumb(context, h, item)
                h.name.setTextColor(if (item.key == currentKey) 0xFF35C759.toInt() else Color.WHITE)
                h.handle.setOnTouchListener { _, event ->
                    if (event.actionMasked == android.view.MotionEvent.ACTION_DOWN) dragHelper?.startDrag(h)
                    true
                }
                h.row.setOnClickListener { onSelect(item); dialog.dismiss() }
                h.remove.setOnClickListener {
                    val at = h.bindingAdapterPosition
                    if (at != RecyclerView.NO_POSITION) {
                        data.removeAt(at); notifyItemRemoved(at); count.text = data.size.toString()
                        onChange(data.toList())
                    }
                }
            }
        }
        rv.adapter = adapter
        var moved = false
        val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(r: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                val from = vh.bindingAdapterPosition; val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                java.util.Collections.swap(data, from, to)
                adapter.notifyItemMoved(from, to)
                moved = true
                return true
            }
            override fun clearView(r: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(r, vh)
                if (moved) { moved = false; onChange(data.toList()) }
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}
            override fun isLongPressDragEnabled() = false
            override fun isItemViewSwipeEnabled() = false
        })
        dragHelper = touch
        touch.attachToRecyclerView(rv)
        root.addView(rv, LinearLayout.LayoutParams(-1, minOf(context.dp(560), context.dp(66) * maxOf(entries.size, 1))))
        dialog.setContentView(root)
        close.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }
}
