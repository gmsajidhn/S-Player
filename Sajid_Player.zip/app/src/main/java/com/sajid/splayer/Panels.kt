package com.sajid.splayer

import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.material.materialswitch.MaterialSwitch

fun fmtSpeedX(x: Float): String = String.format(java.util.Locale.US, "%.2f", x).trimEnd('0').trimEnd('.')

/** "12:30" / "1:02:10" style remaining-time text for the sleep timer. */
fun fmtRemain(ms: Long): String {
    val s = (ms.coerceAtLeast(0L) + 999L) / 1000L
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(java.util.Locale.US, "%d:%02d", m, sec)
}

// ------------------------------------------------------------------ double-tap seek animation

/** Round glass bubble with three chevrons, a soft ripple and "10 sec" text, shown on double tap (left or right). */
class SeekFx(c: Context, private val right: Boolean) : View(c) {
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x47000000 }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d; color = 0x55FFFFFF }
    private val ripple = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.WHITE }
    private val ch = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE; color = Color.WHITE; strokeJoin = Paint.Join.ROUND; strokeWidth = 1.6f * d
    }
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        setShadowLayer(4f * d, 0f, 1f * d, 0x66000000)
    }
    private val tri = Path()
    private var text = ""
    private var step = 0f
    private var pop = 1f
    private val wave = ValueAnimator.ofFloat(0f, 3f).apply {
        duration = 720; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { step = it.animatedValue as Float; invalidate() }
    }
    private val popAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 520
        interpolator = android.view.animation.DecelerateInterpolator(1.6f)
        addUpdateListener { pop = it.animatedValue as Float; invalidate() }
    }
    private val hideRun = Runnable { animate().alpha(0f).setDuration(220).withEndAction { visibility = GONE; wave.cancel() }.start() }

    init { visibility = GONE; alpha = 0f; isClickable = false; setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun show(seconds: Int) {
        text = "$seconds sec"
        removeCallbacks(hideRun)
        if (visibility != VISIBLE) { visibility = VISIBLE; alpha = 0f }
        animate().cancel()
        animate().alpha(1f).setDuration(110).start()
        if (!wave.isStarted) wave.start()
        popAnim.cancel()
        popAnim.start()
        invalidate()
        postDelayed(hideRun, 760)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * .44f
        val scale = .9f + .1f * pop
        // glass bubble + thin rim
        cv.drawCircle(cx, cy, r * scale, fill)
        cv.drawCircle(cx, cy, r * scale, rim)
        // ripple ring that expands and fades on every tap
        ripple.alpha = ((1f - pop) * 110).toInt().coerceIn(0, 255)
        if (ripple.alpha > 0) cv.drawCircle(cx, cy, r * (.78f + .42f * pop), ripple)
        // three chevrons lighting up one after another
        val s = r * .17f
        val gap = s * 1.55f
        val y = cy - r * .16f
        for (k in 0 until 3) {
            val idx = if (right) k else 2 - k
            val a = (1f - kotlin.math.abs(step - idx - .5f).coerceAtMost(1.5f) / 1.5f).coerceIn(.28f, 1f)
            ch.alpha = (a * 255).toInt()
            val x = cx + (k - 1) * gap
            tri.reset()
            if (right) { tri.moveTo(x - s * .55f, y - s); tri.lineTo(x + s * .65f, y); tri.lineTo(x - s * .55f, y + s) }
            else { tri.moveTo(x + s * .55f, y - s); tri.lineTo(x - s * .65f, y); tri.lineTo(x + s * .55f, y + s) }
            tri.close()
            cv.drawPath(tri, ch)
        }
        tx.textSize = (r * .30f).coerceIn(11f * d, 16f * d)
        cv.drawText(text, cx, cy + r * .50f, tx)
    }
}

// ------------------------------------------------------------------ vertical slider (equalizer bands)

class VSlider(c: Context) : View(c) {
    var min = 0
    var max = 100
    var value = 50
        set(v) { field = v.coerceIn(min, max); invalidate() }
    var onChange: ((Int) -> Unit)? = null
    var green = 0xFF2DC76D.toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    private fun pad() = 7f * d          // = thumb radius: thumb centre can reach both ends of the track
    private fun yFor(v: Int): Float {
        val t = (v - min).toFloat() / (max - min).coerceAtLeast(1)
        return pad() + (1f - t) * (height - 2 * pad())
    }

    override fun onDraw(cv: Canvas) {
        val x = width / 2f
        val y = yFor(value)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 1.5f * d
        p.color = 0xFFDDDDDD.toInt()
        cv.drawLine(x, pad(), x, height - pad(), p)
        p.strokeWidth = 2f * d
        p.color = green
        cv.drawLine(x, y, x, height - pad(), p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        cv.drawCircle(x, y, 7f * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> parent.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { parent.requestDisallowInterceptTouchEvent(false); return true }
        }
        val t = 1f - ((e.y - pad()) / (height - 2 * pad())).coerceIn(0f, 1f)
        val nv = min + Math.round(t * (max - min))
        if (nv != value) { value = nv; onChange?.invoke(nv) }
        return true
    }
}

/** Thin horizontal slider (BassBooster / Virtualizer): grey track, green part, white round thumb. */
class HSlider(c: Context) : View(c) {
    var max = 1000
    var value = 0
        set(v) { field = v.coerceIn(0, max); invalidate() }
    var onChange: ((Int) -> Unit)? = null
    var green = 0xFF2DC76D.toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private fun pad() = 7f * d
    private fun xFor(v: Int) = pad() + v.toFloat() / max.coerceAtLeast(1) * (width - 2 * pad())

    override fun onDraw(cv: Canvas) {
        val y = height / 2f
        val x = xFor(value)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 1.5f * d
        p.color = 0xFFDDDDDD.toInt()
        cv.drawLine(pad(), y, width - pad(), y, p)
        p.strokeWidth = 2f * d
        p.color = green
        cv.drawLine(pad(), y, x, y, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        cv.drawCircle(x, y, 7f * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> parent.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { parent.requestDisallowInterceptTouchEvent(false); return true }
        }
        val t = ((e.x - pad()) / (width - 2 * pad())).coerceIn(0f, 1f)
        val nv = Math.round(t * max)
        if (nv != value) { value = nv; onChange?.invoke(nv) }
        return true
    }
}

/** Equalizer sheet body: while the equalizer is OFF everything below the header (ON / OFF row) is dimmed and cannot be touched. */
class EqLockLayout(c: Context) : LinearLayout(c) {
    var locked = false
    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (locked && childCount > 0 && ev.y > getChildAt(0).bottom) return true
        return super.onInterceptTouchEvent(ev)
    }
    fun applyLock() {
        for (i in 1 until childCount) getChildAt(i).alpha = if (locked) 0.35f else 1f
    }
}

/** Small ON/OFF switch like the reference: dark-green track, green round thumb. */
class EqSwitch(c: Context) : View(c) {
    var checked = true
        set(v) { field = v; invalidate() }
    var onToggle: ((Boolean) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension((37 * d).toInt(), (22 * d).toInt()) }
    override fun onDraw(cv: Canvas) {
        val tw = 37f * d; val th = 17f * d; val cy = height / 2f
        p.style = Paint.Style.FILL
        p.color = if (checked) 0xFF2C6747.toInt() else 0xFF4A4A4A.toInt()
        cv.drawRoundRect(0f, cy - th / 2, tw, cy + th / 2, th / 2, th / 2, p)
        p.color = if (checked) 0xFF29C476.toInt() else 0xFF9E9E9E.toInt()
        val tx = if (checked) tw - 10f * d else 10f * d
        cv.drawCircle(tx, cy, 10f * d, p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) { checked = !checked; onToggle?.invoke(checked); performClick() }
        return true
    }
}

// ------------------------------------------------------------------ extra audio effects

/** Many phones (Xiaomi etc.) have no hardware BassBoost: then the lowest equalizer bands are raised instead. */
fun applyBassFallback(e: Equalizer?, x: FxExtras?, pf: Prefs, v: Int) {
    if (e == null) return
    val hw = try { x?.bass?.strengthSupported == true } catch (ex: Exception) { false }
    if (hw) return
    try {
        val maxL = e.bandLevelRange[1].toInt()
        val minL = e.bandLevelRange[0].toInt()
        val on = pf.b("eq_on", true)
        for (b in 0 until minOf(2, e.numberOfBands.toInt())) {
            val base = if (on && pf.sp.contains("eq$b")) pf.i("eq$b", 0) else 0
            val add = if (on) (v / 1000f * maxL * (if (b == 0) 1f else 0.5f)).toInt() else 0
            e.setBandLevel(b.toShort(), (base + add).coerceIn(minL, maxL).toShort())
        }
    } catch (ex: Exception) {}
}

/**
 * Real ON / OFF for the whole equalizer. Many phones keep filtering even after setEnabled(false), so OFF also flattens
 * every band to 0 and sets Bass / Virtualizer / Reverb to zero; ON restores the saved band levels and effect strengths.
 */
fun applyEqState(e: Equalizer?, x: FxExtras?, pf: Prefs, on: Boolean) {
    try {
        if (e != null) {
            val minL = e.bandLevelRange[0].toInt()
            val maxL = e.bandLevelRange[1].toInt()
            if (on) e.setEnabled(true)
            for (b in 0 until e.numberOfBands.toInt()) {
                val lv = if (on && pf.sp.contains("eq$b")) pf.i("eq$b", 0) else 0
                try { e.setBandLevel(b.toShort(), lv.coerceIn(minL, maxL).toShort()) } catch (ex: Exception) {}
            }
            if (!on) e.setEnabled(false)
        }
    } catch (ex: Exception) {}
    val bass = pf.i("fx_bass", 0)
    val virt = pf.i("fx_virt", 0)
    val rev = pf.i("fx_rev", 0)
    try { x?.bass?.let { if (it.strengthSupported) it.setStrength((if (on) bass else 0).toShort()); it.setEnabled(on && bass > 0) } } catch (ex: Exception) {}
    try { x?.virt?.let { if (it.strengthSupported) it.setStrength((if (on) virt else 0).toShort()); it.setEnabled(on && virt > 0) } } catch (ex: Exception) {}
    try { x?.rev?.let { it.preset = (if (on) rev else 0).toShort(); it.setEnabled(on && rev > 0) } } catch (ex: Exception) {}
    if (e != null) applyBassFallback(e, x, pf, bass)
}

class FxExtras {
    var bass: BassBoost? = null
    var virt: Virtualizer? = null
    var rev: PresetReverb? = null

    fun release() {
        try { bass?.release() } catch (e: Exception) {}
        try { virt?.release() } catch (e: Exception) {}
        try { rev?.release() } catch (e: Exception) {}
        bass = null; virt = null; rev = null
    }

    companion object {
        fun create(session: Int, pf: Prefs): FxExtras {
            val x = FxExtras()
            if (session == 0) return x
            val on = pf.b("eq_on", true)
            try { x.bass = BassBoost(0, session).also { b -> if (b.strengthSupported) b.setStrength(pf.i("fx_bass", 0).toShort()); b.setEnabled(on && pf.i("fx_bass", 0) > 0) } } catch (e: Exception) {}
            try { x.virt = Virtualizer(0, session).also { v -> if (v.strengthSupported) v.setStrength(pf.i("fx_virt", 0).toShort()); v.setEnabled(on && pf.i("fx_virt", 0) > 0) } } catch (e: Exception) {}
            try { x.rev = PresetReverb(0, session).also { r -> r.preset = pf.i("fx_rev", 0).toShort(); r.setEnabled(on && pf.i("fx_rev", 0) > 0) } } catch (e: Exception) {}
            return x
        }
    }
}

// ------------------------------------------------------------------ Speed panel (like the reference "Speed" screen)

private fun Context.chip(text: String, selected: Boolean, green: Int, click: () -> Unit): TextView {
    val t = label(text, 17f, Color.WHITE)
    t.gravity = Gravity.CENTER
    t.maxLines = 1
    t.background = rr(if (selected) green else 0xFF262626.toInt(), dpf(30))
    t.setOnClickListener { click() }
    return t
}

/** Full-screen translucent Speed panel: big value, slider 0.25–8.0, preset buttons. */
fun Context.speedPanel(current: Float, onChange: (Float) -> Unit) {
    val green = 0xFF12B312.toInt()
    val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
    dlg.window?.apply {
        setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0xB8000000.toInt()))
        setLayout(-1, -1)
        addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
    }
    val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val root = FrameLayout(this)
    root.setOnClickListener { dlg.dismiss() }
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(16), dp(8), dp(16), dp(16))
    col.isClickable = true

    val head = LinearLayout(this)
    head.gravity = Gravity.CENTER_VERTICAL
    head.addView(iconBtn(Ic.BACK, Color.WHITE, 48, 26) { dlg.dismiss() })
    val title = label("Speed", 22f, Color.WHITE, true)
    title.setPadding(dp(8), 0, 0, 0)
    head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
    val big = label(fmtSpeedX(current) + "x", 26f, Color.WHITE, true)
    head.addView(big)
    col.addView(head, LinearLayout.LayoutParams(-1, -2))

    val seek = SeekBar(this)
    seek.max = 155                                   // 0.25 .. 8.00 in 0.05 steps
    seek.progress = ((current - 0.25f) / 0.05f).toInt().coerceIn(0, 155)
    seek.progressTintList = android.content.res.ColorStateList.valueOf(green)
    seek.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFF3A3A3A.toInt())
    seek.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
    col.addView(seek, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(10) })
    val scale = LinearLayout(this)
    scale.addView(label("0.25", 15f, 0xFFCCCCCC.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
    scale.addView(label("8.0", 15f, 0xFFCCCCCC.toInt()))
    scale.setPadding(dp(14), 0, dp(14), 0)
    col.addView(scale, LinearLayout.LayoutParams(-1, -2))

    val vals = floatArrayOf(0.25f, 0.5f, 1f, 1.25f, 1.5f, 2f, 4f, 8f)
    val chips = ArrayList<TextView>()
    fun refreshChips(v: Float) {
        for ((i, t) in chips.withIndex()) t.background = rr(if (kotlin.math.abs(vals[i] - v) < 0.001f) green else 0xFF262626.toInt(), dpf(30))
    }
    fun apply(v: Float, fromSlider: Boolean) {
        val x = (Math.round(v * 20f) / 20f).coerceIn(0.25f, 8f)
        big.text = fmtSpeedX(x) + "x"
        if (!fromSlider) seek.progress = ((x - 0.25f) / 0.05f).toInt().coerceIn(0, 155)
        refreshChips(x)
        onChange(x)
    }
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) { if (u) apply(0.25f + v * 0.05f, true) }
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    })
    val grid = LinearLayout(this)
    grid.orientation = LinearLayout.VERTICAL
    for (r in 0 until 2) {
        val row = LinearLayout(this)
        for (k in 0 until 4) {
            val v = vals[r * 4 + k]
            val t = chip(fmtSpeedX(v) + "x", kotlin.math.abs(v - current) < 0.001f, green) { apply(v, false) }
            chips.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(5), dp(6), dp(5), dp(6)) })
        }
        grid.addView(row, LinearLayout.LayoutParams(-1, -2))
    }
    col.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

    if (land) root.addView(col, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.58f).toInt(), -2, Gravity.END or Gravity.CENTER_VERTICAL))
    else root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
    dlg.setContentView(root)
    dlg.show()
}

// ------------------------------------------------------------------ Equalizer panel (like the reference)

/** Dark equalizer sheet: ON switch, preset chips, vertical band sliders, Reverb, BassBooster, Virtualizer (sizes follow the reference screenshot). */
fun Context.eqPanel(eq: Equalizer?, extras: FxExtras?, session: Int, pf: Prefs, onStateChange: () -> Unit = {}) {
    val green = 0xFF2CC877.toInt()
    val white = Color.WHITE
    // bottom panel over the player (player stays faintly visible behind it), like the reference screenshot
    val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
    val sv = android.widget.ScrollView(this)
    sv.isVerticalScrollBarEnabled = false
    val col = EqLockLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(0, 0, 0, dp(19))
    col.background = android.graphics.drawable.GradientDrawable().apply {
        setColor(0xF2282828.toInt()); val r = dpf(16); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
    }
    sv.addView(col)

    var on = pf.b("eq_on", true)
    var eqLocal: Equalizer? = null
    fun applyOn() { applyEqState(eq ?: eqLocal, extras, pf, on) }

    // header: ‹  Equalizer ............ ON [switch]
    val top = LinearLayout(this)
    top.gravity = Gravity.CENTER_VERTICAL
    top.setPadding(dp(6), 0, dp(16), 0)
    top.addView(iconBtn(Ic.CHEV_L, white, 40, 26) { dlg.dismiss() })
    val tt = label("Equalizer", 18f, white, true)
    tt.setPadding(dp(6), 0, 0, 0)
    top.addView(tt, LinearLayout.LayoutParams(0, -2, 1f))
    val onTxt = label(if (on) "ON" else "OFF", 17f, white, true)
    top.addView(onTxt)
    val sw = EqSwitch(this)
    sw.checked = on
    sw.onToggle = { v ->
        on = v; pf.put("eq_on", v); applyOn()
        col.locked = !v; col.applyLock()
        onTxt.text = if (v) "ON" else "OFF"
        onStateChange()
    }
    top.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(12) })
    col.addView(top, LinearLayout.LayoutParams(-1, dp(56)))

    // The panel always shows the full layout. If the audio effect is not ready yet (nothing playing),
    // the values are saved and applied as soon as playback starts.
    val e: Equalizer? = eq ?: (if (session != 0) { try { Equalizer(0, session).also { it.setEnabled(on) } } catch (x: Exception) { null } } else null)
    eqLocal = e
    if (e != null && !on) applyEqState(e, extras, pf, false)
    run {
        val fbNames = listOf("Normal", "Classical", "Dance", "Flat", "Folk", "Heavy Metal", "Hip Hop", "Jazz", "Pop", "Rock")
        val fbFreq = intArrayOf(60, 230, 910, 3600, 14000)
        val fbPreset = arrayOf(
            intArrayOf(300, 0, 0, 0, 300), intArrayOf(500, 300, -200, 400, 400), intArrayOf(600, 0, 200, 400, 100),
            intArrayOf(0, 0, 0, 0, 0), intArrayOf(300, 0, 0, 200, -100), intArrayOf(400, 100, 900, 300, 0),
            intArrayOf(500, 300, 0, 100, 300), intArrayOf(400, 200, -200, 200, 500), intArrayOf(-100, 200, 500, 100, -200),
            intArrayOf(500, 300, -100, 300, 500)
        )
        val hw = e
        val minL = if (hw != null) hw.bandLevelRange[0].toInt() else -1500
        val maxL = if (hw != null) hw.bandLevelRange[1].toInt() else 1500
        val nb = if (hw != null) hw.numberOfBands.toInt() else 5
        val sliders = ArrayList<VSlider>()
        val presetChips = ArrayList<TextView>()
        val names = ArrayList<String>()
        names.add("Custom")
        if (hw != null) { for (i in 0 until hw.numberOfPresets.toInt()) names.add(hw.getPresetName(i.toShort())) } else names.addAll(fbNames)
        var selected = (pf.i("eq_preset", -1) + 1).coerceIn(0, names.size - 1)          // 0 = Custom
        fun levelOf(b: Int): Int =
            if (hw != null) hw.getBandLevel(b.toShort()).toInt() else pf.i("eq$b", 0).coerceIn(minL, maxL)

        fun paintChips() {
            for ((i, t) in presetChips.withIndex()) {
                val sel = i == selected
                t.background = if (sel) rr(green, dpf(14)) else rr(0, dpf(14), dp(1), 0xFFD0D0D0.toInt())
                t.setTextColor(white)
            }
        }
        val chipRow = LinearLayout(this)
        chipRow.setPadding(dp(15), 0, dp(15), 0)
        for ((i, n) in names.withIndex()) {
            val t = label(n, 15f, white, true)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.setPadding(dp(12), 0, dp(12), 0)
            t.setOnClickListener {
                selected = i
                pf.put("eq_preset", i - 1)
                if (i > 0) {
                    if (hw != null) {
                        try { hw.usePreset((i - 1).toShort()) } catch (x: Exception) {}
                        for (b in 0 until nb) { val lv = hw.getBandLevel(b.toShort()).toInt(); sliders[b].value = lv; pf.put("eq$b", lv) }
                        applyEqState(hw, extras, pf, on)
                    } else {
                        for (b in 0 until nb) { val lv = fbPreset[i - 1].getOrElse(b) { 0 }.coerceIn(minL, maxL); sliders[b].value = lv; pf.put("eq$b", lv) }
                    }
                }
                paintChips()
            }
            presetChips.add(t)
            chipRow.addView(t, LinearLayout.LayoutParams(-2, dp(27)).apply { marginEnd = dp(10) })
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chipRow)
        col.addView(hs, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        paintChips()

        // 5 vertical bands, full width (each column = 1/5 of the screen)
        val bands = LinearLayout(this)
        bands.weightSum = nb.toFloat()
        for (b in 0 until nb) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            val s = VSlider(this)
            s.green = green; s.min = minL; s.max = maxL
            s.value = levelOf(b)
            s.onChange = { v ->
                pf.put("eq$b", v)
                if (hw != null && on) { try { hw.setBandLevel(b.toShort(), v.toShort()); hw.setEnabled(true) } catch (x: Exception) {} }
                if (selected != 0) { selected = 0; pf.put("eq_preset", -1); paintChips() }
            }
            sliders.add(s)
            cell.addView(s, LinearLayout.LayoutParams(-1, dp(82)))
            val hz = if (hw != null) hw.getCenterFreq(b.toShort()) / 1000 else fbFreq.getOrElse(b) { 1000 }
            cell.addView(label("${hz}Hz", 12f, white, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-2, dp(20)).apply { topMargin = dp(8) })
            bands.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(bands, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(25) })
    }
    dlg.setOnDismissListener { if (eq == null) { try { e?.release() } catch (x: Exception) {} } }

    // reverb:  Reverb  None ▼
    val revNames = listOf("None", "Small room", "Medium room", "Large room", "Medium hall", "Large hall", "Plate")
    val revRow = LinearLayout(this)
    revRow.gravity = Gravity.CENTER_VERTICAL
    revRow.setPadding(dp(24), 0, dp(24), 0)
    revRow.addView(label("Reverb", 14.5f, white, true))
    val revBox = LinearLayout(this)
    revBox.gravity = Gravity.CENTER_VERTICAL
    revBox.setPadding(dp(20), 0, dp(8), 0)
    val revVal = label(revNames[pf.i("fx_rev", 0).coerceIn(0, 6)], 14.5f, green, true)
    revBox.addView(revVal)
    val tri = ImageView(this)
    tri.setImageDrawable(PathIcon("M7,10l5,5 5,-5z", white))
    revBox.addView(tri, LinearLayout.LayoutParams(dp(29), dp(29)).apply { marginStart = dp(8) })
    revBox.setOnClickListener {
        val pm = PopupMenu(this, revBox)
        for ((i, n) in revNames.withIndex()) pm.menu.add(0, i, i, n)
        pm.setOnMenuItemClickListener { mi ->
            val v = mi.itemId
            pf.put("fx_rev", v)
            try { extras?.rev?.preset = v.toShort(); extras?.rev?.setEnabled(on && v > 0) } catch (x: Exception) {}
            revVal.text = revNames[v]
            true
        }
        pm.show()
    }
    revRow.addView(revBox)
    col.addView(revRow, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(5) })

    // full-width divider
    col.addView(View(this).apply { setBackgroundColor(0xFF3D3D3D.toInt()) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(13) })

    fun strengthRow(name: String, key: String, apply: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), 0, 0, 0)
        box.addView(label(name, 14.5f, white, true).apply { gravity = Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(-2, dp(20)))
        val sb = HSlider(this)
        sb.green = green
        sb.max = 1000
        sb.value = pf.i(key, 0)
        sb.onChange = { v -> pf.put(key, v); apply(v) }
        box.addView(sb, LinearLayout.LayoutParams(dp(115), dp(28)).apply { marginStart = dp(8); topMargin = dp(2) })
        return box
    }
    val two = LinearLayout(this)
    two.weightSum = 2f
    two.addView(strengthRow("BassBooster", "fx_bass") { v ->
        try { extras?.bass?.let { if (it.strengthSupported) it.setStrength(v.toShort()); it.setEnabled(on && v > 0) } } catch (x: Exception) {}
        applyBassFallback(e ?: eq, extras, pf, v)
    }, LinearLayout.LayoutParams(0, -2, 1f))
    two.addView(strengthRow("Virtualizer", "fx_virt") { v ->
        try { extras?.virt?.let { if (it.strengthSupported) it.setStrength(v.toShort()); it.setEnabled(on && v > 0) } } catch (x: Exception) {}
    }, LinearLayout.LayoutParams(0, -2, 1f))
    col.addView(two, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(13) })

    val more = label("Explore more equalizer settings  ›", 15f, white, true)
    more.gravity = Gravity.CENTER
    more.background = rr(0, dpf(23), dp(1), 0xFFD0D0D0.toInt())
    more.setOnClickListener {
        try {
            startActivity(
                Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
                    .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, session)
                    .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            )
        } catch (x: Exception) { toast("System equalizer is not available on this device") }
    }
    col.addView(more, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(9); marginStart = dp(25); marginEnd = dp(25) })

    col.locked = !on
    col.applyLock()
    dlg.setContentView(sv)
    dlg.setOnShowListener {
        val sh = dlg.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
        sh?.setBackgroundColor(Color.TRANSPARENT)
        if (sh != null) com.google.android.material.bottomsheet.BottomSheetBehavior.from(sh).apply { state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED; skipCollapsed = true; isDraggable = false }
    }
    dlg.show()
}
