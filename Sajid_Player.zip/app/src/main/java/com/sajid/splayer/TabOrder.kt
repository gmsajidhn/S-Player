package com.sajid.splayer

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

class TabRowAdapter(
    val ctx: Context, val pal: Pal, val items: MutableList<String>, val on: MutableSet<String>,
    val names: Map<String, String>, val drag: (RecyclerView.ViewHolder) -> Unit
) : RecyclerView.Adapter<TabRowAdapter.VH>() {

    class VH(val row: LinearLayout, val handle: ImageView, val label: TextView, val sw: MaterialSwitch) : RecyclerView.ViewHolder(row)

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val row = LinearLayout(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(ctx.dp(16), 0, ctx.dp(16), 0)
        row.layoutParams = RecyclerView.LayoutParams(-1, ctx.dp(58))
        val handle = ImageView(ctx)
        handle.setImageDrawable(PathIcon("M3,15h18v-2H3v2zM3,19h18v-2H3v2zM3,11h18V9H3v2zM3,5v2h18V5H3z", pal.text))
        row.addView(handle, LinearLayout.LayoutParams(ctx.dp(24), ctx.dp(24)).apply { marginEnd = ctx.dp(8) })
        val label = ctx.label("", 19f, pal.text, true)
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = MaterialSwitch(ctx)
        row.addView(sw)
        return VH(row, handle, label, sw)
    }

    override fun getItemCount() = items.size

    @Suppress("ClickableViewAccessibility")
    override fun onBindViewHolder(h: VH, i: Int) {
        val k = items[i]
        h.label.text = names[k] ?: k
        h.sw.setOnCheckedChangeListener(null)
        h.sw.isChecked = k in on
        h.sw.setOnCheckedChangeListener { _, c -> if (c) on.add(k) else on.remove(k) }
        h.handle.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) drag(h)
            false
        }
    }
}

/** Settings > Tab order: two buttons (Video / Audio), each with its own draggable, switchable tab list. */
fun MainActivity.tabOrderDialog() {
    val vNames = mapOf("all" to "All videos", "folder" to "Folder", "playlist" to "Playlist")
    val aNames = mapOf(
        "album" to "Album", "songs" to "Songs", "artist" to "Artist", "folder" to "Folder", "playlist" to "Playlist",
        "recent" to "Recently added", "genres" to "Genres", "mini" to "Mini tracks"
    )
    val vl = pf.order(true).toMutableList()
    val vo = pf.on(true)
    val al = pf.order(false).toMutableList()
    val ao = pf.on(false)
    var curVideo = video

    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.background = rr(if (pal.dark) 0xFF24252B.toInt() else 0xFFEAE9F4.toInt(), dpf(28))
    box.setPadding(0, dp(18), 0, dp(10))

    val seg = LinearLayout(this)
    seg.setPadding(dp(16), 0, dp(16), dp(10))
    val bVideo = label("Video", 16f, pal.text, true)
    val bAudio = label("Audio", 16f, pal.text, true)
    for (b in listOf(bVideo, bAudio)) b.gravity = Gravity.CENTER
    seg.addView(bVideo, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
    seg.addView(bAudio, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
    box.addView(seg)

    val rv = RecyclerView(this)
    rv.layoutManager = LinearLayoutManager(this)
    rv.overScrollMode = android.view.View.OVER_SCROLL_NEVER
    box.addView(rv, LinearLayout.LayoutParams(-1, -2))

    lateinit var touch: ItemTouchHelper
    fun show(v: Boolean) {
        curVideo = v
        bVideo.background = rr(if (v) pal.selTab else pal.unselTab, dpf(22))
        bAudio.background = rr(if (!v) pal.selTab else pal.unselTab, dpf(22))
        bVideo.setTextColor(if (v) pal.onSel else pal.onUnsel)
        bAudio.setTextColor(if (!v) pal.onSel else pal.onUnsel)
        rv.adapter = TabRowAdapter(this, pal, if (v) vl else al, if (v) vo else ao, if (v) vNames else aNames) { touch.startDrag(it) }
    }
    touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
        override fun onMove(r: RecyclerView, a: RecyclerView.ViewHolder, b: RecyclerView.ViewHolder): Boolean {
            val l = if (curVideo) vl else al
            val from = a.adapterPosition
            val to = b.adapterPosition
            if (from < 0 || to < 0) return false
            l.add(to, l.removeAt(from))
            r.adapter?.notifyItemMoved(from, to)
            return true
        }
        override fun onSwiped(v: RecyclerView.ViewHolder, dir: Int) {}
        override fun isLongPressDragEnabled() = false
    })
    touch.attachToRecyclerView(rv)
    bVideo.setOnClickListener { show(true) }
    bAudio.setOnClickListener { show(false) }

    val br = LinearLayout(this)
    br.gravity = Gravity.END
    br.setPadding(dp(16), dp(8), dp(16), 0)
    val cancel = label("Cancel", 16f, pal.text, true)
    cancel.setPadding(dp(20), dp(12), dp(20), dp(12))
    cancel.setOnClickListener { d.dismiss() }
    val ok = label("OK", 16f, pal.text, true)
    ok.setPadding(dp(20), dp(12), dp(20), dp(12))
    ok.setOnClickListener {
        if (vo.isEmpty()) vo.add(vl[0])
        if (ao.isEmpty()) ao.add(al[0])
        pf.saveTabs(true, vl, vo)
        pf.saveTabs(false, al, ao)
        tab = pf.tabs(video).first()
        folder = null
        d.dismiss()
        render()
    }
    br.addView(cancel)
    br.addView(ok)
    box.addView(br)

    show(true)
    d.setContentView(box)
    d.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
    d.show()
    d.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
}
