package com.sajid.splayer

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** Small pop-up music player (cover, name, seek bar, previous / play / next). Used when a song is opened from a file manager. */
class MusicPopupActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var pal: Pal
    private lateinit var art: ImageView
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var cur: TextView
    private lateinit var dur: TextView
    private lateinit var seek: SeekBar
    private lateinit var play: ImageView
    private var shownUri = ""
    private var user = false
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 500)
        }
    }
    private val listener: () -> Unit = { refresh() }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format("%d:%02d", s / 60, s % 60)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pf = Prefs(this)
        pal = Pal(pf.dark, pf.accent)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setDimAmount(0.45f)
        window.setGravity(Gravity.BOTTOM)
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(18), dp(16), dp(18), dp(14))
        card.background = rr(pal.surface, dpf(26), dp(1), pal.line)

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rr(pal.tile, dpf(14))
        art.roundClip(dpf(14))
        art.setPadding(dp(14), dp(14), dp(14), dp(14))
        art.setImageDrawable(PathIcon(Ic.MUSIC, pal.sub))
        top.addView(art, LinearLayout.LayoutParams(dp(64), dp(64)).apply { marginEnd = dp(14) })
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        title = label("", 17f, pal.text, true)
        title.maxLines = 2
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        sub = label("", 13f, pal.sub)
        sub.maxLines = 1
        tc.addView(title)
        tc.addView(sub)
        top.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(iconBtn(Ic.CLOSE, pal.sub, 44, 22) { finish() })
        card.addView(top)

        seek = SeekBar(this)
        seek.progressTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        seek.thumbTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { if (fromUser) cur.text = fmt(v.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) { user = true }
            override fun onStopTrackingTouch(s: SeekBar?) { user = false; AudioEngine.player?.seekTo(seek.progress.toLong()) }
        })
        card.addView(seek, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val times = LinearLayout(this)
        cur = label("0:00", 12f, pal.sub)
        dur = label("0:00", 12f, pal.sub)
        times.addView(cur, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(dur)
        card.addView(times, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), 0, dp(4), 0) })

        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER
        ctl.addView(iconBtn(Ic.PREV, pal.text, 52, 28) { AudioEngine.player?.seekToPrevious() })
        play = iconBtn(Ic.PLAY, Color.WHITE, 60, 30) { AudioEngine.toggle() }
        play.background = rr(pal.accent, dpf(30))
        ctl.addView(play, LinearLayout.LayoutParams(dp(60), dp(60)).apply { setMargins(dp(18), 0, dp(18), 0) })
        ctl.addView(iconBtn(Ic.NEXT, pal.text, 52, 28) { AudioEngine.player?.seekToNext() })
        card.addView(ctl, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val full = label("Open full player", 14f, pal.accent, true)
        full.gravity = Gravity.CENTER
        full.setPadding(0, dp(10), 0, dp(4))
        full.setOnClickListener {
            startActivity(Intent(this, AudioPlayerActivity::class.java))
            finish()
        }
        card.addView(full, LinearLayout.LayoutParams(-1, -2))

        val root = FrameLayout(this)
        root.setOnClickListener { finish() }                       // tap outside: close the pop-up (music keeps playing)
        root.addView(card, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(10), 0, dp(10), dp(12)) })
        card.setOnClickListener { }
        setContentView(root)
        AudioEngine.listeners.add(listener)
        h.post(tick)
    }

    private fun refresh() {
        val t = AudioEngine.current
        val p = AudioEngine.player
        if (t == null || p == null) return
        if (t.uri != shownUri) {
            shownUri = t.uri
            title.text = t.title.ifEmpty { "Unknown" }
            sub.text = t.shownArtist
            val u = t.uri; val id = t.id
            Thread {
                val bmp: Bitmap? = Art.load(this, u, id, 256)
                runOnUiThread {
                    if (bmp != null && shownUri == u) { art.setPadding(0, 0, 0, 0); art.setImageBitmap(bmp) }
                    else if (shownUri == u) { art.setPadding(dp(14), dp(14), dp(14), dp(14)); art.setImageDrawable(PathIcon(Ic.MUSIC, pal.sub)) }
                }
            }.start()
        }
        val d = p.duration.coerceAtLeast(0L)
        if (!user) {
            seek.max = d.toInt().coerceAtLeast(1)
            seek.progress = p.currentPosition.toInt()
            cur.text = fmt(p.currentPosition)
        }
        dur.text = fmt(d)
        play.setImageDrawable(PathIcon(if (p.isPlaying) Ic.PAUSE else Ic.PLAY, Color.WHITE))
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
        AudioEngine.listeners.remove(listener)
    }
}
