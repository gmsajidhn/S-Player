package com.sajid.splayer

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.media3.common.Player
import kotlin.math.sqrt

/**
 * One shared shake detector for the video player, the pop-up window and the music service.
 * The accelerometer is registered ONLY while "Enable shake" is on AND something is able to play,
 * so with the switch off the sensor is completely off (no battery use).
 */
object Shake {
    private val owners = LinkedHashMap<Any, () -> Player?>()
    private var sm: SensorManager? = null
    private var registered = false
    private var last = 0L
    private var app: Context? = null

    private val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val c = app ?: return
            val pf = Prefs(c)
            if (!pf.shake) { sync(c); return }
            val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / SensorManager.GRAVITY_EARTH
            val thr = 1.3f + pf.shakeForce / 100f * 1.7f
            val now = System.currentTimeMillis()
            if (g > thr && now - last > 1000) {
                last = now
                val players = owners.values.mapNotNull { it() }
                // the player that is playing wins; otherwise the most recently added one
                val p = players.firstOrNull { it.isPlaying } ?: players.lastOrNull() ?: return
                when (pf.shakeAction) {
                    0 -> p.seekToNext()
                    1 -> p.seekToPrevious()
                    else -> if (p.isPlaying) p.pause() else p.play()
                }
            }
        }
        override fun onAccuracyChanged(s: Sensor?, acc: Int) {}
    }

    /** A screen / service that owns a player registers itself here and removes itself when it dies. */
    fun add(ctx: Context, owner: Any, player: () -> Player?) {
        owners[owner] = player
        sync(ctx)
    }

    fun remove(ctx: Context, owner: Any) {
        owners.remove(owner)
        sync(ctx)
    }

    /** Call after the "Enable shake" switch changes: starts or stops the sensor right away. */
    fun sync(ctx: Context) {
        val c = ctx.applicationContext
        app = c
        val want = Prefs(c).shake && owners.isNotEmpty()
        if (want && !registered) {
            val m = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val acc = m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            m.registerListener(listener, acc, SensorManager.SENSOR_DELAY_UI)
            sm = m
            registered = true
        } else if (!want && registered) {
            try { sm?.unregisterListener(listener) } catch (e: Exception) {}
            registered = false
        }
    }
}
