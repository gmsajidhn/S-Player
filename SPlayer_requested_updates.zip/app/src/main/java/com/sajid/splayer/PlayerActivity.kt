package com.sajid.splayer

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.os.Build
import android.widget.CheckBox
import android.widget.ScrollView
import android.widget.PopupWindow
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil
import androidx.media3.exoplayer.video.MediaCodecVideoRenderer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

class PlayerActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var p: ExoPlayer
    lateinit var pv: PlayerView
    lateinit var root: FrameLayout
    lateinit var topPanel: LinearLayout
    lateinit var botPanel: LinearLayout
    lateinit var toolsRow: LinearLayout
    lateinit var rotBtn: ImageView
    lateinit var rotRow: LinearLayout
    var unlockShown = false
    lateinit var flashTxt: TextView
    lateinit var titleTxt: TextView
    lateinit var curTxt: TextView
    lateinit var durTxt: TextView
    lateinit var seek: SeekBar
    lateinit var edgeSeek: SeekBar
    lateinit var playIc: PathIcon
    var stopAfterCurrent = false
    lateinit var lockBtn: ImageView
    lateinit var gd: GestureDetector
    lateinit var am: AudioManager
    var uris: List<String> = emptyList()
    var names: List<String> = emptyList()
    var isVideo = true
    var locked = false
    var shown = true
    var muted = false
    var night = false
    var flipped = false
    var inPip = false
    var userSeeking = false
    var expanded = false
    var a = -1L
    var b = -1L
    var resizeIdx = 0
    var savedBright = -1f
    var cBright = 0
    var cContrast = 100
    var cSat = 100
    var eq: Equalizer? = null
    var loud: LoudnessEnhancer? = null
    var sm: SensorManager? = null
    var ticks = 0
    var lastFlashUpdate = 0L
    var gMode = 0
    var gStartPos = 0L
    var gTarget = 0L
    var gStartB = 0.5f
    var gStartV = 0
    var holdSpeedActive = false
    var speedBeforeHold = 1f
    var trackIdx = -1
    var trackPos = 0L
    var trackDur = 0L
    val toolViews = ArrayList<View>()
    val toolLabels = ArrayList<TextView>()
    val h = Handler(Looper.getMainLooper())

    val autoHide = Runnable { if (isVideo && p.isPlaying && !locked) show(false) }
    val hideFlash = Runnable { flashTxt.visibility = View.GONE; flashTxt.translationX = 0f }
    val hideUnlock = Runnable { if (locked) { unlockShown = false; botPanel.visibility = View.GONE } }
    val sleepRun = Runnable { p.pause(); finish() }

    val tick = object : Runnable {
        override fun run() {
            val d = maxOf(p.duration, 0L)
            val c = p.currentPosition
            trackIdx = p.currentMediaItemIndex
            trackPos = c
            trackDur = d
            if (a >= 0 && b > a && c >= b) p.seekTo(a)
            if (!userSeeking) {
                seek.max = d.toInt()
                seek.progress = c.toInt()
                edgeSeek.max = d.toInt()
                edgeSeek.progress = c.toInt()
                curTxt.text = Media.time(c)
            }
            durTxt.text = Media.time(d)
            ticks++
            if (ticks % 16 == 0) savePos()
            h.postDelayed(this, 300)
        }
    }

    val shakeL = object : SensorEventListener {
        var last = 0L
        override fun onSensorChanged(e: SensorEvent) {
            val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / SensorManager.GRAVITY_EARTH
            val thr = 1.3f + pf.shakeForce / 100f * 1.7f
            val now = System.currentTimeMillis()
            if (g > thr && now - last > 1000) {
                last = now
                when (pf.shakeAction) {
                    0 -> p.seekToNext()
                    1 -> p.seekToPrevious()
                    else -> if (p.isPlaying) p.pause() else p.play()
                }
            }
        }
        override fun onAccuracyChanged(s: Sensor?, acc: Int) {}
    }

    fun lp(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)

    val plListener = object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { setupFx(audioSessionId) }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && stopAfterCurrent) {
                    p.pause()
                    stopAfterCurrent = false
                    p.pauseAtEndOfMediaItems = !pf.auto
                                flash("Stopped after current item")
                }
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (isVideo && pf.orient == 3 && videoSize.width > 0) {
                    requestedOrientation = if (videoSize.width >= videoSize.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                }
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // remember where the previous video was left
                if (trackIdx in uris.indices && trackIdx != p.currentMediaItemIndex) saveAt(trackIdx, trackPos, trackDur)
                onTrack()
                // continue the new video from where it was left last time
                if (pf.resume && (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK)) {
                    val ni = p.currentMediaItemIndex
                    if (ni in uris.indices) {
                        val sv = pf.sp.getLong("pos_" + uris[ni], 0L)
                        if (sv > 0L) { p.seekTo(sv); flash("Resumed from " + Media.time(sv)) }
                    }
                }
                trackIdx = p.currentMediaItemIndex
                trackPos = 0L
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playIc.set(if (isPlaying) Ic.PAUSE else Ic.PLAY)
                if (!isPlaying && stopAfterCurrent && p.duration > 0L && p.currentPosition >= p.duration - 300L) {
                    p.pause()
                    stopAfterCurrent = false
                    p.pauseAtEndOfMediaItems = !pf.auto
                                flash("Stopped after current item")
                }
                if (isPlaying) show(shown)
            }
            override fun onPlayerError(error: PlaybackException) { toast("Cannot play this file (${error.errorCodeName})") }
            }


    // ------------------------------------------------------------------ setup
    override fun onCreate(s: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(s)
        pal = Pal(pf.dark, pf.accent)
        isVideo = intent.getBooleanExtra("v", true)
        uris = intent.getStringArrayListExtra("u") ?: arrayListOf()
        names = intent.getStringArrayListExtra("n") ?: arrayListOf()
        val data = intent.data
        if (uris.isEmpty() && data != null) {
            uris = listOf(data.toString())
            names = listOf(nameOf(data))
            isVideo = (intent.type ?: "video/*").startsWith("video")
        }
        if (uris.isEmpty()) { finish(); return }
        if (!isVideo) {
            // audio now plays in the dedicated audio screen
            val ix = intent.getIntExtra("i", 0).coerceIn(0, uris.size - 1)
            AudioEngine.start(this, uris.mapIndexed { i, u -> Track(u, names.getOrElse(i) { "" }.substringBeforeLast('.'), "", "", -1L) }, ix)
            startActivity(Intent(this, AudioPlayerActivity::class.java))
            finish()
            return
        }
        am = getSystemService(AUDIO_SERVICE) as AudioManager

        if (isVideo) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.attributes = window.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val wc = WindowInsetsControllerCompat(window, window.decorView)
        wc.isAppearanceLightStatusBars = false
        wc.isAppearanceLightNavigationBars = false
        if (isVideo) {
            wc.hide(WindowInsetsCompat.Type.systemBars())
            wc.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            requestedOrientation = when (pf.orient) {
                1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            }
        }

        val idx = intent.getIntExtra("i", 0).coerceIn(0, uris.size - 1)
        if (isVideo && uris.none { it.contains("/vault/") }) { pf.lastQ = uris; pf.lastQN = names }
        p = makePlayer()
        p.setHandleAudioBecomingNoisy(true)
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(if (isVideo) C.AUDIO_CONTENT_TYPE_MOVIE else C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
        )
        p.setWakeMode(C.WAKE_MODE_LOCAL)
        val pos = if (intent.hasExtra("pos")) intent.getLongExtra("pos", 0L)
        else if (pf.resume) pf.sp.getLong("pos_" + uris[idx], 0L) else 0L
        p.setMediaItems(uris.map { MediaItem.fromUri(it) }, idx, pos)
        p.pauseAtEndOfMediaItems = !pf.auto

        buildUi()
        pv.player = p
        p.addListener(plListener)
        p.prepare()
        p.playWhenReady = intent.getBooleanExtra("play", true)
        trackIdx = idx
        onTrack()
        h.post(tick)
        if (isVideo && pos > 3000L) flash("Resumed from " + Media.time(pos))

        if (pf.shake) {
            sm = getSystemService(SENSOR_SERVICE) as SensorManager
            val acc = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (acc != null) sm?.registerListener(shakeL, acc, SensorManager.SENSOR_DELAY_UI)
        }
        if (intent.getBooleanExtra("pip", false)) { show(false); root.post { enterPip() } }
    }

    fun swFactory(): RenderersFactory {
        val sel = MediaCodecSelector { mime, secure, tunneling ->
            val l = MediaCodecUtil.getDecoderInfos(mime, secure, tunneling)
            l.sortedBy { if (it.softwareOnly) 0 else if (it.hardwareAccelerated) 2 else 1 }
        }
        return RenderersFactory { handler, videoL, audioL, _, _ ->
            arrayOf<Renderer>(
                MediaCodecVideoRenderer(this, sel, 5000L, handler, videoL, 50),
                MediaCodecAudioRenderer(this, sel, handler, audioL)
            )
        }
    }

    fun makePlayer(): ExoPlayer {
        val x = if (pf.decoder == 1) ExoPlayer.Builder(this, swFactory()).build() else ExoPlayer.Builder(this).build()
        // Keyframe-aligned seeking avoids expensive frame-by-frame decoding on rapid double taps.
        x.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        x.setHandleAudioBecomingNoisy(true)
        x.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
        x.setWakeMode(C.WAKE_MODE_LOCAL)
        return x
    }

    fun rebuildPlayer() {
        val i = p.currentMediaItemIndex
        val pos = p.currentPosition
        val play = p.playWhenReady
        val rm = p.repeatMode
        val shuffle = p.shuffleModeEnabled
        val spd = p.playbackParameters.speed
        p.removeListener(plListener)
        p.release()
        p = makePlayer()
        p.setMediaItems(uris.map { MediaItem.fromUri(it) }, i, pos)
        p.pauseAtEndOfMediaItems = stopAfterCurrent || (!pf.auto && rm == Player.REPEAT_MODE_OFF && !shuffle)
        p.repeatMode = rm
        p.shuffleModeEnabled = shuffle
        p.setPlaybackSpeed(spd)
        pv.player = p
        p.addListener(plListener)
        p.prepare()
        p.playWhenReady = play
    }

    fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "video"
            }
        } catch (e: Exception) {
        }
        return u.lastPathSegment ?: "video"
    }

    fun onTrack() {
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val n = names.getOrElse(i) { "" }
        titleTxt.text = n
        if (!uris[i].contains("/vault/")) {
            pf.lastUri = uris[i]
            pf.lastName = n
            pf.lastVideo = isVideo
        }
        a = -1L
        b = -1L
        if (!isVideo && pf.broadcast) {
            try { sendBroadcast(Intent("com.android.music.metachanged").putExtra("track", n).putExtra("playing", true)) } catch (e: Exception) {}
        }
    }

    // ------------------------------------------------------------------ ui
    fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = layoutInflater.inflate(R.layout.view_player, root, false) as PlayerView
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        if (!isVideo) {
            val art = FrameLayout(this)
            art.background = rr(pal.accent and 0x00FFFFFF or 0x33000000, dpf(40))
            val ic = ImageView(this)
            ic.setImageDrawable(PathIcon(Ic.MUSIC, pal.bright))
            art.addView(ic, FrameLayout.LayoutParams(dp(96), dp(96), Gravity.CENTER))
            root.addView(art, FrameLayout.LayoutParams(dp(200), dp(200), Gravity.CENTER))
        }

        // ---- top panel: back / title / queue / more, then a small row of quick tools
        topPanel = LinearLayout(this)
        topPanel.orientation = LinearLayout.VERTICAL
        topPanel.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0))
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(iconBtn(Ic.BACK, Color.WHITE, 48, 26) { finishUp() })
        titleTxt = label("", 17f, Color.WHITE, true)
        titleTxt.maxLines = 1
        titleTxt.ellipsize = android.text.TextUtils.TruncateAt.END
        titleTxt.setPadding(dp(8), 0, dp(8), 0)
        bar.addView(titleTxt, lp(0, -2, 1f))
        bar.addView(iconBtn(Ic.QUEUE, Color.WHITE, 48, 24) { queueSheet() })
        val more = iconBtn(Ic.MORE, Color.WHITE, 48, 24) {}
        more.setOnClickListener { moreMenu(more) }
        bar.addView(more)
        topPanel.addView(bar)

        root.addView(topPanel, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- bottom panel
        botPanel = LinearLayout(this)
        botPanel.orientation = LinearLayout.VERTICAL
        botPanel.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xDD000000.toInt(), 0))
        // lock sits right above the current time (left), rotation right above the total time (right)
        rotRow = LinearLayout(this)
        rotRow.gravity = Gravity.CENTER_VERTICAL
        lockBtn = iconBtn(Ic.LOCK, Color.WHITE, 44, 24) { onLockTap() }
        lockBtn.background = ring(44)
        rotRow.addView(lockBtn)
        rotRow.addView(View(this), lp(0, 1, 1f))
        rotBtn = iconBtn(Ic.ROTATE, Color.WHITE, 44, 24) { rotate() }
        rotBtn.background = ring(44)
        rotRow.addView(rotBtn)
        botPanel.addView(rotRow)
        val tl = LinearLayout(this)
        tl.setPadding(dp(4), 0, dp(4), 0)
        curTxt = label("0:00", 14f, Color.WHITE, true)
        durTxt = label("0:00", 14f, 0xCCFFFFFF.toInt(), true)
        tl.addView(curTxt, lp(0, -2, 1f))
        tl.addView(durTxt)
        botPanel.addView(tl)
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(pal.bright)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) { if (u) { p.seekTo(v.toLong()); curTxt.text = Media.time(v.toLong()) } }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true; h.removeCallbacks(autoHide) }
            override fun onStopTrackingTouch(sb: SeekBar?) { userSeeking = false; show(true) }
        })
        botPanel.addView(seek, lp(-1, dp(32)))

        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER_VERTICAL
        playIc = PathIcon(Ic.PLAY, Color.WHITE)
        val playBtn = ImageView(this)
        playBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        playBtn.setImageDrawable(playIc)
        playBtn.background = ripple(null, dpf(28))
        playBtn.setOnClickListener {
            if (p.isPlaying) p.pause() else { if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L); p.play() }
        }
        ctl.addView(playBtn, lp(dp(56), dp(56)))
        ctl.addView(iconBtn(Ic.NEXT, Color.WHITE, 48, 28) { p.seekToNext() })
        ctl.addView(iconBtn(Ic.PREV, Color.WHITE, 48, 28) { p.seekToPrevious() })
        ctl.addView(View(this), lp(0, 1, 1f))
        ctl.addView(iconBtn(Ic.SPEED, Color.WHITE, 48, 26) { speedDialog() })
        ctl.addView(iconBtn(Ic.PIP, Color.WHITE, 48, 26) { popup() })
        ctl.addView(iconBtn(Ic.FIT, Color.WHITE, 48, 26) { cycleFit() })
        botPanel.addView(ctl)
        root.addView(botPanel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // Slim progress line stays visible while the playback controls auto-hide.
        edgeSeek = SeekBar(this)
        edgeSeek.max = 1000
        edgeSeek.progressTintList = ColorStateList.valueOf(pal.bright)
        edgeSeek.progressBackgroundTintList = ColorStateList.valueOf(0x66FFFFFF)
        edgeSeek.thumbTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        edgeSeek.setPadding(0, 0, 0, 0)
        edgeSeek.visibility = View.GONE
        edgeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                if (fromUser) { p.seekTo(v.toLong()); curTxt.text = Media.time(v.toLong()) }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true; h.removeCallbacks(autoHide) }
            override fun onStopTrackingTouch(sb: SeekBar?) { userSeeking = false; show(false) }
        })
        root.addView(edgeSeek, FrameLayout.LayoutParams(-1, dp(18), Gravity.BOTTOM).apply {
            leftMargin = dp(10); rightMargin = dp(10); bottomMargin = 0
        })

        flashTxt = label("", 18f, Color.WHITE, true)
        flashTxt.setPadding(dp(20), dp(10), dp(20), dp(10))
        flashTxt.background = rr(0xCC000000.toInt(), dpf(14))
        flashTxt.visibility = View.GONE
        root.addView(flashTxt, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(90) })

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            // same spacing in portrait and landscape; notch / cut-out and bars are respected on every side
            val i = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topPanel.setPadding(dp(8) + i.left, dp(4) + i.top, dp(8) + i.right, dp(24))
            botPanel.setPadding(dp(12) + i.left, dp(24), dp(12) + i.right, dp(8) + i.bottom)
            ins
        }
        topPanel.setPadding(dp(8), dp(4), dp(8), dp(24))
        botPanel.setPadding(dp(12), dp(24), dp(12), dp(8))

        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onLongPress(e: MotionEvent) {
                if (!locked && isVideo && pf.b("hold_speed_enabled", true)) {
                    speedBeforeHold = p.playbackParameters.speed
                    p.setPlaybackSpeed(pf.sp.getFloat("hold_speed", 3f).coerceIn(1f, 8f))
                    holdSpeedActive = true
                    flash("${fmtSpeed(p.playbackParameters.speed)}x", true)
                }
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) showUnlock() else show(!shown || !isVideo)
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val third = root.width / 3f
                if (e.x > third && e.x < third * 2f) {
                    if (p.isPlaying) p.pause() else {
                        if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
                        p.play()
                    }
                    return true
                }
                val fwd = e.x > root.width / 2f
                // Keep the skip feedback on the side that was tapped, like common video players.
                flashTxt.translationX = if (fwd) root.width * 0.24f else -root.width * 0.24f
                val from = p.currentPosition
                val target = (from + if (fwd) 10_000L else -10_000L)
                    .coerceIn(0L, maxOf(p.duration, 0L))
                p.seekTo(target)
                // Show only the amount actually skipped, without extra action text.
                val skippedSeconds = kotlin.math.abs(target - from) / 1000L
                flash((if (target >= from) "+" else "−") + "$skippedSeconds seconds", true)
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || inPip) return false
                if (gMode == 0) {
                    if (abs(e2.x - e1.x) > abs(e2.y - e1.y)) { gMode = 1; gStartPos = p.currentPosition; gTarget = gStartPos }
                    else if (!isVideo) return false
                    else if (e1.x < root.width / 2f) { gMode = 2; gStartB = curBright() }
                    else { gMode = 3; gStartV = am.getStreamVolume(AudioManager.STREAM_MUSIC) }
                }
                when (gMode) {
                    1 -> {
                        val d = ((e2.x - e1.x) / root.width * 90000).toLong()
                        gTarget = (gStartPos + d).coerceIn(0L, maxOf(p.duration, 0L))
                        val diff = (gTarget - gStartPos) / 1000
                        flash(Media.time(gTarget) + "  (" + (if (diff >= 0) "+" else "") + diff + "s)")
                    }
                    2 -> {
                        val nb = (gStartB + (e1.y - e2.y) / root.height * 1.2f).coerceIn(0.02f, 1f)
                        window.attributes = window.attributes.apply { screenBrightness = nb }
                        flash("Brightness " + (nb * 100).roundToInt() + "%")
                    }
                    3 -> {
                        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val nv = (gStartV + (e1.y - e2.y) / root.height * mx * 1.2f).roundToInt().coerceIn(0, mx)
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, nv, 0)
                        flash("Volume $nv / $mx")
                    }
                }
                return true
            }
        })
        root.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (gMode == 1) p.seekTo(gTarget)
                gMode = 0
                if (holdSpeedActive) {
                    holdSpeedActive = false
                    p.setPlaybackSpeed(speedBeforeHold.coerceIn(0.25f, 8f))
                    flash("${fmtSpeed(speedBeforeHold)}x")
                }
            }
            true
        }
        setContentView(root)
    }

    /** soft translucent circle used behind the few floating buttons */
    fun ring(size: Int): GradientDrawable = rr(0x55000000, dpf(size / 2), dp(1), 0x44FFFFFF)

    // ------------------------------------------------------------------ visibility / feedback
    fun show(v: Boolean) {
        val vv = v || !isVideo
        shown = vv
        val vis = if (vv && !locked && !inPip) View.VISIBLE else View.GONE
        topPanel.visibility = vis
        botPanel.visibility = if (inPip) View.GONE else if (locked) (if (unlockShown) View.VISIBLE else View.GONE) else vis
        edgeSeek.visibility = if (!vv && isVideo && !locked && !inPip) View.VISIBLE else View.GONE
        h.removeCallbacks(autoHide)
        if (vv && isVideo && !locked && p.isPlaying) h.postDelayed(autoHide, 4000)
    }

    fun showUnlock() {
        unlockShown = true
        if (!inPip) botPanel.visibility = View.VISIBLE
        edgeSeek.visibility = View.GONE
        h.removeCallbacks(hideUnlock)
        h.postDelayed(hideUnlock, 2500)
    }

    /** Locked: only the unlock icon (same spot as the lock icon) stays, everything else is hidden. */
    fun setLockedUi(l: Boolean) {
        for (i in 0 until botPanel.childCount) {
            val c = botPanel.getChildAt(i)
            if (c !== rotRow) c.visibility = if (l) View.INVISIBLE else View.VISIBLE
        }
        rotBtn.visibility = if (l) View.INVISIBLE else View.VISIBLE
        botPanel.background = if (l) null else GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xDD000000.toInt(), 0))
        (lockBtn.drawable as PathIcon).set(if (l) Ic.UNLOCK else Ic.LOCK)
    }

    fun onLockTap() {
        if (!locked) {
            locked = true
            setLockedUi(true)
            show(false)
            showUnlock()
        } else {
            locked = false
            unlockShown = false
            h.removeCallbacks(hideUnlock)
            setLockedUi(false)
            show(true)
        }
    }

    fun flash(msg: String, force: Boolean = false) {
        // Gesture scrubbing can fire dozens of callbacks per second; cap overlay relayouts.
        val now = android.os.SystemClock.uptimeMillis()
        if (!force && now - lastFlashUpdate < 55L) return
        lastFlashUpdate = now
        if (flashTxt.visibility != View.VISIBLE || flashTxt.text.toString() != msg) {
            flashTxt.text = msg
            flashTxt.visibility = View.VISIBLE
        }
        h.removeCallbacks(hideFlash)
        h.postDelayed(hideFlash, 650)
    }

    fun curBright(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f } catch (e: Exception) { 0.5f }
    }

    fun finishUp() { savePos(); finish() }

    fun savePos() {
        if (uris.isEmpty()) return
        saveAt(p.currentMediaItemIndex.coerceIn(0, uris.size - 1), p.currentPosition, p.duration)
    }

    fun saveAt(i: Int, c: Long, d: Long) {
        if (i !in uris.indices) return
        val end = d > 0 && c > d - 3000
        pf.sp.edit().putLong("pos_" + uris[i], if (end || c < 3000) 0L else c).apply()
    }

    // ------------------------------------------------------------------ tools
    fun toggleNight() {
        night = !night
        if (night) {
            savedBright = window.attributes.screenBrightness
            window.attributes = window.attributes.apply { screenBrightness = 0.03f }
        } else {
            window.attributes = window.attributes.apply { screenBrightness = if (savedBright >= 0f) savedBright else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
        }
        flash(if (night) "Night mode on" else "Night mode off")
    }

    fun rotate() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    fun speedDialog() {
        val v = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, -1f, 1.25f, 1.5f, 1.75f, 2f, 3f, 4f, 5f, 6f)   // -1 = custom, right after 1x
        val cs = pf.sp.getFloat("custom_speed", 0f)
        val labels = v.map { if (it < 0f) (if (cs > 0f) "Custom (${fmtSpeed(cs)}x)" else "Custom…") else "${fmtSpeed(it)}x" }
        val cur = p.playbackParameters.speed
        val ci = v.indexOfFirst { it > 0f && Math.abs(it - cur) < 0.001f }
        choose("Playback speed", labels, if (ci >= 0) ci else if (cs > 0f && Math.abs(cs - cur) < 0.001f) 4 else -1) {
            if (v[it] < 0f) {
                askNumber("Custom speed", "0.25 – 6", if (cs > 0f) fmtSpeed(cs) else fmtSpeed(cur), true) { x ->
                    val sp = x.toFloat().coerceIn(0.25f, 6f)
                    pf.sp.edit().putFloat("custom_speed", sp).apply()
                    p.setPlaybackSpeed(sp)
                    flash("${fmtSpeed(sp)}x")
                }
            } else { p.setPlaybackSpeed(v[it]); flash("${fmtSpeed(v[it])}x") }
        }
    }

    fun fmtSpeed(x: Float): String = String.format(java.util.Locale.US, "%.2f", x).trimEnd('0').trimEnd('.')

    fun timerDialog() {
        val m = intArrayOf(0, 15, 30, 45, 60, 90)
        choose("Sleep timer", m.map { if (it == 0) "Off" else "$it minutes" } + "Custom…", -1) {
            h.removeCallbacks(sleepRun)
            if (it == m.size) {
                askNumber("Custom timer", "Minutes (1 – 600)", "", false) { x ->
                    val mm = x.toInt().coerceIn(1, 600)
                    h.postDelayed(sleepRun, mm * 60000L); flash("Sleep in $mm min")
                }
            } else if (m[it] > 0) { h.postDelayed(sleepRun, m[it] * 60000L); flash("Sleep in ${m[it]} min") } else flash("Timer off")
        }
    }

    fun abRepeat() {
        when {
            a < 0 -> { a = p.currentPosition; flash("A set  " + Media.time(a)) }
            b < 0 -> { b = p.currentPosition; flash("B set  " + Media.time(b)) }
            else -> { a = -1L; b = -1L; flash("A-B repeat off") }
        }
    }

    fun cycleFit() {
        val modes = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL)
        val nm = listOf("Fit", "Crop", "Stretch")
        resizeIdx = (resizeIdx + 1) % 3
        pv.resizeMode = modes[resizeIdx]
        flash(nm[resizeIdx])
    }

    fun setupFx(id: Int) {
        try { eq?.release() } catch (e: Exception) {}
        try { loud?.release() } catch (e: Exception) {}
        eq = null
        loud = null
        if (id == 0) return
        try {
            val e = Equalizer(0, id)
            for (bd in 0 until e.numberOfBands.toInt()) {
                val k = "eq$bd"
                if (pf.sp.contains(k)) { e.setBandLevel(bd.toShort(), pf.i(k, 0).toShort()); e.setEnabled(true) }
            }
            eq = e
        } catch (e: Exception) {
        }
        try {
            val l = LoudnessEnhancer(id)
            l.setTargetGain(600)
            l.setEnabled(pf.smartVol)
            loud = l
        } catch (e: Exception) {
        }
    }

    fun eqDialog() {
        if (pf.sysEq) {
            try {
                startActivity(
                    Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
                        .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, p.audioSessionId)
                        .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MOVIE)
                )
                return
            } catch (e: Exception) {
            }
        }
        val e = eq
        if (e == null) { toast("Equalizer is not available yet"); return }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(8), dp(22), 0)
        val minL = e.bandLevelRange[0].toInt()
        val maxL = e.bandLevelRange[1].toInt()
        val bars = ArrayList<SeekBar>()
        for (bd in 0 until e.numberOfBands.toInt()) {
            val bi = bd.toShort()
            val hz = e.getCenterFreq(bi) / 1000
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label(if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz", 13f, pal.text), lp(dp(64), -2))
            val sb = SeekBar(this)
            sb.max = maxL - minL
            sb.progress = e.getBandLevel(bi) - minL
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    if (u) { e.setBandLevel(bi, (v + minL).toShort()); e.setEnabled(true); pf.put("eq$bd", v + minL) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            bars.add(sb)
            row.addView(sb, lp(0, -2, 1f))
            box.addView(row)
        }
        val presets = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
        MaterialAlertDialogBuilder(this).setTitle("Equalizer").setView(box)
            .setPositiveButton("Done", null)
            .setNeutralButton("Reset") { _, _ ->
                for (bd in 0 until e.numberOfBands.toInt()) { e.setBandLevel(bd.toShort(), 0); pf.put("eq$bd", 0) }
                e.setEnabled(true)
            }
            .apply {
                if (presets.isNotEmpty()) setNegativeButton("Presets") { _, _ ->
                    choose("Preset", presets, -1) { pi ->
                        e.usePreset(pi.toShort())
                        e.setEnabled(true)
                        for (bd in 0 until e.numberOfBands.toInt()) pf.put("eq$bd", e.getBandLevel(bd.toShort()).toInt())
                    }
                }
            }.show()
    }

    fun applyColor() {
        val cm = ColorMatrix()
        cm.setSaturation(cSat / 100f)
        val c = cContrast / 100f
        val t = (1f - c) * 128f + cBright
        cm.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        val tv = pv.videoSurfaceView as? TextureView
        tv?.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
    }

    fun seekRow(t: String, min: Int, max: Int, cur: Int, on: (Int) -> Unit): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(6), 0, dp(6))
        r.addView(label(t, 15f, pal.text), lp(dp(96), -2))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { if (u) on(v + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        r.addView(sb, lp(0, -2, 1f))
        return r
    }

    fun colorDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(8), dp(22), 0)
        box.addView(seekRow("Brightness", -60, 60, cBright) { cBright = it; applyColor() })
        box.addView(seekRow("Contrast", 50, 150, cContrast) { cContrast = it; applyColor() })
        box.addView(seekRow("Saturation", 0, 200, cSat) { cSat = it; applyColor() })
        MaterialAlertDialogBuilder(this).setTitle("Video color").setView(box)
            .setPositiveButton("Done", null)
            .setNeutralButton("Reset") { _, _ -> cBright = 0; cContrast = 100; cSat = 100; applyColor() }
            .show()
    }

    fun currentPlaybackMode(): Int = when {
        stopAfterCurrent -> 3
        p.shuffleModeEnabled -> 4
        p.repeatMode == Player.REPEAT_MODE_ONE -> 1
        p.repeatMode == Player.REPEAT_MODE_ALL -> 2
        else -> 0
    }

    fun cyclePlaybackMode() { setPlaybackMode((currentPlaybackMode() + 1) % 5) }

    fun setPlaybackMode(mode: Int) {
        stopAfterCurrent = mode == 3
        p.shuffleModeEnabled = mode == 4
        p.repeatMode = when (mode) {
            1 -> Player.REPEAT_MODE_ONE
            2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        p.pauseAtEndOfMediaItems = when (mode) {
            3 -> true
            0 -> !pf.auto
            else -> false
        }
        val label = AudioEngine.modeLabels.getOrElse(mode) { "Play in Order" }
        flash(label)
    }

    // ------------------------------------------------------------------ menus
    fun queueSheet() {
        val sourceUris = uris
        val sourceNames = names
        val entries = sourceUris.mapIndexed { i, u -> QueueEntry("$i|$u", sourceNames.getOrElse(i) { nameOf(Uri.parse(u)) }) }
        QueueSheet.show(this, "Playing Queue", entries, pal.accent, showMode = true,
            modeIndex = { currentPlaybackMode() }, onCycleMode = { cyclePlaybackMode() },
            currentKey = "${p.currentMediaItemIndex}|${uris.getOrNull(p.currentMediaItemIndex) ?: ""}",
            onSelect = { e ->
                val i = uris.indexOf(e.key.substringAfter("|"))
                if (i >= 0) { p.seekTo(i, 0L); p.play() }
            },
            onChange = { changed ->
                val ordered = changed.mapNotNull { e ->
                    val old = e.key.substringBefore("|").toIntOrNull() ?: -1
                    if (old in sourceUris.indices) old else -1
                }
                val newUris = ordered.map { sourceUris[it] }
                val newNames = ordered.map { sourceNames.getOrElse(it) { "Video" } }
                val currentUri = uris.getOrNull(p.currentMediaItemIndex)
                val pos = p.currentPosition
                val wasPlaying = p.isPlaying
                uris = newUris; names = newNames
                pf.lastQ = newUris; pf.lastQN = newNames
                if (newUris.isNotEmpty()) {
                    val currentNewIndex = newUris.indexOf(currentUri)
                    val idx = if (currentNewIndex >= 0) currentNewIndex else 0
                    p.setMediaItems(newUris.map { MediaItem.fromUri(it) }, idx, if (currentNewIndex >= 0) pos else 0L)
                    p.prepare(); p.playWhenReady = wasPlaying
                } else { p.stop(); finishUp() }
            })
    }

    fun moreMenu(anchor: View) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = rr(0xFF303030.toInt(), dpf(6))
        lateinit var pw: PopupWindow
        fun row(icon: String, text: String, trail: View?, click: () -> Unit) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(16), 0, dp(16), 0)
            r.background = ripple(null, 0f, 0x33FFFFFF)
            val iv = ImageView(this)
            iv.setImageDrawable(PathIcon(icon, Color.WHITE))
            r.addView(iv, lp(dp(26), dp(26)).apply { marginEnd = dp(16) })
            val t = label(text, 17f, Color.WHITE)
            t.maxLines = 1
            r.addView(t, lp(0, -2, 1f))
            if (trail != null) r.addView(trail)
            r.setOnClickListener { click() }
            col.addView(r, lp(-1, dp(48)))
        }
        fun close() { pw.dismiss() }
        val modeTxt = label(AudioEngine.modeLabels[currentPlaybackMode()], 13f, 0xFFAAAAAA.toInt())
        row(AudioEngine.modePath(currentPlaybackMode()), "Playback mode", modeTxt) {
            close()
            choose("Playback mode", AudioEngine.modeLabels, currentPlaybackMode()) { m -> setPlaybackMode(m) }
        }
        row(Ic.TIMER, "Timer", null) { close(); timerDialog() }
        row(Ic.HEADPHONES, "Background play", null) { close(); backgroundPlay() }
        row(Ic.SPEED, "Playback speed", null) { close(); speedDialog() }
        row(Ic.SWAP, "A-B repeat", null) { close(); abRepeat() }
        row(Ic.INFO, "Info", null) { close(); details() }
        row(Ic.DELETE, "Delete", null) { close(); deleteCurrent() }
        val sv = ScrollView(this)
        sv.addView(col)
        val maxH = resources.displayMetrics.heightPixels - dp(80)
        pw = PopupWindow(sv, dp(250), if (dp(48 * 6) > maxH) maxH else ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.elevation = dpf(8)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.showAsDropDown(anchor, 0, 0, Gravity.END)
    }

    /** Hands the video over to the music player service: it keeps playing (audio) with the screen off or the app closed. */
    fun backgroundPlay() {
        if (!isVideo || uris.isEmpty()) return
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val pos = p.currentPosition
        val spd = p.playbackParameters.speed
        savePos()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)
        }
        AudioEngine.start(this, uris.mapIndexed { k, u -> Track(u, names.getOrElse(k) { "" }.substringBeforeLast('.'), "", "", -1L) }, i, pos)
        AudioEngine.player?.setPlaybackSpeed(spd)
        p.pause()
        toast("Playing in background")
        finish()
    }

    /** Floating, resizable window (keeps playing from the same position). */
    fun popup() {
        if (!isVideo) return
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        if (startPopup(uris, names, i, p.currentPosition, p.playWhenReady)) {
            savePos()
            p.pause()
            finish()
        }
    }

    fun decoderDialog() {
        choose("Decoder", listOf("Hardware decoder", "Software decoder"), pf.decoder) {
            if (pf.decoder != it) { pf.decoder = it; rebuildPlayer(); flash(if (it == 0) "Hardware decoder" else "Software decoder") }
        }
    }

    fun playOptions() {
        val items = listOf(
            "Repeat mode", "Auto play next video: " + (if (pf.auto) "On" else "Off"),
            "Resume playback: " + (if (pf.resume) "On" else "Off"), "A-B repeat"
        )
        choose("Play options", items, -1) {
            when (it) {
                0 -> choose("Playback mode", AudioEngine.modeLabels, currentPlaybackMode()) { m -> setPlaybackMode(m) }
                1 -> { pf.auto = !pf.auto; if (!stopAfterCurrent && p.repeatMode == Player.REPEAT_MODE_OFF && !p.shuffleModeEnabled) p.pauseAtEndOfMediaItems = !pf.auto; flash(if (pf.auto) "Auto play next: On" else "Auto play next: Off") }
                2 -> { pf.resume = !pf.resume; flash(if (pf.resume) "Resume: On" else "Resume: Off") }
                3 -> abRepeat()
            }
        }
    }

    fun deleteCurrent() {
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val u = Uri.parse(uris[i])
        if (u.scheme != "content" || u.authority != "media") { toast("Cannot delete this file"); return }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startIntentSenderForResult(MediaStore.createDeleteRequest(contentResolver, listOf(u)).intentSender, 8, null, 0, 0, 0)
            } else {
                contentResolver.delete(u, null, null)
                finishUp()
            }
        } catch (e: Exception) {
            toast("Cannot delete: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 8 && res == RESULT_OK) finishUp()
    }

    fun share() {
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val u = Uri.parse(uris[i])
        val it = if (u.scheme == "content" || u.scheme == "file")
            Intent(Intent.ACTION_SEND).setType(if (isVideo) "video/*" else "audio/*").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        else Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, uris[i])
        startActivity(Intent.createChooser(it, "Send"))
    }

    fun details() {
        val i = p.currentMediaItemIndex.coerceIn(0, uris.size - 1)
        val vs = p.videoSize
        message(
            names.getOrElse(i) { "" },
            "Duration: ${Media.time(maxOf(p.duration, 0L))}" + (if (vs.width > 0) "\nResolution: ${vs.width}x${vs.height}" else "") + "\n${uris[i]}"
        )
    }

    fun enterPip() {
        if (!isVideo) return
        try {
            val vs = p.videoSize
            var ar = Rational(16, 9)
            if (vs.width > 0 && vs.height > 0) {
                val r = vs.width.toFloat() / vs.height
                ar = when {
                    r > 2.39f -> Rational(239, 100)
                    r < 0.42f -> Rational(42, 100)
                    else -> Rational(vs.width, vs.height)
                }
            }
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ar).build())
        } catch (e: Exception) {
            toast("Pop-up is not supported here")
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        show(!inPip)
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onStop() {
        super.onStop()
        if (uris.isNotEmpty() && ::p.isInitialized) {
            savePos()
            if (isVideo && !isInPictureInPictureMode) p.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
        try { sm?.unregisterListener(shakeL) } catch (e: Exception) {}
        try { eq?.release() } catch (e: Exception) {}
        try { loud?.release() } catch (e: Exception) {}
        if (::p.isInitialized) p.release()
    }
}
