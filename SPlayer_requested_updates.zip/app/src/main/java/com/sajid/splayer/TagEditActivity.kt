package com.sajid.splayer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.FileOutputStream

class TagEditActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var art: ImageView
    var id = -1L
    var uriStr = ""
    var origTitle = ""
    var newCover: Bitmap? = null
    var coverBytes: ByteArray? = null
    var pendingTmp: java.io.File? = null
    var pendingFields: Map<String, String> = emptyMap()
    val fields = LinkedHashMap<String, TextInputEditText>()

    val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                contentResolver.openInputStream(u)?.use { s ->
                    BitmapFactory.decodeStream(s, null, o)?.let { newCover = it; art.setImageBitmap(it) }
                }
            } catch (e: Exception) {
                toast("Cannot open this image")
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(b)
        pal = Pal(pf.dark, pf.accent)
        id = intent.getLongExtra("id", -1L)
        uriStr = intent.getStringExtra("uri") ?: ""
        origTitle = intent.getStringExtra("title") ?: ""
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !pal.dark
            isAppearanceLightNavigationBars = !pal.dark
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.bg)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(10), dp(12), dp(6))
        bar.addView(iconBtn(Ic.BACK, pal.text) { finish() })
        val tt = label("Edit tag", 22f, pal.text, true)
        tt.setPadding(dp(12), 0, 0, 0)
        bar.addView(tt, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(iconBtn(Ic.CHECK, pal.text) { save() })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(8), dp(24), dp(32))

        val artBox = FrameLayout(this)
        art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rr(pal.tile, dpf(12))
        art.roundClip(dpf(12))
        art.setImageDrawable(null)
        artBox.addView(art, FrameLayout.LayoutParams(-1, -1))
        val pick = FrameLayout(this)
        pick.background = rr(ColorUtils.blendARGB(pal.accent, Color.WHITE, 0.82f), dpf(18))
        val pi = ImageView(this)
        pi.setImageDrawable(PathIcon(Ic.IMAGE, pal.accent))
        pick.addView(pi, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        pick.setOnClickListener { picker.launch("image/*") }
        artBox.addView(pick, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(12), dp(12)) })
        col.addView(artBox, LinearLayout.LayoutParams(dp(200), dp(200)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(16) })

        fun field(key: String, hint: String, value: String, multi: Boolean = false, number: Boolean = false): TextInputLayout {
            val til = TextInputLayout(this)
            til.hint = hint
            val et = TextInputEditText(til.context)
            et.setText(value)
            if (number) et.inputType = InputType.TYPE_CLASS_NUMBER
            if (multi) { et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; et.minLines = 2 }
            til.addView(et)
            fields[key] = et
            return til
        }
        fun gap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        col.addView(field("title", "Title", intent.getStringExtra("title") ?: ""), gap())
        col.addView(field("artist", "Artist", intent.getStringExtra("artist") ?: ""), gap())
        col.addView(field("album", "Album", intent.getStringExtra("album") ?: ""), gap())
        col.addView(field("genre", "Genre", intent.getStringExtra("genre") ?: ""), gap())
        val yt = LinearLayout(this)
        yt.addView(field("year", "Year", pf.tag(id, "year"), number = true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        yt.addView(field("track", "Track", pf.tag(id, "track"), number = true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        col.addView(yt, gap())
        col.addView(field("comment", "Comment", pf.tag(id, "comment"), multi = true), gap())
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        Thread {
            val bm = Art.load(this, uriStr, id, 600)
            runOnUiThread { if (newCover == null && bm != null) art.setImageBitmap(bm) }
        }.start()
    }

    fun isMp3(): Boolean {
        val u = Uri.parse(uriStr)
        val t = try { contentResolver.getType(u) } catch (e: Exception) { null }
        if (t == "audio/mpeg") return true
        try {
            contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return (it.getString(0) ?: "").endsWith(".mp3", true)
            }
        } catch (e: Exception) {
        }
        return false
    }

    fun save() {
        if (id <= 0) { finish(); return }
        for ((k, e) in fields) pf.setTag(id, k, e.text.toString().trim())
        newCover?.let { bm ->
            try {
                val s = 1024f / maxOf(bm.width, bm.height)
                val out = if (s < 1f) Bitmap.createScaledBitmap(bm, (bm.width * s).toInt(), (bm.height * s).toInt(), true) else bm
                FileOutputStream(Art.file(this, id)).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                val bo = java.io.ByteArrayOutputStream()
                out.compress(Bitmap.CompressFormat.JPEG, 90, bo)
                coverBytes = bo.toByteArray()
            } catch (e: Exception) {
                toast("Cannot save the cover")
            }
        }
        val t = pf.tag(id, "title").ifEmpty { origTitle }
        AudioEngine.updateTrack(id, Track(uriStr, t, pf.tag(id, "artist"), pf.tag(id, "album"), id))
        pendingFields = fields.mapValues { it.value.text.toString().trim() }
        // now write the same information into the real audio file so other players show it too
        val d = busy("Saving…")
        val mp3 = isMp3()
        Thread {
            var tmp: java.io.File? = null
            var err = ""
            try {
                if (mp3) tmp = Id3.build(this, Uri.parse(uriStr), pendingFields, coverBytes)
            } catch (e: Exception) {
                err = e.message ?: "error"
            }
            runOnUiThread {
                d.dismiss()
                pendingTmp = tmp
                if (err.isNotEmpty()) finishSave("Saved in the app only ($err)") else askWrite()
            }
        }.start()
    }

    /** Android needs the user's OK once before an app may change a file it did not create. */
    fun askWrite() {
        val u = Uri.parse(uriStr)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startIntentSenderForResult(MediaStore.createWriteRequest(contentResolver, listOf(u)).intentSender, 11, null, 0, 0, 0)
            } else {
                writeNow(true)
            }
        } catch (e: Exception) {
            finishSave("Saved in the app only (no permission to change the file)")
        }
    }

    fun writeNow(mayAsk: Boolean) {
        val d = busy("Writing tags into the file…")
        Thread {
            var err: String? = null
            var recover: android.app.RecoverableSecurityException? = null
            try {
                err = Id3.apply(this, Uri.parse(uriStr), pendingTmp, pendingFields)
            } catch (e: android.app.RecoverableSecurityException) {
                recover = e
            }
            runOnUiThread {
                d.dismiss()
                val r = recover
                if (r != null && mayAsk) {
                    try { startIntentSenderForResult(r.userAction.actionIntent.intentSender, 11, null, 0, 0, 0) }
                    catch (e: Exception) { finishSave("Saved in the app only (no permission to change the file)") }
                } else if (r != null) finishSave("Saved in the app only (no permission to change the file)")
                else if (err != null) finishSave("Saved in the app only ($err)")
                else finishSave(if (pendingTmp != null || isMp3()) "Saved in the file — other players will show it" else "Saved (this format keeps tags only in the app and library)")
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: android.content.Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 11) {
            if (res == RESULT_OK) writeNow(false)
            else finishSave("Saved in the app only (permission denied)")
        }
    }

    fun finishSave(msg: String) {
        toast(msg)
        setResult(RESULT_OK)
        finish()
    }
}
