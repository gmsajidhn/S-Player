package com.sajid.splayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.LayerDrawable
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.media3.common.Player
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class AudioPlayerActivity : AppCompatActivity() {
    lateinit var pf: Prefs
    lateinit var pal: Pal
    lateinit var am: AudioManager
    lateinit var vinyl: CoverView
    lateinit var vizView: VisualizerView
    lateinit var idxTxt: TextView
    lateinit var titleTxt: TextView
    lateinit var artistTxt: TextView
    lateinit var curTxt: TextView
    lateinit var durTxt: TextView
    lateinit var seek: SeekBar
    lateinit var playIc: PathIcon
    lateinit var heartIc: PathIcon
    lateinit var shufIc: PathIcon
    lateinit var modeCell: FrameLayout
    lateinit var repIc: PathIcon
    lateinit var timerLabel: TextView
    var userSeeking = false
    var lastPlaying: Boolean? = null
    var shownUri = ""
    var viz: Visualizer? = null
    var ok = false
    val h = Handler(Looper.getMainLooper())
    val cb: () -> Unit = { runOnUiThread { refresh() } }

    val tick = object : Runnable {
        override fun run() {
            val p = AudioEngine.player
            if (p != null && !userSeeking) {
                val d = maxOf(p.duration, 0L)
                seek.max = d.toInt()
                seek.progress = p.currentPosition.toInt()
                curTxt.text = Media.time(p.currentPosition)
                durTxt.text = Media.time(d)
            }
            if (::timerLabel.isInitialized) {
                val left = AudioEngine.sleepRemainingMs()
                timerLabel.text = if (left > 0L) { val sec = (left + 999L) / 1000L; String.format(java.util.Locale.US, "%d:%02d", sec / 60, sec % 60) } else ""
                timerLabel.visibility = if (left > 0L) View.VISIBLE else View.GONE
            }
            h.postDelayed(this, 300)
        }
    }

    fun lp(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)

    override fun onCreate(b: Bundle?) {
        pf = Prefs(this)
        setTheme(Themes.res(pf.accent))
        super.onCreate(b)
        pal = Pal(pf.dark, pf.accent)
        if (AudioEngine.player == null || AudioEngine.queue.isEmpty()) { finish(); return }
        ok = true
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        val barBg = 0xFF60364D.toInt()
        window.statusBarColor = 0xFF0D0D0D.toInt()
        window.navigationBarColor = barBg
        androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.clipChildren = false
        root.clipToPadding = false
        root.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1C382A.toInt(), 0xFF263C31.toInt(), 0xFF60364D.toInt())
        )

        // ---- compact header: back, track title/artist, queue
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(10), dp(8), dp(10), dp(6))
        top.addView(iconBtn(Ic.BACK, Color.WHITE) { finish() })
        top.addView(View(this), lp(0, 1, 1f))
        root.addView(top, lp(-1, -2))

        // ---- circular cover with radial spectrum
        val mid = FrameLayout(this)
        vinyl = CoverView(this)
        vinyl.accent = pal.accent
        mid.addView(vinyl, FrameLayout.LayoutParams(-1, -1))
        vizView = VisualizerView(this)
        vizView.visibility = View.GONE

        // Gestures on the artwork: vertical = system music volume, horizontal = track change.
        val artworkGestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                val ax = kotlin.math.abs(dx)
                val ay = kotlin.math.abs(dy)
                if (ax > dp(80) && ax > ay * 1.2f && kotlin.math.abs(velocityX) > dp(350)) {
                    val player = AudioEngine.player ?: return true
                    if (dx < 0) {
                        player.seekToNext()
                        toast("Next track")
                    } else {
                        player.seekToPrevious()
                        toast("Previous track")
                    }
                    return true
                }
                if (ay > dp(65) && ay > ax * 1.2f) {
                    val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    val step = maxOf(1, maxVol / 12)
                    val target = if (dy < 0) (current + step).coerceAtMost(maxVol) else (current - step).coerceAtLeast(0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
                    return true
                }
                return false
            }
        })
        mid.setOnTouchListener { _, event -> artworkGestures.onTouchEvent(event) }

        root.addView(mid, lp(-1, 0, 1f))

        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        heading.setPadding(dp(24), dp(8), dp(24), dp(4))
        titleTxt = label("", 19f, Color.WHITE, true)
        titleTxt.maxLines = 1
        titleTxt.ellipsize = TextUtils.TruncateAt.MARQUEE
        titleTxt.isSelected = true
        titleTxt.gravity = Gravity.CENTER
        artistTxt = label("", 13f, 0xCCFFFFFF.toInt())
        artistTxt.maxLines = 1
        artistTxt.gravity = Gravity.CENTER
        heading.addView(titleTxt, lp(-1, -2))
        heading.addView(artistTxt, lp(-1, -2))
        root.addView(heading, lp(-1, -2))

        // ---- utility row: favourite, sleep timer, more
        val tools = LinearLayout(this)
        tools.gravity = Gravity.CENTER
        tools.setPadding(dp(24), dp(2), dp(24), dp(2))
        fun toolCell(btn: ImageView): FrameLayout {
            val cell = FrameLayout(this)
            btn.background = LayerDrawable(arrayOf(rr(0x2EFFFFFF, dpf(26)), ripple(null, dpf(26))))
            cell.addView(btn, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
            return cell
        }
        val heart = iconBtn(Ic.HEART_O, Color.WHITE, 52, 26) {}
        heartIc = heart.drawable as PathIcon
        heart.contentDescription = "Add to favourites"
        heart.setOnClickListener { toggleFav() }
        tools.addView(toolCell(heart), lp(0, dp(60), 1f))
        val timerCell = FrameLayout(this)
        val sleepButton = iconBtn(Ic.TIMER, Color.WHITE, 52, 26) { sleepTimerDialog() }
        sleepButton.contentDescription = "Sleep timer"
        timerCell.addView(sleepButton, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        timerLabel = label("", 9f, 0xFF80E8B0.toInt(), true).apply { gravity = Gravity.CENTER; setPadding(dp(2), 0, dp(2), 0); background = rr(0xDD18251F.toInt(), dpf(6)); visibility = View.GONE }
        timerCell.addView(timerLabel, FrameLayout.LayoutParams(dp(42), dp(16), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(1) })
        tools.addView(timerCell, lp(0, dp(60), 1f))
        val moreButton = iconBtn(Ic.MORE_H, Color.WHITE, 52, 26) { moreSheet() }
        moreButton.contentDescription = "More options"
        tools.addView(toolCell(moreButton), lp(0, dp(60), 1f))
        root.addView(tools, lp(-1, -2))

        // ---- progress row
        val seekRow = LinearLayout(this)
        seekRow.gravity = Gravity.CENTER_VERTICAL
        seekRow.setPadding(dp(16), dp(2), dp(16), dp(2))
        curTxt = label("0:00", 13f, Color.WHITE)
        seekRow.addView(curTxt, lp(-2, -2))
        seek = SeekBar(this)
        seek.progressTintList = ColorStateList.valueOf(Color.WHITE)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0x66FFFFFF)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) { if (u) { AudioEngine.player?.seekTo(v.toLong()); curTxt.text = Media.time(v.toLong()) } }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) { userSeeking = false }
        })
        seekRow.addView(seek, lp(0, dp(34), 1f))
        durTxt = label("0:00", 13f, Color.WHITE)
        seekRow.addView(durTxt, lp(-2, -2))
        root.addView(seekRow, lp(-1, -2))

        // ---- fixed-height transport controls; fixed cells prevent icons collapsing on narrow screens.
        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER_VERTICAL
        ctl.weightSum = 5f
        ctl.setPadding(dp(8), dp(4), dp(8), dp(10))
        ctl.minimumHeight = dp(88)
        ctl.setBackgroundColor(Color.TRANSPARENT)
        ctl.clipChildren = false
        ctl.clipToPadding = false

        fun transportCell(path: String, description: String, action: () -> Unit): FrameLayout {
            val cell = FrameLayout(this)
            cell.isClickable = true
            cell.isFocusable = true
            cell.contentDescription = description
            cell.background = ripple(null, dpf(36))
            val iv = ImageView(this)
            iv.setImageDrawable(PathIcon(path, Color.WHITE))
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            cell.addView(iv, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            cell.setOnClickListener { action() }
            return cell
        }

        modeCell = FrameLayout(this).apply {
            isClickable = true; isFocusable = true
            contentDescription = "Playback mode: Play in order"
            background = ripple(null, dpf(36))
        }
        shufIc = PathIcon(Ic.ORDER, 0xCCFFFFFF.toInt())
        val repeatIv = ImageView(this).apply {
            setImageDrawable(shufIc); scaleType = ImageView.ScaleType.FIT_CENTER
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        modeCell.addView(repeatIv, FrameLayout.LayoutParams(dp(27), dp(27), Gravity.CENTER))
        modeCell.setOnClickListener { cyclePlaybackMode() }
        ctl.addView(modeCell, lp(0, dp(72), 1f))

        ctl.addView(transportCell(Ic.PREV, "Previous track") {
            AudioEngine.player?.seekToPrevious()
        }, lp(0, dp(72), 1f))

        val playCell = FrameLayout(this)
        playCell.isClickable = true
        playCell.isFocusable = true
        playCell.contentDescription = "Play or pause"
        playCell.background = ripple(null, dpf(40))
        val ring = FrameLayout(this)
        ring.background = rr(Color.WHITE, dpf(28))
        playIc = PathIcon(Ic.PAUSE, pal.accent)
        val piv = ImageView(this)
        piv.setImageDrawable(playIc)
        piv.scaleType = ImageView.ScaleType.FIT_CENTER
        ring.addView(piv, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        playCell.addView(ring, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        playCell.setOnClickListener { AudioEngine.toggle() }
        ctl.addView(playCell, lp(0, dp(80), 1f))

        ctl.addView(transportCell(Ic.NEXT, "Next track") {
            AudioEngine.player?.seekToNext()
        }, lp(0, dp(72), 1f))
        ctl.addView(transportCell(Ic.QUEUE, "Playing queue") { queueSheet() }, lp(0, dp(72), 1f))
        root.addView(ctl, lp(-1, dp(88)))
        setContentView(root)

        AudioEngine.stopAfterCurrent = AudioEngine.player?.pauseAtEndOfMediaItems == true
        AudioEngine.listeners.add(cb)
        refresh()
        h.post(tick)
        if (pf.viz) setViz(true)
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); refresh() }

    fun refresh() {
        val p = AudioEngine.player ?: return
        val t = AudioEngine.current
        if (t == null) { finish(); return }
        titleTxt.text = t.title
        artistTxt.text = t.shownArtist
        playIc.set(if (p.isPlaying) Ic.PAUSE else Ic.PLAY)
        vinyl.playing = p.isPlaying
                heartIc.set(if (isFav(t)) Ic.HEART else Ic.HEART_O)
        heartIc.tint(if (isFav(t)) 0xFFFF5252.toInt() else Color.WHITE)
        updatePlaybackModeIcon()
        if (::timerLabel.isInitialized) {
            val left = AudioEngine.sleepRemainingMs()
            timerLabel.text = if (left > 0L) { val sec = (left + 999L) / 1000L; String.format(java.util.Locale.US, "%d:%02d", sec / 60, sec % 60) } else ""
            timerLabel.visibility = if (left > 0L) View.VISIBLE else View.GONE
        }
        val key = t.uri + "|" + t.id
        if (key != shownUri) {
            shownUri = key
            Thread {
                val bm = Art.load(this, t.uri, t.id, 600)
                runOnUiThread { if (shownUri == key) vinyl.art = bm }
            }.start()
        }
    }

    private fun cyclePlaybackMode() {
        AudioEngine.cycleMode()
        updatePlaybackModeIcon()
        toast(AudioEngine.modeLabels[AudioEngine.modeIndex()])
    }

    private fun updatePlaybackModeIcon() {
        val mode = AudioEngine.modeIndex()
        shufIc.set(AudioEngine.modePath(mode))
        shufIc.tint(if (mode == 0) 0xCCFFFFFF.toInt() else pal.bright)
        if (::modeCell.isInitialized) modeCell.contentDescription = "Playback mode: " + AudioEngine.modeLabels[mode]
    }

    // ---------------------------------------------------------------- favourites
    fun favKey(t: Track) = "a" + t.id
    fun isFav(t: Track) = t.id > 0 && favKey(t) in pf.strs("fav")
    fun toggleFav() {
        val t = AudioEngine.current ?: return
        if (t.id <= 0) { toast("Cannot add this file"); return }
        val s = pf.strs("fav")
        val key = favKey(t)
        if (!s.add(key)) {
            s.remove(key)
            pf.putStrs("fav", s)
            if ("Favourites" in pf.plNames()) pf.plRemoveItem("Favourites", key)
        } else {
            pf.putStrs("fav", s)
            pf.plCreate("Favourites", listOf(key))
        }
        refresh()
    }

    // ---------------------------------------------------------------- visualizer
    fun setViz(on: Boolean) {
        pf.viz = on
        if (!on) { stopViz(); vizView.visibility = View.GONE; vinyl.invalidate(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5)
            return
        }
        startViz()
    }

    fun startViz() {
        stopViz()
        val p = AudioEngine.player ?: return
        val sid = p.audioSessionId
        if (sid == 0) return
        try {
            val v = Visualizer(sid)
            v.captureSize = Visualizer.getCaptureSizeRange()[1]
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, rate: Int) { if (fft != null) vinyl.feed(fft) }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.enabled = true
            viz = v
            vizView.visibility = View.GONE
            vinyl.visibility = View.VISIBLE
        } catch (e: Exception) {
            toast("Visualizer is not available")
            pf.viz = false
        }
    }

    fun stopViz() {
        try { viz?.enabled = false } catch (e: Exception) {}
        try { viz?.release() } catch (e: Exception) {}
        viz = null
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 5) {
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) startViz()
            else { pf.viz = false; toast("Permission needed for visualizer") }
        }
    }

    // ---------------------------------------------------------------- sheets / dialogs
    fun queueSheet() {
        val q = AudioEngine.queue
        if (q.isEmpty()) return
        val entries = q.mapIndexed { i, t -> QueueEntry("$i|${t.uri}", t.title) }
        QueueSheet.show(this, "Playing Queue", entries, pal.accent, showMode = true,
            currentKey = "${AudioEngine.player?.currentMediaItemIndex ?: -1}|${AudioEngine.current?.uri ?: ""}",
            onSelect = { e ->
                val uri = e.key.substringAfter("|")
                val i = AudioEngine.queue.indexOfFirst { it.uri == uri }
                if (i >= 0) { AudioEngine.player?.seekTo(i, 0L); AudioEngine.player?.play() }
            },
            onChange = { changed ->
                val tracks = changed.mapNotNull { e ->
                    val i = e.key.substringBefore("|").toIntOrNull()
                    i?.let { q.getOrNull(it) }
                }
                AudioEngine.reorderQueue(this, tracks)
            })
    }

    fun moreSheet() {
        val t = AudioEngine.current ?: return
        val d = BottomSheetDialog(this)
        val r = dpf(28)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(pal.surface)
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        col.setPadding(0, 0, 0, dp(16))
        val bar = View(this)
        bar.background = rr(pal.line, dpf(2))
        col.addView(bar, lp(dp(40), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(10); bottomMargin = dp(14) })
        val hr = LinearLayout(this)
        hr.gravity = Gravity.CENTER_VERTICAL
        hr.setPadding(dp(20), 0, dp(20), dp(14))
        val art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rr(pal.tile, dpf(10))
        art.roundClip(dpf(10))
        Thread { val bm = Art.load(this, t.uri, t.id, 200); runOnUiThread { if (bm != null) art.setImageBitmap(bm) } }.start()
        hr.addView(art, lp(dp(48), dp(48)).apply { marginEnd = dp(16) })
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        val t1 = label(t.title, 19f, pal.text, true)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        tc.addView(t1)
        tc.addView(label(t.shownArtist, 14f, pal.sub))
        hr.addView(tc, lp(0, -2, 1f))
        col.addView(hr)
        val dv = View(this)
        dv.setBackgroundColor(pal.line)
        col.addView(dv, lp(-1, dp(1)).apply { marginStart = dp(20); marginEnd = dp(20) })

        fun row(icon: String, text: String, trail: View?, click: () -> Unit) {
            val rw = LinearLayout(this)
            rw.gravity = Gravity.CENTER_VERTICAL
            rw.setPadding(dp(20), dp(8), dp(20), dp(8))
            rw.background = ripple(null, 0f)
            val circ = FrameLayout(this)
            circ.background = rr(pal.tile, dpf(22))
            val iv = ImageView(this)
            iv.setImageDrawable(PathIcon(icon, pal.text))
            circ.addView(iv, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            rw.addView(circ, lp(dp(44), dp(44)).apply { marginEnd = dp(20) })
            rw.addView(label(text, 17f, pal.text), lp(0, -2, 1f))
            if (trail != null) rw.addView(trail)
            rw.setOnClickListener { click() }
            col.addView(rw, lp(-1, dp(56)))
        }
        val sw = MaterialSwitch(this)
        sw.isChecked = pf.viz
        sw.setOnCheckedChangeListener { _, v -> setViz(v) }
        row(Ic.WAVE, "Visualizer", sw) { sw.toggle() }
        row(Ic.CUT, "Cut", null) { d.dismiss(); cutCur(t) }
        row(Ic.SHARE, "Send", null) { d.dismiss(); sendCur(t) }
        row(Ic.TIMER, "Timer", null) { d.dismiss(); timerDialog() }
        row(Ic.SPEED, "Playback speed", null) { d.dismiss(); speedDialog() }
        row(Ic.EDIT, "Edit tag", null) { d.dismiss(); editTag(t) }
        row(Ic.MUSIC, "Set as ringtone", null) { d.dismiss(); ringtone(t) }
        row(Ic.DETAILS, "Details", null) { d.dismiss(); details(t) }

        val sv = android.widget.ScrollView(this)
        sv.addView(col)
        d.setContentView(sv)
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
            d.behavior.skipCollapsed = true
            d.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        }
        d.show()
    }

    fun cutCur(t: Track) {
        val p = AudioEngine.player
        startActivity(
            Intent(this, CutterActivity::class.java).putExtra("uri", t.uri).putExtra("name", t.title + ".mp3")
                .putExtra("dur", maxOf(p?.duration ?: 0L, 0L)).putExtra("size", 0L).putExtra("audio", true)
        )
    }

    fun sendCur(t: Track) {
        val u = Uri.parse(t.uri)
        val i = Intent(Intent.ACTION_SEND).setType("audio/*").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Send"))
    }

    fun timerDialog() {
        sleepTimerDialog()
    }


    private fun speedDialog() {
        val p = AudioEngine.player ?: return
        val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f, 4f, 6f, 8f)
        val labels = speeds.map { "${String.format(java.util.Locale.US, "%.2f", it).trimEnd('0').trimEnd('.')}x" }.toTypedArray()
        val current = speeds.indexOfFirst { kotlin.math.abs(it - p.playbackParameters.speed) < 0.01f }
        MaterialAlertDialogBuilder(this).setTitle("Playback speed")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                p.setPlaybackSpeed(speeds[which])
                dialog.dismiss()
                toast("Speed ${labels[which]}")
            }.setNegativeButton("Cancel", null).show()
    }



    fun editTag(t: Track) {
        if (t.id <= 0) { toast("Cannot edit this file"); return }
        startActivity(
            Intent(this, TagEditActivity::class.java).putExtra("id", t.id).putExtra("uri", t.uri)
                .putExtra("title", t.title).putExtra("artist", t.artist).putExtra("album", t.album)
                .putExtra("genre", pf.tag(t.id, "genre"))
        )
    }

    fun ringtone(t: Track) {
        if (!Settings.System.canWrite(this)) {
            toast("Allow \"Modify system settings\" for S Player")
            try { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).setData(Uri.parse("package:$packageName"))) } catch (e: Exception) {}
            return
        }
        try {
            RingtoneManager.setActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE, Uri.parse(t.uri))
            toast("Ringtone set")
        } catch (e: Exception) {
            toast("Cannot set ringtone")
        }
    }

    fun details(t: Track) {
        val p = AudioEngine.player
        message(t.title, "Artist: ${t.shownArtist}\nAlbum: ${if (t.album.isEmpty()) "<unknown>" else t.album}\nDuration: ${Media.time(maxOf(p?.duration ?: 0L, 0L))}\n${t.uri}")
    }

    fun eqDialog() {
        if (pf.sysEq) {
            try {
                startActivity(Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
                    .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, AudioEngine.player?.audioSessionId ?: 0)
                    .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC))
                return
            } catch (_: Exception) { }
        }
        val e = AudioEngine.eq
        if (e == null) { toast("Equalizer is not available yet"); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(4)) }
        val enabled = MaterialSwitch(this).apply { text = "Equalizer"; isChecked = e.enabled }
        enabled.setOnCheckedChangeListener { _, on -> e.enabled = on }
        box.addView(enabled, lp(-1, dp(42)))
        val presets = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val presetNames = listOf("Custom", "Normal", "Classical", "Dance", "Flat")
        val presetButtons = ArrayList<TextView>()
        fun selectPreset(name: String) {
            val values = when (name) {
                "Normal" -> intArrayOf(0, 0, 0, 0, 0)
                "Classical" -> intArrayOf(5, 3, -1, 2, 4)
                "Dance" -> intArrayOf(5, 3, 0, 3, 4)
                "Flat" -> intArrayOf(0, 0, 0, 0, 0)
                else -> return
            }
            val minDb = e.bandLevelRange[0].toInt(); val maxDb = e.bandLevelRange[1].toInt()
            for (i in 0 until e.numberOfBands.toInt()) {
                val v = (values[(i * 5 / maxOf(1, e.numberOfBands.toInt())).coerceIn(0, 4)] * 100).coerceIn(minDb, maxDb)
                e.setBandLevel(i.toShort(), v.toShort()); pf.put("eq$i", v)
            }
            e.enabled = true; enabled.isChecked = true
            box.post { }
        }
        presetNames.forEach { name ->
            val b = label(name, 11f, pal.text, true).apply { gravity = Gravity.CENTER; setPadding(dp(7), dp(9), dp(7), dp(9)); background = ripple(pal.tile, dpf(18)); setOnClickListener { selectPreset(name); toast("$name preset") } }
            presetButtons.add(b); presets.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) })
        }
        box.addView(presets, lp(-1, dp(42)))
        val sliders = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4)) }
        val minL = e.bandLevelRange[0].toInt(); val maxL = e.bandLevelRange[1].toInt()
        val count = e.numberOfBands.toInt()
        val chosen = if (count <= 5) (0 until count).toList() else (0..4).map { (it * (count - 1) / 4) }
        chosen.forEachIndexed { visualIndex, bandIndex ->
            val bi = bandIndex.toShort()
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val sb = SeekBar(this).apply {
                max = maxL - minL; progress = e.getBandLevel(bi) - minL; rotation = -90f
                progressTintList = ColorStateList.valueOf(pal.accent); thumbTintList = ColorStateList.valueOf(pal.accent)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { if (fromUser) { val level = v + minL; e.setBandLevel(bi, level.toShort()); e.enabled = true; enabled.isChecked = true; pf.put("eq$bandIndex", level) } }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            col.addView(sb, LinearLayout.LayoutParams(dp(145), dp(38)).apply { topMargin = dp(55); bottomMargin = dp(55) })
            val hz = e.getCenterFreq(bi) / 1000
            col.addView(label(if (hz >= 1000) "${hz / 1000}kHz" else "${hz}Hz", 10f, pal.text, true).apply { gravity = Gravity.CENTER })
            sliders.addView(col, LinearLayout.LayoutParams(0, dp(165), 1f))
        }
        box.addView(sliders, lp(-1, dp(178)))
        box.addView(label("Reverb     None", 13f, pal.sub).apply { setPadding(dp(4), dp(6), 0, dp(8)) })
        MaterialAlertDialogBuilder(this).setTitle("Equalizer").setView(box)
            .setPositiveButton("Done", null)
            .setNeutralButton("Reset") { _, _ ->
                for (bd in 0 until count) { e.setBandLevel(bd.toShort(), 0); pf.put("eq$bd", 0) }
                e.enabled = true
            }.show()
    }

    // ---------------------------------------------------------------- delete
    fun deleteCur() {
        val t = AudioEngine.current ?: return
        val u = Uri.parse(t.uri)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startIntentSenderForResult(MediaStore.createDeleteRequest(contentResolver, listOf(u)).intentSender, 7, null, 0, 0, 0)
            } else {
                contentResolver.delete(u, null, null)
                afterDelete()
            }
        } catch (e: Exception) {
            toast("Cannot delete: ${e.message}")
        }
    }

    fun afterDelete() {
        AudioEngine.removeCurrent(this)
        if (AudioEngine.queue.isEmpty()) finish()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 7 && res == RESULT_OK) afterDelete()
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
        AudioEngine.listeners.remove(cb)
        stopViz()
    }
}
