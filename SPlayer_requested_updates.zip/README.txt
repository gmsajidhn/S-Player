S Player v3 - Android video/music player (Material 3 UI).
Upload all files to a GitHub repo (main branch). Actions > Build S Player APK builds app-debug.apk (artifact S-Player-APK).

New in v3: private vault for Lock/Hide, real ID3 tag writing, round static cover, floating resizable pop-up, background export, resume bars.

v3.1: new player control layout, named playlists, thumbnail progress line.

v3.2: fixed signing key (app/splayer.jks) - APKs from every build update over each other. Do not delete this file.

Updated implementation notes:
- All in-app audio/video Playing Queue sheets use a draggable handle on the left and a remove control on the right. Reorder/remove changes are saved.
- Audio Player uses a radial cover visualizer, a single repeat/shuffle cycle control, and an audio-only Favourites playlist action.
- Primary colour settings include preset swatches and a custom HEX colour entry.
- Audio Editor includes decoded PCM waveform display, Cut/Exclude selection, trim handles, fade/silence/volume/bitrate controls and MP3 export.
- Video playback keeps a slim seek progress line visible when the main controls auto-hide.

GitHub Actions:
- The Android project is located in the SPlayer/ directory.
- The workflow installs Java 17, Android SDK platform 34 and Gradle 8.7, then builds SPlayer/app/build/outputs/apk/debug/app-debug.apk.
